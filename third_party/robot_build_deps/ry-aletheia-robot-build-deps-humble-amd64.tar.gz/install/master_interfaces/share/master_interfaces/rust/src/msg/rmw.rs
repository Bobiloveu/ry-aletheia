#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__BagInfo() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__BagInfo__init(msg: *mut BagInfo) -> bool;
    fn master_interfaces__msg__BagInfo__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BagInfo>, size: usize) -> bool;
    fn master_interfaces__msg__BagInfo__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BagInfo>);
    fn master_interfaces__msg__BagInfo__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BagInfo>, out_seq: *mut rosidl_runtime_rs::Sequence<BagInfo>) -> bool;
}

// Corresponds to master_interfaces__msg__BagInfo
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 数据包信息

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BagInfo {
    /// 数据包名称
    pub name: rosidl_runtime_rs::String,

    /// 数据包完整路径
    pub path: rosidl_runtime_rs::String,

    /// 数据包大小（字节）
    pub size_bytes: i64,

    /// 创建时间（Unix 时间戳，秒）
    pub creation_time: i64,

    /// 录制时长（纳秒）
    pub duration_ns: i64,

    /// 消息总数
    pub message_count: i32,

}



impl Default for BagInfo {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__BagInfo__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__BagInfo__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BagInfo {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__BagInfo__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__BagInfo__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__BagInfo__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BagInfo {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BagInfo where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/BagInfo";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__BagInfo() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__Carbuilding() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__Carbuilding__init(msg: *mut Carbuilding) -> bool;
    fn master_interfaces__msg__Carbuilding__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Carbuilding>, size: usize) -> bool;
    fn master_interfaces__msg__Carbuilding__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Carbuilding>);
    fn master_interfaces__msg__Carbuilding__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Carbuilding>, out_seq: *mut rosidl_runtime_rs::Sequence<Carbuilding>) -> bool;
}

// Corresponds to master_interfaces__msg__Carbuilding
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Carbuilding {

    // This member is not documented.
    #[allow(missing_docs)]
    pub car_id: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building_id: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ent_status: rosidl_runtime_rs::String,

}



impl Default for Carbuilding {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__Carbuilding__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__Carbuilding__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Carbuilding {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__Carbuilding__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__Carbuilding__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__Carbuilding__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Carbuilding {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Carbuilding where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/Carbuilding";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__Carbuilding() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__ErrorCode() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__ErrorCode__init(msg: *mut ErrorCode) -> bool;
    fn master_interfaces__msg__ErrorCode__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ErrorCode>, size: usize) -> bool;
    fn master_interfaces__msg__ErrorCode__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ErrorCode>);
    fn master_interfaces__msg__ErrorCode__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ErrorCode>, out_seq: *mut rosidl_runtime_rs::Sequence<ErrorCode>) -> bool;
}

// Corresponds to master_interfaces__msg__ErrorCode
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 标准错误码定义

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ErrorCode {
    /// 当前错误码
    pub code: i32,

    /// 错误详细描述
    pub description: rosidl_runtime_rs::String,

}

impl ErrorCode {
    /// 操作成功
    pub const SUCCESS: i32 = 0;

    /// 未知错误
    pub const UNKNOWN_ERROR: i32 = 1000;

    /// 网络通信错误
    pub const NETWORK_ERROR: i32 = 1001;

    /// 无效参数
    pub const INVALID_PARAMETER: i32 = 1002;

    /// 服务不可用
    pub const SERVICE_UNAVAILABLE: i32 = 1003;

    /// 操作超时
    pub const TIMEOUT: i32 = 1004;

    /// 资源不存在
    pub const RESOURCE_NOT_FOUND: i32 = 1005;

    /// 权限不足
    pub const PERMISSION_DENIED: i32 = 1006;

    /// 硬件错误
    pub const HARDWARE_ERROR: i32 = 2000;

    /// 导航相关错误
    pub const NAVIGATION_ERROR: i32 = 3000;

}


impl Default for ErrorCode {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__ErrorCode__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__ErrorCode__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ErrorCode {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__ErrorCode__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__ErrorCode__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__ErrorCode__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ErrorCode {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ErrorCode where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/ErrorCode";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__ErrorCode() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__MultiTaskDestination() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__MultiTaskDestination__init(msg: *mut MultiTaskDestination) -> bool;
    fn master_interfaces__msg__MultiTaskDestination__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MultiTaskDestination>, size: usize) -> bool;
    fn master_interfaces__msg__MultiTaskDestination__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MultiTaskDestination>);
    fn master_interfaces__msg__MultiTaskDestination__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MultiTaskDestination>, out_seq: *mut rosidl_runtime_rs::Sequence<MultiTaskDestination>) -> bool;
}

// Corresponds to master_interfaces__msg__MultiTaskDestination
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// MultiTaskDestination.msg - One destination in a multi-point delivery sequence

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MultiTaskDestination {

    // This member is not documented.
    #[allow(missing_docs)]
    pub building: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_type: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub delivery_code: rosidl_runtime_rs::String,

}



impl Default for MultiTaskDestination {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__MultiTaskDestination__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__MultiTaskDestination__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MultiTaskDestination {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__MultiTaskDestination__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__MultiTaskDestination__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__MultiTaskDestination__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MultiTaskDestination {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MultiTaskDestination where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/MultiTaskDestination";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__MultiTaskDestination() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigateTodoorStatus() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__NavigateTodoorStatus__init(msg: *mut NavigateTodoorStatus) -> bool;
    fn master_interfaces__msg__NavigateTodoorStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoorStatus>, size: usize) -> bool;
    fn master_interfaces__msg__NavigateTodoorStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoorStatus>);
    fn master_interfaces__msg__NavigateTodoorStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoorStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoorStatus>) -> bool;
}

// Corresponds to master_interfaces__msg__NavigateTodoorStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// NavigateTodoorStatus.msg - 导航到户详细状态消息
/// 用于发布导航到户任务的详细进度信息

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoorStatus {
    /// 时间戳
    pub stamp: builtin_interfaces::msg::rmw::Time,

    /// 导航状态
    /// 状态: "idle", "navigating", "task_executing", "completed", "failed", "successful"
    pub status: rosidl_runtime_rs::String,

    /// 当前路径点信息
    /// 当前路径点ID
    pub current_waypoint_id: rosidl_runtime_rs::String,

    /// 当前路径点索引（从0开始）
    pub current_waypoint_index: i32,

    /// 当前路径点位姿
    pub current_pose: geometry_msgs::msg::rmw::Pose,

    /// 当前速度模式
    pub current_speed_mode: rosidl_runtime_rs::String,

    /// 当前任务描述（如果有）
    pub current_task: rosidl_runtime_rs::String,

    /// 进度信息
    /// 总路径点数
    pub total_waypoints: i32,

    /// 已完成路径点数
    pub completed_waypoints: i32,

    /// 剩余路径点数
    pub remaining_waypoints: i32,

    /// 完成百分比 (0-100)
    pub progress_percentage: f32,

    /// 分组信息
    /// 总分组数
    pub total_groups: i32,

    /// 当前分组索引（从0开始）
    pub current_group_index: i32,

    /// 当前分组内的路径点数
    pub current_group_waypoints: i32,

    /// 已完成分组数
    pub completed_groups: i32,

    /// 距离和时间信息
    /// 距离当前目标的距离（米）
    pub distance_to_current_goal: f32,

    /// 已用时间（秒）
    pub elapsed_time: f32,

    /// 错误信息（如果有）
    /// 错误描述信息
    pub error_message: rosidl_runtime_rs::String,

}



impl Default for NavigateTodoorStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__NavigateTodoorStatus__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__NavigateTodoorStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoorStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateTodoorStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateTodoorStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateTodoorStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoorStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoorStatus where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/NavigateTodoorStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigateTodoorStatus() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigateWaypoint() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__NavigateWaypoint__init(msg: *mut NavigateWaypoint) -> bool;
    fn master_interfaces__msg__NavigateWaypoint__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateWaypoint>, size: usize) -> bool;
    fn master_interfaces__msg__NavigateWaypoint__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateWaypoint>);
    fn master_interfaces__msg__NavigateWaypoint__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateWaypoint>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateWaypoint>) -> bool;
}

// Corresponds to master_interfaces__msg__NavigateWaypoint
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// NavigateWaypoint.msg - 导航路径点消息
/// 包含位姿、速度模式和任务信息

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateWaypoint {
    /// 路径点唯一标识符（可选，为空表示无ID）
    pub waypoint_id: rosidl_runtime_rs::String,

    /// 路径点位姿（位置和方向）
    pub pose: geometry_msgs::msg::rmw::Pose,

    /// 速度模式（行为树文件路径）
    pub speed_mode: rosidl_runtime_rs::String,

    /// 路径点任务（行为树文件路径，空字符串表示无任务）
    pub waypoint_task: rosidl_runtime_rs::String,

}



impl Default for NavigateWaypoint {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__NavigateWaypoint__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__NavigateWaypoint__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateWaypoint {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateWaypoint__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateWaypoint__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateWaypoint__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateWaypoint {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateWaypoint where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/NavigateWaypoint";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigateWaypoint() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigateWaypointArray() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__NavigateWaypointArray__init(msg: *mut NavigateWaypointArray) -> bool;
    fn master_interfaces__msg__NavigateWaypointArray__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateWaypointArray>, size: usize) -> bool;
    fn master_interfaces__msg__NavigateWaypointArray__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateWaypointArray>);
    fn master_interfaces__msg__NavigateWaypointArray__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateWaypointArray>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateWaypointArray>) -> bool;
}

// Corresponds to master_interfaces__msg__NavigateWaypointArray
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// NavigateWaypointArray.msg - 导航路径点数组消息
/// 包含多个导航路径点

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateWaypointArray {
    /// 路径点数组
    pub waypoints: rosidl_runtime_rs::Sequence<super::super::msg::rmw::NavigateWaypoint>,

}



impl Default for NavigateWaypointArray {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__NavigateWaypointArray__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__NavigateWaypointArray__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateWaypointArray {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateWaypointArray__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateWaypointArray__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigateWaypointArray__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateWaypointArray {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateWaypointArray where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/NavigateWaypointArray";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigateWaypointArray() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigationStatus() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__NavigationStatus__init(msg: *mut NavigationStatus) -> bool;
    fn master_interfaces__msg__NavigationStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigationStatus>, size: usize) -> bool;
    fn master_interfaces__msg__NavigationStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigationStatus>);
    fn master_interfaces__msg__NavigationStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigationStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigationStatus>) -> bool;
}

// Corresponds to master_interfaces__msg__NavigationStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// NavigationStatus.msg - 导航状态消息
///
/// 描述导航任务的详细状态信息
/// 用于导航状态查询和监控

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigationStatus {
    /// 任务ID
    pub task_id: rosidl_runtime_rs::String,

    /// 任务状态
    pub status: u8,

    /// 目标位姿
    pub target_pose: geometry_msgs::msg::rmw::PoseStamped,

    /// 当前位姿
    pub current_pose: geometry_msgs::msg::rmw::PoseStamped,

    /// 剩余距离 (米)
    pub remaining_distance: f64,

    /// 预计剩余时间 (秒)
    pub estimated_time_remaining: f64,

    /// 导航进度 (0.0 - 1.0)
    pub progress: f64,

    /// 当前使用的规划器ID
    pub current_planner_id: rosidl_runtime_rs::String,

    /// 当前使用的控制器ID
    pub current_controller_id: rosidl_runtime_rs::String,

    /// 任务创建时间
    pub created_time: builtin_interfaces::msg::rmw::Time,

    /// 任务开始时间
    pub started_time: builtin_interfaces::msg::rmw::Time,

    /// 任务完成时间 (如果已完成)
    pub completed_time: builtin_interfaces::msg::rmw::Time,

    /// 错误信息 (如果失败)
    pub error_message: rosidl_runtime_rs::String,

    /// 航点类型 (用于业务逻辑识别)
    pub waypoint_type: rosidl_runtime_rs::String,

    /// 导航相关的额外数据 (JSON格式)
    pub navigation_data: rosidl_runtime_rs::String,

}

impl NavigationStatus {
    /// 导航状态常量定义
    /// 等待中 - 任务已创建但未开始
    pub const PENDING: u8 = 0;

    /// 规划中 - 正在计算路径
    pub const PLANNING: u8 = 1;

    /// 执行中 - 正在导航
    pub const RUNNING: u8 = 2;

    /// 成功 - 导航任务成功完成
    pub const SUCCEEDED: u8 = 3;

    /// 失败 - 导航任务失败
    pub const FAILED: u8 = 4;

    /// 已取消 - 导航任务被取消
    pub const CANCELLED: u8 = 5;

    /// 暂停中 - 导航任务暂停
    pub const PAUSED: u8 = 6;

}


impl Default for NavigationStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__NavigationStatus__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__NavigationStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigationStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigationStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigationStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__NavigationStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigationStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigationStatus where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/NavigationStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__NavigationStatus() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__PlanStatus() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__PlanStatus__init(msg: *mut PlanStatus) -> bool;
    fn master_interfaces__msg__PlanStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PlanStatus>, size: usize) -> bool;
    fn master_interfaces__msg__PlanStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PlanStatus>);
    fn master_interfaces__msg__PlanStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PlanStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<PlanStatus>) -> bool;
}

// Corresponds to master_interfaces__msg__PlanStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 任务状态骨架消息

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PlanStatus {
    /// 任务UID
    pub task_id: rosidl_runtime_rs::String,

    /// 任务状态
    pub state: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub detail: rosidl_runtime_rs::String,

}



impl Default for PlanStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__PlanStatus__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__PlanStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PlanStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__PlanStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__PlanStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__PlanStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PlanStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PlanStatus where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/PlanStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__PlanStatus() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__RobotState() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__RobotState__init(msg: *mut RobotState) -> bool;
    fn master_interfaces__msg__RobotState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RobotState>, size: usize) -> bool;
    fn master_interfaces__msg__RobotState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RobotState>);
    fn master_interfaces__msg__RobotState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RobotState>, out_seq: *mut rosidl_runtime_rs::Sequence<RobotState>) -> bool;
}

// Corresponds to master_interfaces__msg__RobotState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// RobotState.msg - 机器人综合状态信息
///
/// 提供机器人在某一时刻的完整运行状态，用于监控与调试。
/// 该消息与 master_SDK_server/RobotStateServer 实现保持一致。

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobotState {
    /// 标准头部（时间戳 + 坐标系）
    pub header: std_msgs::msg::rmw::Header,

    /// 机器人唯一标识（一般使用节点名或序列号）
    pub robot_id: rosidl_runtime_rs::String,

    /// 机器人位姿（包含协方差）
    pub pose: geometry_msgs::msg::rmw::PoseWithCovarianceStamped,

    /// 机器人速度（包含协方差）
    pub twist: geometry_msgs::msg::rmw::TwistWithCovariance,

    /// 电池电量百分比 (0-100)
    pub battery_percentage: f64,

    /// 电池电压 (V)
    pub battery_voltage: f64,

    /// 当前是否在充电
    pub is_charging: bool,

    /// 系统状态 (参考 master_interfaces/msg/SystemState 常量)
    pub system_state: u8,

    /// 系统状态文字描述
    pub state_description: rosidl_runtime_rs::String,

    /// 机器人已运行时间 (秒)
    pub uptime: f64,

    /// 健康状态文字描述，如 "健康"、"警告: 电池电量低"
    pub health_status: rosidl_runtime_rs::String,

    /// 与平台（MQTT / ROS2 等）的连接状态
    pub is_connected: bool,

    /// 错误信息（非空表示出现异常）
    pub error_message: rosidl_runtime_rs::String,

}



impl Default for RobotState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__RobotState__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__RobotState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RobotState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__RobotState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__RobotState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__RobotState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RobotState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RobotState where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/RobotState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__RobotState() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__StandardResponse() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__StandardResponse__init(msg: *mut StandardResponse) -> bool;
    fn master_interfaces__msg__StandardResponse__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StandardResponse>, size: usize) -> bool;
    fn master_interfaces__msg__StandardResponse__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StandardResponse>);
    fn master_interfaces__msg__StandardResponse__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StandardResponse>, out_seq: *mut rosidl_runtime_rs::Sequence<StandardResponse>) -> bool;
}

// Corresponds to master_interfaces__msg__StandardResponse
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 标准响应消息格式

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StandardResponse {
    /// 操作是否成功
    pub success: bool,

    /// 错误信息（success=false时使用）
    pub error_code: super::super::msg::rmw::ErrorCode,

    /// 响应时间戳
    pub timestamp: builtin_interfaces::msg::rmw::Time,

    /// 可选的额外数据
    pub data: rosidl_runtime_rs::String,

    /// 可选的额外消息
    pub message: rosidl_runtime_rs::String,

}



impl Default for StandardResponse {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__StandardResponse__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__StandardResponse__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StandardResponse {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__StandardResponse__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__StandardResponse__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__StandardResponse__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StandardResponse {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StandardResponse where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/StandardResponse";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__StandardResponse() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__StateTransition() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__StateTransition__init(msg: *mut StateTransition) -> bool;
    fn master_interfaces__msg__StateTransition__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StateTransition>, size: usize) -> bool;
    fn master_interfaces__msg__StateTransition__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StateTransition>);
    fn master_interfaces__msg__StateTransition__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StateTransition>, out_seq: *mut rosidl_runtime_rs::Sequence<StateTransition>) -> bool;
}

// Corresponds to master_interfaces__msg__StateTransition
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// StateTransition.msg - 状态转换消息
///
/// 描述系统状态转换的详细信息
/// 用于状态机的状态转换记录和调试

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StateTransition {
    /// 转换ID (唯一标识符)
    pub transition_id: rosidl_runtime_rs::String,

    /// 源状态
    pub from_state: u8,

    /// 目标状态
    pub to_state: u8,

    /// 转换类型
    pub transition_type: u8,

    /// 转换结果
    pub transition_result: u8,

    /// 触发转换的事件或条件
    pub trigger_event: rosidl_runtime_rs::String,

    /// 转换开始时间
    pub transition_start_time: builtin_interfaces::msg::rmw::Time,

    /// 转换完成时间
    pub transition_end_time: builtin_interfaces::msg::rmw::Time,

    /// 转换持续时间 (毫秒)
    pub transition_duration_ms: i64,

    /// 转换原因或描述
    pub reason: rosidl_runtime_rs::String,

    /// 转换失败时的错误信息
    pub error_message: rosidl_runtime_rs::String,

    /// 转换相关的额外数据 (JSON格式)
    pub transition_data: rosidl_runtime_rs::String,

}

impl StateTransition {
    /// 转换类型常量
    /// 自动转换
    pub const AUTOMATIC: u8 = 0;

    /// 手动触发转换
    pub const MANUAL: u8 = 1;

    /// 事件触发转换
    pub const EVENT_TRIGGERED: u8 = 2;

    /// 错误触发转换
    pub const ERROR_TRIGGERED: u8 = 3;

    /// 超时触发转换
    pub const TIMEOUT_TRIGGERED: u8 = 4;

    /// 转换结果常量
    /// 转换成功
    pub const SUCCESS: u8 = 0;

    /// 转换失败
    pub const FAILED: u8 = 1;

    /// 转换被拒绝
    pub const REJECTED: u8 = 2;

    /// 转换进行中
    pub const PENDING: u8 = 3;

}


impl Default for StateTransition {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__StateTransition__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__StateTransition__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StateTransition {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__StateTransition__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__StateTransition__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__StateTransition__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StateTransition {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StateTransition where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/StateTransition";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__StateTransition() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__SystemState() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__SystemState__init(msg: *mut SystemState) -> bool;
    fn master_interfaces__msg__SystemState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SystemState>, size: usize) -> bool;
    fn master_interfaces__msg__SystemState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SystemState>);
    fn master_interfaces__msg__SystemState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SystemState>, out_seq: *mut rosidl_runtime_rs::Sequence<SystemState>) -> bool;
}

// Corresponds to master_interfaces__msg__SystemState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// SystemState.msg - 系统状态消息
///
/// 定义机器人系统的宏观状态，用于状态机管理
/// 该消息描述了系统当前所处的主要状态

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SystemState {
    /// 当前系统状态
    pub current_state: u8,

    /// 前一个系统状态
    pub previous_state: u8,

    /// 状态描述信息
    pub state_description: rosidl_runtime_rs::String,

    /// 状态进入时间
    pub state_entered_time: builtin_interfaces::msg::rmw::Time,

    /// 状态持续时间 (秒)
    pub state_duration: f64,

    /// 状态相关的额外信息 (JSON格式)
    pub state_data: rosidl_runtime_rs::String,

}

impl SystemState {
    /// 状态常量定义
    /// 未知状态
    pub const UNKNOWN: u8 = 0;

    /// 初始化中
    pub const INITIALIZING: u8 = 1;

    /// 空闲状态 - 系统已就绪但未执行任务
    pub const IDLE: u8 = 2;

    /// 激活状态 - 系统已激活，可以接收任务
    pub const ACTIVE: u8 = 3;

    /// 导航中 - 正在执行导航任务
    pub const NAVIGATING: u8 = 4;

    /// 建图中 - 正在执行SLAM建图
    pub const MAPPING: u8 = 5;

    /// 定位中 - 正在执行重定位
    pub const LOCALIZING: u8 = 6;

    /// 充电中 - 机器人正在充电
    pub const CHARGING: u8 = 7;

    /// 错误状态 - 系统出现错误需要处理
    pub const ERROR: u8 = 8;

    /// 紧急停止 - 系统紧急停止
    pub const EMERGENCY_STOP: u8 = 9;

    /// 维护模式 - 系统处于维护状态
    pub const MAINTENANCE: u8 = 10;

    /// 关机中 - 系统正在关闭
    pub const SHUTDOWN: u8 = 11;

}


impl Default for SystemState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__SystemState__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__SystemState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SystemState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__SystemState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__SystemState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__SystemState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SystemState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SystemState where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/SystemState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__SystemState() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__TaskStatus() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__msg__TaskStatus__init(msg: *mut TaskStatus) -> bool;
    fn master_interfaces__msg__TaskStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TaskStatus>, size: usize) -> bool;
    fn master_interfaces__msg__TaskStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TaskStatus>);
    fn master_interfaces__msg__TaskStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TaskStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<TaskStatus>) -> bool;
}

// Corresponds to master_interfaces__msg__TaskStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Author: Ming Yu Li & Alex
/// Email: 1323653732@qq.com

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TaskStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status_code: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_uuid: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for TaskStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__msg__TaskStatus__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__msg__TaskStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TaskStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__TaskStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__TaskStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__msg__TaskStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TaskStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TaskStatus where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/msg/TaskStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__msg__TaskStatus() }
  }
}


