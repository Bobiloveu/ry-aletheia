
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to master_interfaces__action__CargoCommand_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_Goal {
    /// ============ Goal ============
    pub cargo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub operation_code: u8,

}

impl CargoCommand_Goal {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_UPPER: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_LOWER: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_MANUAL_OPEN: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_MANUAL_CLOSE: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_AUTO_UNLOAD: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_RESET: u8 = 3;

}


impl Default for CargoCommand_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_Goal {
  type RmwMsg = super::action::rmw::CargoCommand_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        cargo_id: msg.cargo_id,
        operation_code: msg.operation_code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      cargo_id: msg.cargo_id,
      operation_code: msg.operation_code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      cargo_id: msg.cargo_id,
      operation_code: msg.operation_code,
    }
  }
}


// Corresponds to master_interfaces__action__CargoCommand_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub operation_code: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_code: u8,

}

impl CargoCommand_Result {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_GOAL: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_BUSY: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_MQTT_UNAVAILABLE: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_PUBLISH_FAILED: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_TIMEOUT: u8 = 5;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_RESPONSE_MISMATCH: u8 = 6;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_RESPONSE_INVALID: u8 = 7;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 8;

}


impl Default for CargoCommand_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_Result::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_Result {
  type RmwMsg = super::action::rmw::CargoCommand_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        cargo_id: msg.cargo_id,
        operation_code: msg.operation_code,
        error_code: msg.error_code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      cargo_id: msg.cargo_id,
      operation_code: msg.operation_code,
      error_code: msg.error_code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      cargo_id: msg.cargo_id,
      operation_code: msg.operation_code,
      error_code: msg.error_code,
    }
  }
}


// Corresponds to master_interfaces__action__CargoCommand_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status_message: std::string::String,

}

impl CargoCommand_Feedback {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_ACCEPTED: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_PUBLISHING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_WAITING_RESPONSE: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CANCELED: u8 = 4;

}


impl Default for CargoCommand_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_Feedback {
  type RmwMsg = super::action::rmw::CargoCommand_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        status_message: msg.status_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        status_message: msg.status_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      status_message: msg.status_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__CargoCommand_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::CargoCommand_Feedback,

}



impl Default for CargoCommand_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_FeedbackMessage {
  type RmwMsg = super::action::rmw::CargoCommand_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::CargoCommand_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::CargoCommand_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::CargoCommand_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_Goal {
    /// ============ Goal ============
    /// 电梯ID string类型
    pub elevid: std::string::String,

    /// 要去的楼层
    pub target_floor: i32,

}



impl Default for ElevatorCommand_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_Goal {
  type RmwMsg = super::action::rmw::ElevatorCommand_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        elevid: msg.elevid.as_str().into(),
        target_floor: msg.target_floor,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        elevid: msg.elevid.as_str().into(),
      target_floor: msg.target_floor,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      elevid: msg.elevid.to_string(),
      target_floor: msg.target_floor,
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub final_floor: i32,

}



impl Default for ElevatorCommand_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_Result::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_Result {
  type RmwMsg = super::action::rmw::ElevatorCommand_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        final_floor: msg.final_floor,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      final_floor: msg.final_floor,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      final_floor: msg.final_floor,
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub current_floor: i32,

}



impl Default for ElevatorCommand_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_Feedback {
  type RmwMsg = super::action::rmw::ElevatorCommand_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        current_floor: msg.current_floor,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      current_floor: msg.current_floor,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      current_floor: msg.current_floor,
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::ElevatorCommand_Feedback,

}



impl Default for ElevatorCommand_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_FeedbackMessage {
  type RmwMsg = super::action::rmw::ElevatorCommand_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::ElevatorCommand_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::ElevatorCommand_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::ElevatorCommand_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_Goal {
    /// ============ Goal ============
    /// 是否启动一次占用检测
    /// true=启动检测，false=不启动
    pub enable: bool,

    /// 小车状态
    /// 进电梯=in，出电梯=out；当前占用检测只处理 in
    pub car_status: std::string::String,

}



impl Default for ElevatorOccupancyCheck_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_Goal {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        enable: msg.enable,
        car_status: msg.car_status.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      enable: msg.enable,
        car_status: msg.car_status.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      enable: msg.enable,
      car_status: msg.car_status.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_Result {
    /// true=检测完成，false=检测失败
    pub success: bool,

    /// 窗口平均占用率
    pub average_occupied_ratio: f32,

    /// 采样窗口大小
    pub window_size: i32,

    /// 实际采样数量
    pub sample_count: i32,

    /// 最后一帧占用率
    pub last_occupied_ratio: f32,

    /// 最后一帧占用栅格数
    pub last_occupied_cells: i32,

    /// 最后一帧总栅格数
    pub last_total_cells: i32,

    /// 最后一帧最大占用簇大小
    pub last_largest_cluster_cells: i32,

    /// 点云坐标系
    pub source_frame: std::string::String,

    /// ROI 中心点
    pub roi_center_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_center_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_center_z: f32,

    /// ROI 半尺寸
    pub roi_half_size_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_half_size_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_half_size_z: f32,

    /// 失败原因或补充信息
    /// JSON 或普通文本，例如 {"reason":"occupancy_action_timeout"}
    pub message: std::string::String,

}



impl Default for ElevatorOccupancyCheck_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_Result::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_Result {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        average_occupied_ratio: msg.average_occupied_ratio,
        window_size: msg.window_size,
        sample_count: msg.sample_count,
        last_occupied_ratio: msg.last_occupied_ratio,
        last_occupied_cells: msg.last_occupied_cells,
        last_total_cells: msg.last_total_cells,
        last_largest_cluster_cells: msg.last_largest_cluster_cells,
        source_frame: msg.source_frame.as_str().into(),
        roi_center_x: msg.roi_center_x,
        roi_center_y: msg.roi_center_y,
        roi_center_z: msg.roi_center_z,
        roi_half_size_x: msg.roi_half_size_x,
        roi_half_size_y: msg.roi_half_size_y,
        roi_half_size_z: msg.roi_half_size_z,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      average_occupied_ratio: msg.average_occupied_ratio,
      window_size: msg.window_size,
      sample_count: msg.sample_count,
      last_occupied_ratio: msg.last_occupied_ratio,
      last_occupied_cells: msg.last_occupied_cells,
      last_total_cells: msg.last_total_cells,
      last_largest_cluster_cells: msg.last_largest_cluster_cells,
        source_frame: msg.source_frame.as_str().into(),
      roi_center_x: msg.roi_center_x,
      roi_center_y: msg.roi_center_y,
      roi_center_z: msg.roi_center_z,
      roi_half_size_x: msg.roi_half_size_x,
      roi_half_size_y: msg.roi_half_size_y,
      roi_half_size_z: msg.roi_half_size_z,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      average_occupied_ratio: msg.average_occupied_ratio,
      window_size: msg.window_size,
      sample_count: msg.sample_count,
      last_occupied_ratio: msg.last_occupied_ratio,
      last_occupied_cells: msg.last_occupied_cells,
      last_total_cells: msg.last_total_cells,
      last_largest_cluster_cells: msg.last_largest_cluster_cells,
      source_frame: msg.source_frame.to_string(),
      roi_center_x: msg.roi_center_x,
      roi_center_y: msg.roi_center_y,
      roi_center_z: msg.roi_center_z,
      roi_half_size_x: msg.roi_half_size_x,
      roi_half_size_y: msg.roi_half_size_y,
      roi_half_size_z: msg.roi_half_size_z,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub collected_frames: i32,

    /// 目标采样帧数
    pub target_frames: i32,

    /// 当前帧占用率
    pub current_occupied_ratio: f32,

    /// 当前平均占用率
    pub current_average_occupied_ratio: f32,

    /// 进度百分比
    pub progress_percentage: f32,

    /// 状态信息
    pub status_message: std::string::String,

}



impl Default for ElevatorOccupancyCheck_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_Feedback {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        collected_frames: msg.collected_frames,
        target_frames: msg.target_frames,
        current_occupied_ratio: msg.current_occupied_ratio,
        current_average_occupied_ratio: msg.current_average_occupied_ratio,
        progress_percentage: msg.progress_percentage,
        status_message: msg.status_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      collected_frames: msg.collected_frames,
      target_frames: msg.target_frames,
      current_occupied_ratio: msg.current_occupied_ratio,
      current_average_occupied_ratio: msg.current_average_occupied_ratio,
      progress_percentage: msg.progress_percentage,
        status_message: msg.status_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      collected_frames: msg.collected_frames,
      target_frames: msg.target_frames,
      current_occupied_ratio: msg.current_occupied_ratio,
      current_average_occupied_ratio: msg.current_average_occupied_ratio,
      progress_percentage: msg.progress_percentage,
      status_message: msg.status_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::ElevatorOccupancyCheck_Feedback,

}



impl Default for ElevatorOccupancyCheck_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_FeedbackMessage {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::ElevatorOccupancyCheck_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::ElevatorOccupancyCheck_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::ElevatorOccupancyCheck_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_Goal {
    /// ============ Goal ============
    /// 电梯id必填 string类型
    pub elevid: std::string::String,

    /// 没有用填0就行
    pub door: i32,

}



impl Default for ElevatorStated_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_Goal {
  type RmwMsg = super::action::rmw::ElevatorStated_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        elevid: msg.elevid.as_str().into(),
        door: msg.door,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        elevid: msg.elevid.as_str().into(),
      door: msg.door,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      elevid: msg.elevid.to_string(),
      door: msg.door,
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 楼层号
    pub current_floor: i32,

    /// 结果信息
    pub message: std::string::String,

}



impl Default for ElevatorStated_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_Result::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_Result {
  type RmwMsg = super::action::rmw::ElevatorStated_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        current_floor: msg.current_floor,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      current_floor: msg.current_floor,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      current_floor: msg.current_floor,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub progress: i32,

}



impl Default for ElevatorStated_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_Feedback {
  type RmwMsg = super::action::rmw::ElevatorStated_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        progress: msg.progress,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      progress: msg.progress,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      progress: msg.progress,
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::ElevatorStated_Feedback,

}



impl Default for ElevatorStated_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_FeedbackMessage {
  type RmwMsg = super::action::rmw::ElevatorStated_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::ElevatorStated_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::ElevatorStated_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::ElevatorStated_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_Goal {
    /// ============ Goal ============
    /// 路径点数组
    pub waypoints: Vec<super::msg::NavigateWaypoint>,

}



impl Default for NavigateTodoor_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_Goal {
  type RmwMsg = super::action::rmw::NavigateTodoor_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoints: msg.waypoints
          .into_iter()
          .map(|elem| super::msg::NavigateWaypoint::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoints: msg.waypoints
          .iter()
          .map(|elem| super::msg::NavigateWaypoint::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      waypoints: msg.waypoints
          .into_iter()
          .map(super::msg::NavigateWaypoint::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 结果信息
    pub message: std::string::String,

    /// 总路径点数量
    pub total_waypoints: i32,

    /// 任务路径点数量
    pub task_waypoints: i32,

    /// 路径点分组数量
    pub waypoint_groups: i32,

    /// 实际完成的路径点数量
    pub completed_waypoints: i32,

    /// 总用时（秒）
    pub total_time: f32,

    /// 错误码 (0: 成功, 1: 导航失败, 2: 任务执行失败, 3: 被取消, 4: 参数错误)
    pub error_code: u8,

}

impl NavigateTodoor_Result {
    /// 错误码常量
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NAVIGATION_FAILED: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_TASK_FAILED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_PARAM: u8 = 4;

}


impl Default for NavigateTodoor_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_Result::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_Result {
  type RmwMsg = super::action::rmw::NavigateTodoor_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        total_waypoints: msg.total_waypoints,
        task_waypoints: msg.task_waypoints,
        waypoint_groups: msg.waypoint_groups,
        completed_waypoints: msg.completed_waypoints,
        total_time: msg.total_time,
        error_code: msg.error_code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      total_waypoints: msg.total_waypoints,
      task_waypoints: msg.task_waypoints,
      waypoint_groups: msg.waypoint_groups,
      completed_waypoints: msg.completed_waypoints,
      total_time: msg.total_time,
      error_code: msg.error_code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      total_waypoints: msg.total_waypoints,
      task_waypoints: msg.task_waypoints,
      waypoint_groups: msg.waypoint_groups,
      completed_waypoints: msg.completed_waypoints,
      total_time: msg.total_time,
      error_code: msg.error_code,
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: super::msg::NavigateTodoorStatus,

}



impl Default for NavigateTodoor_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_Feedback {
  type RmwMsg = super::action::rmw::NavigateTodoor_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: super::msg::NavigateTodoorStatus::into_rmw_message(std::borrow::Cow::Owned(msg.status)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: super::msg::NavigateTodoorStatus::into_rmw_message(std::borrow::Cow::Borrowed(&msg.status)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: super::msg::NavigateTodoorStatus::from_rmw_message(msg.status),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::NavigateTodoor_Feedback,

}



impl Default for NavigateTodoor_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_FeedbackMessage {
  type RmwMsg = super::action::rmw::NavigateTodoor_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::NavigateTodoor_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::NavigateTodoor_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::NavigateTodoor_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_Goal {
    /// ============ Goal ============
    pub trigger: bool,

}



impl Default for PhotoUpload_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_Goal {
  type RmwMsg = super::action::rmw::PhotoUpload_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        trigger: msg.trigger,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      trigger: msg.trigger,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      trigger: msg.trigger,
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub file_url: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_code: u8,

}

impl PhotoUpload_Result {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_IMAGE_SUBSCRIBE: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_UPLOAD_FAILED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NETWORK: u8 = 3;

}


impl Default for PhotoUpload_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_Result::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_Result {
  type RmwMsg = super::action::rmw::PhotoUpload_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        file_url: msg.file_url.as_str().into(),
        error_code: msg.error_code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
        file_url: msg.file_url.as_str().into(),
      error_code: msg.error_code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      file_url: msg.file_url.to_string(),
      error_code: msg.error_code,
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status_message: std::string::String,

}

impl PhotoUpload_Feedback {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_WAITING: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_UPLOADING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 2;

}


impl Default for PhotoUpload_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_Feedback {
  type RmwMsg = super::action::rmw::PhotoUpload_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        status_message: msg.status_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        status_message: msg.status_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      status_message: msg.status_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::PhotoUpload_Feedback,

}



impl Default for PhotoUpload_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_FeedbackMessage {
  type RmwMsg = super::action::rmw::PhotoUpload_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::PhotoUpload_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::PhotoUpload_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::PhotoUpload_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_Goal {
    /// ============ Goal ============
    /// 要播放的文本内容
    pub text: std::string::String,

    /// 音色选择 (可选, 默认使用服务器配置的默认音色)
    /// zf_xxx: 女性音色
    /// zm_xxx: 男性音色
    pub voice: std::string::String,

    /// 音量设置 (可选, 范围0-100, 默认65, 建议不低于55)
    pub volume: u8,

}



impl Default for TextToSpeech_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_Goal {
  type RmwMsg = super::action::rmw::TextToSpeech_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        text: msg.text.as_str().into(),
        voice: msg.voice.as_str().into(),
        volume: msg.volume,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        text: msg.text.as_str().into(),
        voice: msg.voice.as_str().into(),
      volume: msg.volume,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      text: msg.text.to_string(),
      voice: msg.voice.to_string(),
      volume: msg.volume,
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 结果信息
    pub message: std::string::String,

    /// 错误码 (0: 成功, 1: 网络错误, 2: 参数错误, 3: 服务不可用, 4: 被取消)
    pub error_code: u8,

}

impl TextToSpeech_Result {
    /// 错误码常量
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NETWORK: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_PARAM: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_SERVICE_UNAVAILABLE: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 4;

}


impl Default for TextToSpeech_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_Result::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_Result {
  type RmwMsg = super::action::rmw::TextToSpeech_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        error_code: msg.error_code,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      error_code: msg.error_code,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      error_code: msg.error_code,
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

    /// 状态描述信息
    pub status_message: std::string::String,

    /// 播放进度百分比 (0-100)
    pub progress: u8,

}

impl TextToSpeech_Feedback {
    /// 状态常量
    pub const STATUS_PREPARING: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_PLAYING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CANCELED: u8 = 3;

}


impl Default for TextToSpeech_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_Feedback {
  type RmwMsg = super::action::rmw::TextToSpeech_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        status_message: msg.status_message.as_str().into(),
        progress: msg.progress,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        status_message: msg.status_message.as_str().into(),
      progress: msg.progress,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      status_message: msg.status_message.to_string(),
      progress: msg.progress,
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::TextToSpeech_Feedback,

}



impl Default for TextToSpeech_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_FeedbackMessage {
  type RmwMsg = super::action::rmw::TextToSpeech_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::TextToSpeech_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::TextToSpeech_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::TextToSpeech_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Goal {
    /// ============ Goal ============
    /// 请求开启/关闭检测
    /// True=开启检测，False=关闭检测
    pub enable: bool,

    /// 小车状态，进电梯=in,出电梯=out
    pub car_status: std::string::String,

}



impl Default for VisionElevatorStatus_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Goal {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        enable: msg.enable,
        car_status: msg.car_status.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      enable: msg.enable,
        car_status: msg.car_status.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      enable: msg.enable,
      car_status: msg.car_status.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Result {
    /// 门状态：open/closed/half-open/unknown/error/timeout
    pub door_state: std::string::String,

    /// 最终置信度
    /// 检测置信度（%）
    pub confidence: f32,

    /// 操作是否成功
    /// 操作是否成功（True/False）
    pub success: bool,

    /// 结果信息
    /// 详细结果信息
    pub message: std::string::String,

}



impl Default for VisionElevatorStatus_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_Result::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Result {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        door_state: msg.door_state.as_str().into(),
        confidence: msg.confidence,
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        door_state: msg.door_state.as_str().into(),
      confidence: msg.confidence,
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      door_state: msg.door_state.to_string(),
      confidence: msg.confidence,
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub collected_frames: i32,

    /// 目标帧数
    pub target_frames: i32,

    /// 当前检测到的门状态
    pub current_state: std::string::String,

    /// 当前置信度
    pub current_confidence: f32,

    /// 进度百分比
    pub progress_percentage: f32,

    /// 状态信息
    pub status_message: std::string::String,

}



impl Default for VisionElevatorStatus_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Feedback {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        collected_frames: msg.collected_frames,
        target_frames: msg.target_frames,
        current_state: msg.current_state.as_str().into(),
        current_confidence: msg.current_confidence,
        progress_percentage: msg.progress_percentage,
        status_message: msg.status_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      collected_frames: msg.collected_frames,
      target_frames: msg.target_frames,
        current_state: msg.current_state.as_str().into(),
      current_confidence: msg.current_confidence,
      progress_percentage: msg.progress_percentage,
        status_message: msg.status_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      collected_frames: msg.collected_frames,
      target_frames: msg.target_frames,
      current_state: msg.current_state.to_string(),
      current_confidence: msg.current_confidence,
      progress_percentage: msg.progress_percentage,
      status_message: msg.status_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::VisionElevatorStatus_Feedback,

}



impl Default for VisionElevatorStatus_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_FeedbackMessage {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::VisionElevatorStatus_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::VisionElevatorStatus_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::VisionElevatorStatus_Feedback::from_rmw_message(msg.feedback),
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_Goal

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_Goal {
    /// ============ Goal ============
    /// 要播放的文本内容
    pub text: std::string::String,

    /// 模型选择 (可选, 默认为 "cosyvoice-v1")
    /// 可选模型: cosyvoice-v1, cosyvoice-v2
    pub model: std::string::String,

    /// 音色选择 (可选, 默认为 "longxiaochun")
    /// 可选音色: longxiaochun, longyuan, longwan 等
    pub voice: std::string::String,

    /// 音量设置 (可选, 范围 0-100, 默认 50)
    pub volume: u8,

    /// 语速设置 (可选, 范围 0.5-2.0, 默认 1.0)
    pub rate: f32,

    /// 音调设置 (可选, 范围 0.5-2.0, 默认 1.0)
    pub pitch: f32,

    /// 采样率 (可选, 默认 22050)
    pub sample_rate: u32,

    /// 输出音频格式 (可选, 默认 "mp3")
    /// 可选: mp3, wav, pcm
    pub format: std::string::String,

    /// 循环播放次数 (可选, 默认 1, 表示播放一次)
    /// 设置为 0 表示无限循环，设置为 n 表示播放 n 次
    pub loop_count: u32,

    /// 循环播放间隔时间 (可选, 单位: 秒, 默认 0)
    /// 当 loop_count >= 2 时生效，表示每次播放之间的间隔时间
    pub loop_interval: f32,

    /// 播放优先级 (可选, 默认 0)
    /// 0: 普通优先级，需要等待当前播放完成
    /// 1: 高优先级，立即停止当前播放并开始新播放
    pub priority: u8,

}



impl Default for WebVoicePlayer_Goal {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_Goal::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_Goal {
  type RmwMsg = super::action::rmw::WebVoicePlayer_Goal;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        text: msg.text.as_str().into(),
        model: msg.model.as_str().into(),
        voice: msg.voice.as_str().into(),
        volume: msg.volume,
        rate: msg.rate,
        pitch: msg.pitch,
        sample_rate: msg.sample_rate,
        format: msg.format.as_str().into(),
        loop_count: msg.loop_count,
        loop_interval: msg.loop_interval,
        priority: msg.priority,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        text: msg.text.as_str().into(),
        model: msg.model.as_str().into(),
        voice: msg.voice.as_str().into(),
      volume: msg.volume,
      rate: msg.rate,
      pitch: msg.pitch,
      sample_rate: msg.sample_rate,
        format: msg.format.as_str().into(),
      loop_count: msg.loop_count,
      loop_interval: msg.loop_interval,
      priority: msg.priority,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      text: msg.text.to_string(),
      model: msg.model.to_string(),
      voice: msg.voice.to_string(),
      volume: msg.volume,
      rate: msg.rate,
      pitch: msg.pitch,
      sample_rate: msg.sample_rate,
      format: msg.format.to_string(),
      loop_count: msg.loop_count,
      loop_interval: msg.loop_interval,
      priority: msg.priority,
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_Result

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 结果信息
    pub message: std::string::String,

    /// 错误码 (0: 成功, 1: 网络错误, 2: 参数错误, 3: API 认证失败, 4: 被取消, 5: 音频播放失败)
    pub error_code: u8,

    /// 合成的字符数 (用于计费统计)
    pub characters_count: u32,

    /// 音频文件路径 (如果保存到本地)
    pub audio_file_path: std::string::String,

}

impl WebVoicePlayer_Result {
    /// 错误码常量
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NETWORK: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_PARAM: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_AUTH_FAILED: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_PLAYBACK_FAILED: u8 = 5;

}


impl Default for WebVoicePlayer_Result {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_Result::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_Result {
  type RmwMsg = super::action::rmw::WebVoicePlayer_Result;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        error_code: msg.error_code,
        characters_count: msg.characters_count,
        audio_file_path: msg.audio_file_path.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      error_code: msg.error_code,
      characters_count: msg.characters_count,
        audio_file_path: msg.audio_file_path.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      error_code: msg.error_code,
      characters_count: msg.characters_count,
      audio_file_path: msg.audio_file_path.to_string(),
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_Feedback

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

    /// 状态描述信息
    pub status_message: std::string::String,

    /// 合成进度百分比 (0-100)
    pub synthesis_progress: u8,

    /// 播放进度百分比 (0-100)
    pub playback_progress: u8,

    /// 已接收的音频数据大小 (字节)
    pub audio_data_size: u32,

}

impl WebVoicePlayer_Feedback {
    /// 状态常量
    pub const STATUS_INITIALIZING: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CONNECTING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_SYNTHESIZING: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_PLAYING: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CANCELED: u8 = 5;

}


impl Default for WebVoicePlayer_Feedback {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_Feedback::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_Feedback {
  type RmwMsg = super::action::rmw::WebVoicePlayer_Feedback;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        status_message: msg.status_message.as_str().into(),
        synthesis_progress: msg.synthesis_progress,
        playback_progress: msg.playback_progress,
        audio_data_size: msg.audio_data_size,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        status_message: msg.status_message.as_str().into(),
      synthesis_progress: msg.synthesis_progress,
      playback_progress: msg.playback_progress,
      audio_data_size: msg.audio_data_size,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      status_message: msg.status_message.to_string(),
      synthesis_progress: msg.synthesis_progress,
      playback_progress: msg.playback_progress,
      audio_data_size: msg.audio_data_size,
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_FeedbackMessage

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::action::WebVoicePlayer_Feedback,

}



impl Default for WebVoicePlayer_FeedbackMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_FeedbackMessage::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_FeedbackMessage {
  type RmwMsg = super::action::rmw::WebVoicePlayer_FeedbackMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        feedback: super::action::WebVoicePlayer_Feedback::into_rmw_message(std::borrow::Cow::Owned(msg.feedback)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        feedback: super::action::WebVoicePlayer_Feedback::into_rmw_message(std::borrow::Cow::Borrowed(&msg.feedback)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      feedback: super::action::WebVoicePlayer_Feedback::from_rmw_message(msg.feedback),
    }
  }
}






// Corresponds to master_interfaces__action__CargoCommand_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::CargoCommand_Goal,

}



impl Default for CargoCommand_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_SendGoal_Request {
  type RmwMsg = super::action::rmw::CargoCommand_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::CargoCommand_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::CargoCommand_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::CargoCommand_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__CargoCommand_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for CargoCommand_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_SendGoal_Response {
  type RmwMsg = super::action::rmw::CargoCommand_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__CargoCommand_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for CargoCommand_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_GetResult_Request {
  type RmwMsg = super::action::rmw::CargoCommand_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__CargoCommand_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::CargoCommand_Result,

}



impl Default for CargoCommand_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::CargoCommand_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_GetResult_Response {
  type RmwMsg = super::action::rmw::CargoCommand_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::CargoCommand_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::CargoCommand_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::CargoCommand_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::ElevatorCommand_Goal,

}



impl Default for ElevatorCommand_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_SendGoal_Request {
  type RmwMsg = super::action::rmw::ElevatorCommand_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::ElevatorCommand_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::ElevatorCommand_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::ElevatorCommand_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for ElevatorCommand_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_SendGoal_Response {
  type RmwMsg = super::action::rmw::ElevatorCommand_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for ElevatorCommand_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_GetResult_Request {
  type RmwMsg = super::action::rmw::ElevatorCommand_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorCommand_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::ElevatorCommand_Result,

}



impl Default for ElevatorCommand_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorCommand_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_GetResult_Response {
  type RmwMsg = super::action::rmw::ElevatorCommand_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::ElevatorCommand_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::ElevatorCommand_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::ElevatorCommand_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::ElevatorOccupancyCheck_Goal,

}



impl Default for ElevatorOccupancyCheck_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_SendGoal_Request {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::ElevatorOccupancyCheck_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::ElevatorOccupancyCheck_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::ElevatorOccupancyCheck_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for ElevatorOccupancyCheck_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_SendGoal_Response {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for ElevatorOccupancyCheck_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_GetResult_Request {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::ElevatorOccupancyCheck_Result,

}



impl Default for ElevatorOccupancyCheck_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorOccupancyCheck_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_GetResult_Response {
  type RmwMsg = super::action::rmw::ElevatorOccupancyCheck_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::ElevatorOccupancyCheck_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::ElevatorOccupancyCheck_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::ElevatorOccupancyCheck_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::ElevatorStated_Goal,

}



impl Default for ElevatorStated_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_SendGoal_Request {
  type RmwMsg = super::action::rmw::ElevatorStated_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::ElevatorStated_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::ElevatorStated_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::ElevatorStated_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for ElevatorStated_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_SendGoal_Response {
  type RmwMsg = super::action::rmw::ElevatorStated_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for ElevatorStated_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_GetResult_Request {
  type RmwMsg = super::action::rmw::ElevatorStated_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__ElevatorStated_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::ElevatorStated_Result,

}



impl Default for ElevatorStated_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::ElevatorStated_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_GetResult_Response {
  type RmwMsg = super::action::rmw::ElevatorStated_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::ElevatorStated_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::ElevatorStated_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::ElevatorStated_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::NavigateTodoor_Goal,

}



impl Default for NavigateTodoor_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_SendGoal_Request {
  type RmwMsg = super::action::rmw::NavigateTodoor_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::NavigateTodoor_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::NavigateTodoor_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::NavigateTodoor_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for NavigateTodoor_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_SendGoal_Response {
  type RmwMsg = super::action::rmw::NavigateTodoor_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for NavigateTodoor_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_GetResult_Request {
  type RmwMsg = super::action::rmw::NavigateTodoor_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__NavigateTodoor_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::NavigateTodoor_Result,

}



impl Default for NavigateTodoor_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::NavigateTodoor_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_GetResult_Response {
  type RmwMsg = super::action::rmw::NavigateTodoor_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::NavigateTodoor_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::NavigateTodoor_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::NavigateTodoor_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::PhotoUpload_Goal,

}



impl Default for PhotoUpload_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_SendGoal_Request {
  type RmwMsg = super::action::rmw::PhotoUpload_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::PhotoUpload_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::PhotoUpload_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::PhotoUpload_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for PhotoUpload_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_SendGoal_Response {
  type RmwMsg = super::action::rmw::PhotoUpload_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for PhotoUpload_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_GetResult_Request {
  type RmwMsg = super::action::rmw::PhotoUpload_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__PhotoUpload_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::PhotoUpload_Result,

}



impl Default for PhotoUpload_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::PhotoUpload_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_GetResult_Response {
  type RmwMsg = super::action::rmw::PhotoUpload_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::PhotoUpload_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::PhotoUpload_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::PhotoUpload_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::TextToSpeech_Goal,

}



impl Default for TextToSpeech_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_SendGoal_Request {
  type RmwMsg = super::action::rmw::TextToSpeech_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::TextToSpeech_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::TextToSpeech_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::TextToSpeech_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for TextToSpeech_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_SendGoal_Response {
  type RmwMsg = super::action::rmw::TextToSpeech_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for TextToSpeech_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_GetResult_Request {
  type RmwMsg = super::action::rmw::TextToSpeech_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__TextToSpeech_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::TextToSpeech_Result,

}



impl Default for TextToSpeech_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::TextToSpeech_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_GetResult_Response {
  type RmwMsg = super::action::rmw::TextToSpeech_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::TextToSpeech_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::TextToSpeech_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::TextToSpeech_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::VisionElevatorStatus_Goal,

}



impl Default for VisionElevatorStatus_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_SendGoal_Request {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::VisionElevatorStatus_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::VisionElevatorStatus_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::VisionElevatorStatus_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for VisionElevatorStatus_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_SendGoal_Response {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for VisionElevatorStatus_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_GetResult_Request {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__VisionElevatorStatus_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::VisionElevatorStatus_Result,

}



impl Default for VisionElevatorStatus_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::VisionElevatorStatus_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_GetResult_Response {
  type RmwMsg = super::action::rmw::VisionElevatorStatus_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::VisionElevatorStatus_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::VisionElevatorStatus_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::VisionElevatorStatus_Result::from_rmw_message(msg.result),
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_SendGoal_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::action::WebVoicePlayer_Goal,

}



impl Default for WebVoicePlayer_SendGoal_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_SendGoal_Request::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_SendGoal_Request {
  type RmwMsg = super::action::rmw::WebVoicePlayer_SendGoal_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
        goal: super::action::WebVoicePlayer_Goal::into_rmw_message(std::borrow::Cow::Owned(msg.goal)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
        goal: super::action::WebVoicePlayer_Goal::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
      goal: super::action::WebVoicePlayer_Goal::from_rmw_message(msg.goal),
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_SendGoal_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for WebVoicePlayer_SendGoal_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_SendGoal_Response::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_SendGoal_Response {
  type RmwMsg = super::action::rmw::WebVoicePlayer_SendGoal_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      accepted: msg.accepted,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      accepted: msg.accepted,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_GetResult_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::UUID,

}



impl Default for WebVoicePlayer_GetResult_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_GetResult_Request::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_GetResult_Request {
  type RmwMsg = super::action::rmw::WebVoicePlayer_GetResult_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Owned(msg.goal_id)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        goal_id: unique_identifier_msgs::msg::UUID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.goal_id)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      goal_id: unique_identifier_msgs::msg::UUID::from_rmw_message(msg.goal_id),
    }
  }
}


// Corresponds to master_interfaces__action__WebVoicePlayer_GetResult_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::action::WebVoicePlayer_Result,

}



impl Default for WebVoicePlayer_GetResult_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::action::rmw::WebVoicePlayer_GetResult_Response::default())
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_GetResult_Response {
  type RmwMsg = super::action::rmw::WebVoicePlayer_GetResult_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status,
        result: super::action::WebVoicePlayer_Result::into_rmw_message(std::borrow::Cow::Owned(msg.result)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      status: msg.status,
        result: super::action::WebVoicePlayer_Result::into_rmw_message(std::borrow::Cow::Borrowed(&msg.result)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status,
      result: super::action::WebVoicePlayer_Result::from_rmw_message(msg.result),
    }
  }
}






#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__CargoCommand_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct CargoCommand_SendGoal;

impl rosidl_runtime_rs::Service for CargoCommand_SendGoal {
    type Request = CargoCommand_SendGoal_Request;
    type Response = CargoCommand_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__CargoCommand_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct CargoCommand_GetResult;

impl rosidl_runtime_rs::Service for CargoCommand_GetResult {
    type Request = CargoCommand_GetResult_Request;
    type Response = CargoCommand_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorCommand_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorCommand_SendGoal;

impl rosidl_runtime_rs::Service for ElevatorCommand_SendGoal {
    type Request = ElevatorCommand_SendGoal_Request;
    type Response = ElevatorCommand_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorCommand_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorCommand_GetResult;

impl rosidl_runtime_rs::Service for ElevatorCommand_GetResult {
    type Request = ElevatorCommand_GetResult_Request;
    type Response = ElevatorCommand_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorOccupancyCheck_SendGoal;

impl rosidl_runtime_rs::Service for ElevatorOccupancyCheck_SendGoal {
    type Request = ElevatorOccupancyCheck_SendGoal_Request;
    type Response = ElevatorOccupancyCheck_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorOccupancyCheck_GetResult;

impl rosidl_runtime_rs::Service for ElevatorOccupancyCheck_GetResult {
    type Request = ElevatorOccupancyCheck_GetResult_Request;
    type Response = ElevatorOccupancyCheck_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorStated_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorStated_SendGoal;

impl rosidl_runtime_rs::Service for ElevatorStated_SendGoal {
    type Request = ElevatorStated_SendGoal_Request;
    type Response = ElevatorStated_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorStated_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorStated_GetResult;

impl rosidl_runtime_rs::Service for ElevatorStated_GetResult {
    type Request = ElevatorStated_GetResult_Request;
    type Response = ElevatorStated_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__NavigateTodoor_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateTodoor_SendGoal;

impl rosidl_runtime_rs::Service for NavigateTodoor_SendGoal {
    type Request = NavigateTodoor_SendGoal_Request;
    type Response = NavigateTodoor_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__NavigateTodoor_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateTodoor_GetResult;

impl rosidl_runtime_rs::Service for NavigateTodoor_GetResult {
    type Request = NavigateTodoor_GetResult_Request;
    type Response = NavigateTodoor_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__PhotoUpload_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct PhotoUpload_SendGoal;

impl rosidl_runtime_rs::Service for PhotoUpload_SendGoal {
    type Request = PhotoUpload_SendGoal_Request;
    type Response = PhotoUpload_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__PhotoUpload_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct PhotoUpload_GetResult;

impl rosidl_runtime_rs::Service for PhotoUpload_GetResult {
    type Request = PhotoUpload_GetResult_Request;
    type Response = PhotoUpload_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__TextToSpeech_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct TextToSpeech_SendGoal;

impl rosidl_runtime_rs::Service for TextToSpeech_SendGoal {
    type Request = TextToSpeech_SendGoal_Request;
    type Response = TextToSpeech_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__TextToSpeech_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct TextToSpeech_GetResult;

impl rosidl_runtime_rs::Service for TextToSpeech_GetResult {
    type Request = TextToSpeech_GetResult_Request;
    type Response = TextToSpeech_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus_SendGoal;

impl rosidl_runtime_rs::Service for VisionElevatorStatus_SendGoal {
    type Request = VisionElevatorStatus_SendGoal_Request;
    type Response = VisionElevatorStatus_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus_GetResult;

impl rosidl_runtime_rs::Service for VisionElevatorStatus_GetResult {
    type Request = VisionElevatorStatus_GetResult_Request;
    type Response = VisionElevatorStatus_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct WebVoicePlayer_SendGoal;

impl rosidl_runtime_rs::Service for WebVoicePlayer_SendGoal {
    type Request = WebVoicePlayer_SendGoal_Request;
    type Response = WebVoicePlayer_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct WebVoicePlayer_GetResult;

impl rosidl_runtime_rs::Service for WebVoicePlayer_GetResult {
    type Request = WebVoicePlayer_GetResult_Request;
    type Response = WebVoicePlayer_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult() }
    }
}






#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__CargoCommand() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__CargoCommand
#[allow(missing_docs, non_camel_case_types)]
pub struct CargoCommand;

impl rosidl_runtime_rs::Action for CargoCommand {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = CargoCommand_Goal;

  /// The result message defined in the action definition.
  type Result = CargoCommand_Result;

  /// The feedback message defined in the action definition.
  type Feedback = CargoCommand_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::CargoCommand_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::CargoCommand_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::CargoCommand_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__CargoCommand() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::CargoCommand_Goal,
  ) -> super::action::rmw::CargoCommand_SendGoal_Request {
   super::action::rmw::CargoCommand_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::CargoCommand_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::CargoCommand_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::CargoCommand_SendGoal_Response {
   super::action::rmw::CargoCommand_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::CargoCommand_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::CargoCommand_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::CargoCommand_Feedback,
  ) -> super::action::rmw::CargoCommand_FeedbackMessage {
    let mut message = super::action::rmw::CargoCommand_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::CargoCommand_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::CargoCommand_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::CargoCommand_GetResult_Request {
   super::action::rmw::CargoCommand_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::CargoCommand_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::CargoCommand_Result,
  ) -> super::action::rmw::CargoCommand_GetResult_Response {
   super::action::rmw::CargoCommand_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::CargoCommand_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::CargoCommand_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__ElevatorCommand() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorCommand
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorCommand;

impl rosidl_runtime_rs::Action for ElevatorCommand {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = ElevatorCommand_Goal;

  /// The result message defined in the action definition.
  type Result = ElevatorCommand_Result;

  /// The feedback message defined in the action definition.
  type Feedback = ElevatorCommand_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::ElevatorCommand_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::ElevatorCommand_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::ElevatorCommand_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__ElevatorCommand() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::ElevatorCommand_Goal,
  ) -> super::action::rmw::ElevatorCommand_SendGoal_Request {
   super::action::rmw::ElevatorCommand_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::ElevatorCommand_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::ElevatorCommand_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::ElevatorCommand_SendGoal_Response {
   super::action::rmw::ElevatorCommand_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::ElevatorCommand_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::ElevatorCommand_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::ElevatorCommand_Feedback,
  ) -> super::action::rmw::ElevatorCommand_FeedbackMessage {
    let mut message = super::action::rmw::ElevatorCommand_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::ElevatorCommand_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::ElevatorCommand_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::ElevatorCommand_GetResult_Request {
   super::action::rmw::ElevatorCommand_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::ElevatorCommand_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::ElevatorCommand_Result,
  ) -> super::action::rmw::ElevatorCommand_GetResult_Response {
   super::action::rmw::ElevatorCommand_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::ElevatorCommand_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::ElevatorCommand_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorOccupancyCheck;

impl rosidl_runtime_rs::Action for ElevatorOccupancyCheck {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = ElevatorOccupancyCheck_Goal;

  /// The result message defined in the action definition.
  type Result = ElevatorOccupancyCheck_Result;

  /// The feedback message defined in the action definition.
  type Feedback = ElevatorOccupancyCheck_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::ElevatorOccupancyCheck_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::ElevatorOccupancyCheck_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::ElevatorOccupancyCheck_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::ElevatorOccupancyCheck_Goal,
  ) -> super::action::rmw::ElevatorOccupancyCheck_SendGoal_Request {
   super::action::rmw::ElevatorOccupancyCheck_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::ElevatorOccupancyCheck_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::ElevatorOccupancyCheck_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::ElevatorOccupancyCheck_SendGoal_Response {
   super::action::rmw::ElevatorOccupancyCheck_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::ElevatorOccupancyCheck_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::ElevatorOccupancyCheck_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::ElevatorOccupancyCheck_Feedback,
  ) -> super::action::rmw::ElevatorOccupancyCheck_FeedbackMessage {
    let mut message = super::action::rmw::ElevatorOccupancyCheck_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::ElevatorOccupancyCheck_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::ElevatorOccupancyCheck_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::ElevatorOccupancyCheck_GetResult_Request {
   super::action::rmw::ElevatorOccupancyCheck_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::ElevatorOccupancyCheck_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::ElevatorOccupancyCheck_Result,
  ) -> super::action::rmw::ElevatorOccupancyCheck_GetResult_Response {
   super::action::rmw::ElevatorOccupancyCheck_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::ElevatorOccupancyCheck_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::ElevatorOccupancyCheck_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__ElevatorStated() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorStated
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorStated;

impl rosidl_runtime_rs::Action for ElevatorStated {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = ElevatorStated_Goal;

  /// The result message defined in the action definition.
  type Result = ElevatorStated_Result;

  /// The feedback message defined in the action definition.
  type Feedback = ElevatorStated_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::ElevatorStated_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::ElevatorStated_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::ElevatorStated_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__ElevatorStated() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::ElevatorStated_Goal,
  ) -> super::action::rmw::ElevatorStated_SendGoal_Request {
   super::action::rmw::ElevatorStated_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::ElevatorStated_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::ElevatorStated_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::ElevatorStated_SendGoal_Response {
   super::action::rmw::ElevatorStated_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::ElevatorStated_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::ElevatorStated_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::ElevatorStated_Feedback,
  ) -> super::action::rmw::ElevatorStated_FeedbackMessage {
    let mut message = super::action::rmw::ElevatorStated_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::ElevatorStated_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::ElevatorStated_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::ElevatorStated_GetResult_Request {
   super::action::rmw::ElevatorStated_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::ElevatorStated_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::ElevatorStated_Result,
  ) -> super::action::rmw::ElevatorStated_GetResult_Response {
   super::action::rmw::ElevatorStated_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::ElevatorStated_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::ElevatorStated_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__NavigateTodoor() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__NavigateTodoor
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateTodoor;

impl rosidl_runtime_rs::Action for NavigateTodoor {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = NavigateTodoor_Goal;

  /// The result message defined in the action definition.
  type Result = NavigateTodoor_Result;

  /// The feedback message defined in the action definition.
  type Feedback = NavigateTodoor_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::NavigateTodoor_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::NavigateTodoor_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::NavigateTodoor_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__NavigateTodoor() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::NavigateTodoor_Goal,
  ) -> super::action::rmw::NavigateTodoor_SendGoal_Request {
   super::action::rmw::NavigateTodoor_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::NavigateTodoor_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::NavigateTodoor_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::NavigateTodoor_SendGoal_Response {
   super::action::rmw::NavigateTodoor_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::NavigateTodoor_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::NavigateTodoor_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::NavigateTodoor_Feedback,
  ) -> super::action::rmw::NavigateTodoor_FeedbackMessage {
    let mut message = super::action::rmw::NavigateTodoor_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::NavigateTodoor_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::NavigateTodoor_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::NavigateTodoor_GetResult_Request {
   super::action::rmw::NavigateTodoor_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::NavigateTodoor_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::NavigateTodoor_Result,
  ) -> super::action::rmw::NavigateTodoor_GetResult_Response {
   super::action::rmw::NavigateTodoor_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::NavigateTodoor_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::NavigateTodoor_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__PhotoUpload() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__PhotoUpload
#[allow(missing_docs, non_camel_case_types)]
pub struct PhotoUpload;

impl rosidl_runtime_rs::Action for PhotoUpload {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = PhotoUpload_Goal;

  /// The result message defined in the action definition.
  type Result = PhotoUpload_Result;

  /// The feedback message defined in the action definition.
  type Feedback = PhotoUpload_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::PhotoUpload_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::PhotoUpload_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::PhotoUpload_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__PhotoUpload() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::PhotoUpload_Goal,
  ) -> super::action::rmw::PhotoUpload_SendGoal_Request {
   super::action::rmw::PhotoUpload_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::PhotoUpload_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::PhotoUpload_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::PhotoUpload_SendGoal_Response {
   super::action::rmw::PhotoUpload_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::PhotoUpload_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::PhotoUpload_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::PhotoUpload_Feedback,
  ) -> super::action::rmw::PhotoUpload_FeedbackMessage {
    let mut message = super::action::rmw::PhotoUpload_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::PhotoUpload_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::PhotoUpload_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::PhotoUpload_GetResult_Request {
   super::action::rmw::PhotoUpload_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::PhotoUpload_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::PhotoUpload_Result,
  ) -> super::action::rmw::PhotoUpload_GetResult_Response {
   super::action::rmw::PhotoUpload_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::PhotoUpload_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::PhotoUpload_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__TextToSpeech() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__TextToSpeech
#[allow(missing_docs, non_camel_case_types)]
pub struct TextToSpeech;

impl rosidl_runtime_rs::Action for TextToSpeech {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = TextToSpeech_Goal;

  /// The result message defined in the action definition.
  type Result = TextToSpeech_Result;

  /// The feedback message defined in the action definition.
  type Feedback = TextToSpeech_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::TextToSpeech_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::TextToSpeech_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::TextToSpeech_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__TextToSpeech() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::TextToSpeech_Goal,
  ) -> super::action::rmw::TextToSpeech_SendGoal_Request {
   super::action::rmw::TextToSpeech_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::TextToSpeech_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::TextToSpeech_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::TextToSpeech_SendGoal_Response {
   super::action::rmw::TextToSpeech_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::TextToSpeech_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::TextToSpeech_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::TextToSpeech_Feedback,
  ) -> super::action::rmw::TextToSpeech_FeedbackMessage {
    let mut message = super::action::rmw::TextToSpeech_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::TextToSpeech_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::TextToSpeech_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::TextToSpeech_GetResult_Request {
   super::action::rmw::TextToSpeech_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::TextToSpeech_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::TextToSpeech_Result,
  ) -> super::action::rmw::TextToSpeech_GetResult_Response {
   super::action::rmw::TextToSpeech_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::TextToSpeech_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::TextToSpeech_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__VisionElevatorStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus;

impl rosidl_runtime_rs::Action for VisionElevatorStatus {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = VisionElevatorStatus_Goal;

  /// The result message defined in the action definition.
  type Result = VisionElevatorStatus_Result;

  /// The feedback message defined in the action definition.
  type Feedback = VisionElevatorStatus_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::VisionElevatorStatus_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::VisionElevatorStatus_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::VisionElevatorStatus_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__VisionElevatorStatus() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::VisionElevatorStatus_Goal,
  ) -> super::action::rmw::VisionElevatorStatus_SendGoal_Request {
   super::action::rmw::VisionElevatorStatus_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::VisionElevatorStatus_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::VisionElevatorStatus_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::VisionElevatorStatus_SendGoal_Response {
   super::action::rmw::VisionElevatorStatus_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::VisionElevatorStatus_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::VisionElevatorStatus_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::VisionElevatorStatus_Feedback,
  ) -> super::action::rmw::VisionElevatorStatus_FeedbackMessage {
    let mut message = super::action::rmw::VisionElevatorStatus_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::VisionElevatorStatus_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::VisionElevatorStatus_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::VisionElevatorStatus_GetResult_Request {
   super::action::rmw::VisionElevatorStatus_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::VisionElevatorStatus_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::VisionElevatorStatus_Result,
  ) -> super::action::rmw::VisionElevatorStatus_GetResult_Response {
   super::action::rmw::VisionElevatorStatus_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::VisionElevatorStatus_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::VisionElevatorStatus_Result,
  ) {
    (response.status, response.result)
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__WebVoicePlayer() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__WebVoicePlayer
#[allow(missing_docs, non_camel_case_types)]
pub struct WebVoicePlayer;

impl rosidl_runtime_rs::Action for WebVoicePlayer {
  // --- Associated types for client library users ---
  /// The goal message defined in the action definition.
  type Goal = WebVoicePlayer_Goal;

  /// The result message defined in the action definition.
  type Result = WebVoicePlayer_Result;

  /// The feedback message defined in the action definition.
  type Feedback = WebVoicePlayer_Feedback;

  // --- Associated types for client library implementation ---
  /// The feedback message with generic fields which wraps the feedback message.
  type FeedbackMessage = super::action::WebVoicePlayer_FeedbackMessage;

  /// The send_goal service using a wrapped version of the goal message as a request.
  type SendGoalService = super::action::WebVoicePlayer_SendGoal;

  /// The generic service to cancel a goal.
  type CancelGoalService = action_msgs::srv::rmw::CancelGoal;

  /// The get_result service using a wrapped version of the result message as a response.
  type GetResultService = super::action::WebVoicePlayer_GetResult;

  // --- Methods for client library implementation ---
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_action_type_support_handle__master_interfaces__action__WebVoicePlayer() }
  }

  fn create_goal_request(
    goal_id: &[u8; 16],
    goal: super::action::rmw::WebVoicePlayer_Goal,
  ) -> super::action::rmw::WebVoicePlayer_SendGoal_Request {
   super::action::rmw::WebVoicePlayer_SendGoal_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
      goal,
    }
  }

  fn split_goal_request(
    request: super::action::rmw::WebVoicePlayer_SendGoal_Request,
  ) -> (
    [u8; 16],
   super::action::rmw::WebVoicePlayer_Goal,
  ) {
    (request.goal_id.uuid, request.goal)
  }

  fn create_goal_response(
    accepted: bool,
    stamp: (i32, u32),
  ) -> super::action::rmw::WebVoicePlayer_SendGoal_Response {
   super::action::rmw::WebVoicePlayer_SendGoal_Response {
      accepted,
      stamp: builtin_interfaces::msg::rmw::Time {
        sec: stamp.0,
        nanosec: stamp.1,
      },
    }
  }

  fn get_goal_response_accepted(
    response: &super::action::rmw::WebVoicePlayer_SendGoal_Response,
  ) -> bool {
    response.accepted
  }

  fn get_goal_response_stamp(
    response: &super::action::rmw::WebVoicePlayer_SendGoal_Response,
  ) -> (i32, u32) {
    (response.stamp.sec, response.stamp.nanosec)
  }

  fn create_feedback_message(
    goal_id: &[u8; 16],
    feedback: super::action::rmw::WebVoicePlayer_Feedback,
  ) -> super::action::rmw::WebVoicePlayer_FeedbackMessage {
    let mut message = super::action::rmw::WebVoicePlayer_FeedbackMessage::default();
    message.goal_id.uuid = *goal_id;
    message.feedback = feedback;
    message
  }

  fn split_feedback_message(
    feedback: super::action::rmw::WebVoicePlayer_FeedbackMessage,
  ) -> (
    [u8; 16],
   super::action::rmw::WebVoicePlayer_Feedback,
  ) {
    (feedback.goal_id.uuid, feedback.feedback)
  }

  fn create_result_request(
    goal_id: &[u8; 16],
  ) -> super::action::rmw::WebVoicePlayer_GetResult_Request {
   super::action::rmw::WebVoicePlayer_GetResult_Request {
      goal_id: unique_identifier_msgs::msg::rmw::UUID { uuid: *goal_id },
    }
  }

  fn get_result_request_uuid(
    request: &super::action::rmw::WebVoicePlayer_GetResult_Request,
  ) -> &[u8; 16] {
    &request.goal_id.uuid
  }

  fn create_result_response(
    status: i8,
    result: super::action::rmw::WebVoicePlayer_Result,
  ) -> super::action::rmw::WebVoicePlayer_GetResult_Response {
   super::action::rmw::WebVoicePlayer_GetResult_Response {
      status,
      result,
    }
  }

  fn split_result_response(
    response: super::action::rmw::WebVoicePlayer_GetResult_Response
  ) -> (
    i8,
   super::action::rmw::WebVoicePlayer_Result,
  ) {
    (response.status, response.result)
  }
}


