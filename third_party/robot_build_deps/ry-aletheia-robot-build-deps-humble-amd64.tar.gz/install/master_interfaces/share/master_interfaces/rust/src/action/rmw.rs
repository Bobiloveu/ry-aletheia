
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_Goal__init(msg: *mut CargoCommand_Goal) -> bool;
    fn master_interfaces__action__CargoCommand_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Goal>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Goal>);
    fn master_interfaces__action__CargoCommand_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_Goal {
    /// ============ Goal ============
    pub cargo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub operation_code: u8,

}

impl CargoCommand_Goal {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_UPPER: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_LOWER: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_MANUAL_OPEN: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_MANUAL_CLOSE: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_AUTO_UNLOAD: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const OP_RESET: u8 = 3;

}


impl Default for CargoCommand_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_Result__init(msg: *mut CargoCommand_Result) -> bool;
    fn master_interfaces__action__CargoCommand_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Result>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Result>);
    fn master_interfaces__action__CargoCommand_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Result>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub operation_code: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_code: u8,

}

impl CargoCommand_Result {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_GOAL: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_BUSY: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_MQTT_UNAVAILABLE: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_PUBLISH_FAILED: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_TIMEOUT: u8 = 5;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_RESPONSE_MISMATCH: u8 = 6;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_RESPONSE_INVALID: u8 = 7;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 8;

}


impl Default for CargoCommand_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_Feedback__init(msg: *mut CargoCommand_Feedback) -> bool;
    fn master_interfaces__action__CargoCommand_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Feedback>);
    fn master_interfaces__action__CargoCommand_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status_message: rosidl_runtime_rs::String,

}

impl CargoCommand_Feedback {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_ACCEPTED: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_PUBLISHING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_WAITING_RESPONSE: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CANCELED: u8 = 4;

}


impl Default for CargoCommand_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_FeedbackMessage__init(msg: *mut CargoCommand_FeedbackMessage) -> bool;
    fn master_interfaces__action__CargoCommand_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_FeedbackMessage>);
    fn master_interfaces__action__CargoCommand_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::CargoCommand_Feedback,

}



impl Default for CargoCommand_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_Goal__init(msg: *mut ElevatorCommand_Goal) -> bool;
    fn master_interfaces__action__ElevatorCommand_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Goal>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Goal>);
    fn master_interfaces__action__ElevatorCommand_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_Goal {
    /// ============ Goal ============
    /// 电梯ID string类型
    pub elevid: rosidl_runtime_rs::String,

    /// 要去的楼层
    pub target_floor: i32,

}



impl Default for ElevatorCommand_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_Result__init(msg: *mut ElevatorCommand_Result) -> bool;
    fn master_interfaces__action__ElevatorCommand_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Result>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Result>);
    fn master_interfaces__action__ElevatorCommand_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Result>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub final_floor: i32,

}



impl Default for ElevatorCommand_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_Feedback__init(msg: *mut ElevatorCommand_Feedback) -> bool;
    fn master_interfaces__action__ElevatorCommand_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Feedback>);
    fn master_interfaces__action__ElevatorCommand_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub current_floor: i32,

}



impl Default for ElevatorCommand_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_FeedbackMessage__init(msg: *mut ElevatorCommand_FeedbackMessage) -> bool;
    fn master_interfaces__action__ElevatorCommand_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_FeedbackMessage>);
    fn master_interfaces__action__ElevatorCommand_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::ElevatorCommand_Feedback,

}



impl Default for ElevatorCommand_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_Goal__init(msg: *mut ElevatorOccupancyCheck_Goal) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Goal>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Goal>);
    fn master_interfaces__action__ElevatorOccupancyCheck_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_Goal {
    /// ============ Goal ============
    /// 是否启动一次占用检测
    /// true=启动检测，false=不启动
    pub enable: bool,

    /// 小车状态
    /// 进电梯=in，出电梯=out；当前占用检测只处理 in
    pub car_status: rosidl_runtime_rs::String,

}



impl Default for ElevatorOccupancyCheck_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_Result__init(msg: *mut ElevatorOccupancyCheck_Result) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Result>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Result>);
    fn master_interfaces__action__ElevatorOccupancyCheck_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Result>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_Result {
    /// true=检测完成，false=检测失败
    pub success: bool,

    /// 窗口平均占用率
    pub average_occupied_ratio: f32,

    /// 采样窗口大小
    pub window_size: i32,

    /// 实际采样数量
    pub sample_count: i32,

    /// 最后一帧占用率
    pub last_occupied_ratio: f32,

    /// 最后一帧占用栅格数
    pub last_occupied_cells: i32,

    /// 最后一帧总栅格数
    pub last_total_cells: i32,

    /// 最后一帧最大占用簇大小
    pub last_largest_cluster_cells: i32,

    /// 点云坐标系
    pub source_frame: rosidl_runtime_rs::String,

    /// ROI 中心点
    pub roi_center_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_center_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_center_z: f32,

    /// ROI 半尺寸
    pub roi_half_size_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_half_size_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roi_half_size_z: f32,

    /// 失败原因或补充信息
    /// JSON 或普通文本，例如 {"reason":"occupancy_action_timeout"}
    pub message: rosidl_runtime_rs::String,

}



impl Default for ElevatorOccupancyCheck_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_Feedback__init(msg: *mut ElevatorOccupancyCheck_Feedback) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Feedback>);
    fn master_interfaces__action__ElevatorOccupancyCheck_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub collected_frames: i32,

    /// 目标采样帧数
    pub target_frames: i32,

    /// 当前帧占用率
    pub current_occupied_ratio: f32,

    /// 当前平均占用率
    pub current_average_occupied_ratio: f32,

    /// 进度百分比
    pub progress_percentage: f32,

    /// 状态信息
    pub status_message: rosidl_runtime_rs::String,

}



impl Default for ElevatorOccupancyCheck_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__init(msg: *mut ElevatorOccupancyCheck_FeedbackMessage) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_FeedbackMessage>);
    fn master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::ElevatorOccupancyCheck_Feedback,

}



impl Default for ElevatorOccupancyCheck_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_Goal__init(msg: *mut ElevatorStated_Goal) -> bool;
    fn master_interfaces__action__ElevatorStated_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Goal>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Goal>);
    fn master_interfaces__action__ElevatorStated_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_Goal {
    /// ============ Goal ============
    /// 电梯id必填 string类型
    pub elevid: rosidl_runtime_rs::String,

    /// 没有用填0就行
    pub door: i32,

}



impl Default for ElevatorStated_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_Result__init(msg: *mut ElevatorStated_Result) -> bool;
    fn master_interfaces__action__ElevatorStated_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Result>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Result>);
    fn master_interfaces__action__ElevatorStated_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Result>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 楼层号
    pub current_floor: i32,

    /// 结果信息
    pub message: rosidl_runtime_rs::String,

}



impl Default for ElevatorStated_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_Feedback__init(msg: *mut ElevatorStated_Feedback) -> bool;
    fn master_interfaces__action__ElevatorStated_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Feedback>);
    fn master_interfaces__action__ElevatorStated_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub progress: i32,

}



impl Default for ElevatorStated_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_FeedbackMessage__init(msg: *mut ElevatorStated_FeedbackMessage) -> bool;
    fn master_interfaces__action__ElevatorStated_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_FeedbackMessage>);
    fn master_interfaces__action__ElevatorStated_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::ElevatorStated_Feedback,

}



impl Default for ElevatorStated_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_Goal__init(msg: *mut NavigateTodoor_Goal) -> bool;
    fn master_interfaces__action__NavigateTodoor_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Goal>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Goal>);
    fn master_interfaces__action__NavigateTodoor_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_Goal {
    /// ============ Goal ============
    /// 路径点数组
    pub waypoints: rosidl_runtime_rs::Sequence<super::super::msg::rmw::NavigateWaypoint>,

}



impl Default for NavigateTodoor_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_Result__init(msg: *mut NavigateTodoor_Result) -> bool;
    fn master_interfaces__action__NavigateTodoor_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Result>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Result>);
    fn master_interfaces__action__NavigateTodoor_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Result>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 结果信息
    pub message: rosidl_runtime_rs::String,

    /// 总路径点数量
    pub total_waypoints: i32,

    /// 任务路径点数量
    pub task_waypoints: i32,

    /// 路径点分组数量
    pub waypoint_groups: i32,

    /// 实际完成的路径点数量
    pub completed_waypoints: i32,

    /// 总用时（秒）
    pub total_time: f32,

    /// 错误码 (0: 成功, 1: 导航失败, 2: 任务执行失败, 3: 被取消, 4: 参数错误)
    pub error_code: u8,

}

impl NavigateTodoor_Result {
    /// 错误码常量
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NAVIGATION_FAILED: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_TASK_FAILED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_PARAM: u8 = 4;

}


impl Default for NavigateTodoor_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_Feedback__init(msg: *mut NavigateTodoor_Feedback) -> bool;
    fn master_interfaces__action__NavigateTodoor_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Feedback>);
    fn master_interfaces__action__NavigateTodoor_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: super::super::msg::rmw::NavigateTodoorStatus,

}



impl Default for NavigateTodoor_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_FeedbackMessage__init(msg: *mut NavigateTodoor_FeedbackMessage) -> bool;
    fn master_interfaces__action__NavigateTodoor_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_FeedbackMessage>);
    fn master_interfaces__action__NavigateTodoor_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::NavigateTodoor_Feedback,

}



impl Default for NavigateTodoor_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_Goal__init(msg: *mut PhotoUpload_Goal) -> bool;
    fn master_interfaces__action__PhotoUpload_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Goal>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Goal>);
    fn master_interfaces__action__PhotoUpload_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_Goal {
    /// ============ Goal ============
    pub trigger: bool,

}



impl Default for PhotoUpload_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_Result__init(msg: *mut PhotoUpload_Result) -> bool;
    fn master_interfaces__action__PhotoUpload_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Result>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Result>);
    fn master_interfaces__action__PhotoUpload_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Result>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub file_url: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_code: u8,

}

impl PhotoUpload_Result {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_IMAGE_SUBSCRIBE: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_UPLOAD_FAILED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NETWORK: u8 = 3;

}


impl Default for PhotoUpload_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_Feedback__init(msg: *mut PhotoUpload_Feedback) -> bool;
    fn master_interfaces__action__PhotoUpload_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Feedback>);
    fn master_interfaces__action__PhotoUpload_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status_message: rosidl_runtime_rs::String,

}

impl PhotoUpload_Feedback {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_WAITING: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_UPLOADING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 2;

}


impl Default for PhotoUpload_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_FeedbackMessage__init(msg: *mut PhotoUpload_FeedbackMessage) -> bool;
    fn master_interfaces__action__PhotoUpload_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_FeedbackMessage>);
    fn master_interfaces__action__PhotoUpload_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::PhotoUpload_Feedback,

}



impl Default for PhotoUpload_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_Goal__init(msg: *mut TextToSpeech_Goal) -> bool;
    fn master_interfaces__action__TextToSpeech_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Goal>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Goal>);
    fn master_interfaces__action__TextToSpeech_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_Goal {
    /// ============ Goal ============
    /// 要播放的文本内容
    pub text: rosidl_runtime_rs::String,

    /// 音色选择 (可选, 默认使用服务器配置的默认音色)
    /// zf_xxx: 女性音色
    /// zm_xxx: 男性音色
    pub voice: rosidl_runtime_rs::String,

    /// 音量设置 (可选, 范围0-100, 默认65, 建议不低于55)
    pub volume: u8,

}



impl Default for TextToSpeech_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_Result__init(msg: *mut TextToSpeech_Result) -> bool;
    fn master_interfaces__action__TextToSpeech_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Result>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Result>);
    fn master_interfaces__action__TextToSpeech_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Result>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 结果信息
    pub message: rosidl_runtime_rs::String,

    /// 错误码 (0: 成功, 1: 网络错误, 2: 参数错误, 3: 服务不可用, 4: 被取消)
    pub error_code: u8,

}

impl TextToSpeech_Result {
    /// 错误码常量
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NETWORK: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_PARAM: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_SERVICE_UNAVAILABLE: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 4;

}


impl Default for TextToSpeech_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_Feedback__init(msg: *mut TextToSpeech_Feedback) -> bool;
    fn master_interfaces__action__TextToSpeech_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Feedback>);
    fn master_interfaces__action__TextToSpeech_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

    /// 状态描述信息
    pub status_message: rosidl_runtime_rs::String,

    /// 播放进度百分比 (0-100)
    pub progress: u8,

}

impl TextToSpeech_Feedback {
    /// 状态常量
    pub const STATUS_PREPARING: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_PLAYING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CANCELED: u8 = 3;

}


impl Default for TextToSpeech_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_FeedbackMessage__init(msg: *mut TextToSpeech_FeedbackMessage) -> bool;
    fn master_interfaces__action__TextToSpeech_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_FeedbackMessage>);
    fn master_interfaces__action__TextToSpeech_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::TextToSpeech_Feedback,

}



impl Default for TextToSpeech_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_Goal__init(msg: *mut VisionElevatorStatus_Goal) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Goal>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Goal>);
    fn master_interfaces__action__VisionElevatorStatus_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Goal {
    /// ============ Goal ============
    /// 请求开启/关闭检测
    /// True=开启检测，False=关闭检测
    pub enable: bool,

    /// 小车状态，进电梯=in,出电梯=out
    pub car_status: rosidl_runtime_rs::String,

}



impl Default for VisionElevatorStatus_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_Result__init(msg: *mut VisionElevatorStatus_Result) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Result>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Result>);
    fn master_interfaces__action__VisionElevatorStatus_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Result>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Result {
    /// 门状态：open/closed/half-open/unknown/error/timeout
    pub door_state: rosidl_runtime_rs::String,

    /// 最终置信度
    /// 检测置信度（%）
    pub confidence: f32,

    /// 操作是否成功
    /// 操作是否成功（True/False）
    pub success: bool,

    /// 结果信息
    /// 详细结果信息
    pub message: rosidl_runtime_rs::String,

}



impl Default for VisionElevatorStatus_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_Feedback__init(msg: *mut VisionElevatorStatus_Feedback) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Feedback>);
    fn master_interfaces__action__VisionElevatorStatus_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub collected_frames: i32,

    /// 目标帧数
    pub target_frames: i32,

    /// 当前检测到的门状态
    pub current_state: rosidl_runtime_rs::String,

    /// 当前置信度
    pub current_confidence: f32,

    /// 进度百分比
    pub progress_percentage: f32,

    /// 状态信息
    pub status_message: rosidl_runtime_rs::String,

}



impl Default for VisionElevatorStatus_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_FeedbackMessage__init(msg: *mut VisionElevatorStatus_FeedbackMessage) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_FeedbackMessage>);
    fn master_interfaces__action__VisionElevatorStatus_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::VisionElevatorStatus_Feedback,

}



impl Default for VisionElevatorStatus_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_FeedbackMessage() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_Goal() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_Goal__init(msg: *mut WebVoicePlayer_Goal) -> bool;
    fn master_interfaces__action__WebVoicePlayer_Goal__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Goal>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_Goal__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Goal>);
    fn master_interfaces__action__WebVoicePlayer_Goal__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_Goal>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Goal>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_Goal
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_Goal {
    /// ============ Goal ============
    /// 要播放的文本内容
    pub text: rosidl_runtime_rs::String,

    /// 模型选择 (可选, 默认为 "cosyvoice-v1")
    /// 可选模型: cosyvoice-v1, cosyvoice-v2
    pub model: rosidl_runtime_rs::String,

    /// 音色选择 (可选, 默认为 "longxiaochun")
    /// 可选音色: longxiaochun, longyuan, longwan 等
    pub voice: rosidl_runtime_rs::String,

    /// 音量设置 (可选, 范围 0-100, 默认 50)
    pub volume: u8,

    /// 语速设置 (可选, 范围 0.5-2.0, 默认 1.0)
    pub rate: f32,

    /// 音调设置 (可选, 范围 0.5-2.0, 默认 1.0)
    pub pitch: f32,

    /// 采样率 (可选, 默认 22050)
    pub sample_rate: u32,

    /// 输出音频格式 (可选, 默认 "mp3")
    /// 可选: mp3, wav, pcm
    pub format: rosidl_runtime_rs::String,

    /// 循环播放次数 (可选, 默认 1, 表示播放一次)
    /// 设置为 0 表示无限循环，设置为 n 表示播放 n 次
    pub loop_count: u32,

    /// 循环播放间隔时间 (可选, 单位: 秒, 默认 0)
    /// 当 loop_count >= 2 时生效，表示每次播放之间的间隔时间
    pub loop_interval: f32,

    /// 播放优先级 (可选, 默认 0)
    /// 0: 普通优先级，需要等待当前播放完成
    /// 1: 高优先级，立即停止当前播放并开始新播放
    pub priority: u8,

}



impl Default for WebVoicePlayer_Goal {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_Goal__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_Goal__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_Goal {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Goal__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Goal__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Goal__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_Goal {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_Goal where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_Goal";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_Goal() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_Result() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_Result__init(msg: *mut WebVoicePlayer_Result) -> bool;
    fn master_interfaces__action__WebVoicePlayer_Result__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Result>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_Result__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Result>);
    fn master_interfaces__action__WebVoicePlayer_Result__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_Result>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Result>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_Result
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_Result {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 结果信息
    pub message: rosidl_runtime_rs::String,

    /// 错误码 (0: 成功, 1: 网络错误, 2: 参数错误, 3: API 认证失败, 4: 被取消, 5: 音频播放失败)
    pub error_code: u8,

    /// 合成的字符数 (用于计费统计)
    pub characters_count: u32,

    /// 音频文件路径 (如果保存到本地)
    pub audio_file_path: rosidl_runtime_rs::String,

}

impl WebVoicePlayer_Result {
    /// 错误码常量
    pub const ERROR_NONE: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_NETWORK: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_INVALID_PARAM: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_AUTH_FAILED: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_CANCELED: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const ERROR_PLAYBACK_FAILED: u8 = 5;

}


impl Default for WebVoicePlayer_Result {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_Result__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_Result__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_Result {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Result__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Result__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Result__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_Result {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_Result where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_Result";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_Result() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_Feedback() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_Feedback__init(msg: *mut WebVoicePlayer_Feedback) -> bool;
    fn master_interfaces__action__WebVoicePlayer_Feedback__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Feedback>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_Feedback__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Feedback>);
    fn master_interfaces__action__WebVoicePlayer_Feedback__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_Feedback>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_Feedback>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_Feedback
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_Feedback {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

    /// 状态描述信息
    pub status_message: rosidl_runtime_rs::String,

    /// 合成进度百分比 (0-100)
    pub synthesis_progress: u8,

    /// 播放进度百分比 (0-100)
    pub playback_progress: u8,

    /// 已接收的音频数据大小 (字节)
    pub audio_data_size: u32,

}

impl WebVoicePlayer_Feedback {
    /// 状态常量
    pub const STATUS_INITIALIZING: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CONNECTING: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_SYNTHESIZING: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_PLAYING: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_COMPLETED: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATUS_CANCELED: u8 = 5;

}


impl Default for WebVoicePlayer_Feedback {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_Feedback__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_Feedback__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_Feedback {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Feedback__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Feedback__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_Feedback__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_Feedback {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_Feedback where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_Feedback";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_Feedback() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_FeedbackMessage() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_FeedbackMessage__init(msg: *mut WebVoicePlayer_FeedbackMessage) -> bool;
    fn master_interfaces__action__WebVoicePlayer_FeedbackMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_FeedbackMessage>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_FeedbackMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_FeedbackMessage>);
    fn master_interfaces__action__WebVoicePlayer_FeedbackMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_FeedbackMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_FeedbackMessage>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_FeedbackMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_FeedbackMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub feedback: super::super::action::rmw::WebVoicePlayer_Feedback,

}



impl Default for WebVoicePlayer_FeedbackMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_FeedbackMessage__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_FeedbackMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_FeedbackMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_FeedbackMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_FeedbackMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_FeedbackMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_FeedbackMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_FeedbackMessage where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_FeedbackMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_FeedbackMessage() }
  }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_SendGoal_Request__init(msg: *mut CargoCommand_SendGoal_Request) -> bool;
    fn master_interfaces__action__CargoCommand_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Request>);
    fn master_interfaces__action__CargoCommand_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::CargoCommand_Goal,

}



impl Default for CargoCommand_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_SendGoal_Response__init(msg: *mut CargoCommand_SendGoal_Response) -> bool;
    fn master_interfaces__action__CargoCommand_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Response>);
    fn master_interfaces__action__CargoCommand_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for CargoCommand_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_GetResult_Request__init(msg: *mut CargoCommand_GetResult_Request) -> bool;
    fn master_interfaces__action__CargoCommand_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Request>);
    fn master_interfaces__action__CargoCommand_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for CargoCommand_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__CargoCommand_GetResult_Response__init(msg: *mut CargoCommand_GetResult_Response) -> bool;
    fn master_interfaces__action__CargoCommand_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__CargoCommand_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Response>);
    fn master_interfaces__action__CargoCommand_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CargoCommand_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__CargoCommand_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CargoCommand_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::CargoCommand_Result,

}



impl Default for CargoCommand_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__CargoCommand_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__CargoCommand_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CargoCommand_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__CargoCommand_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CargoCommand_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CargoCommand_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/CargoCommand_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__CargoCommand_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_SendGoal_Request__init(msg: *mut ElevatorCommand_SendGoal_Request) -> bool;
    fn master_interfaces__action__ElevatorCommand_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Request>);
    fn master_interfaces__action__ElevatorCommand_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::ElevatorCommand_Goal,

}



impl Default for ElevatorCommand_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_SendGoal_Response__init(msg: *mut ElevatorCommand_SendGoal_Response) -> bool;
    fn master_interfaces__action__ElevatorCommand_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Response>);
    fn master_interfaces__action__ElevatorCommand_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for ElevatorCommand_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_GetResult_Request__init(msg: *mut ElevatorCommand_GetResult_Request) -> bool;
    fn master_interfaces__action__ElevatorCommand_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Request>);
    fn master_interfaces__action__ElevatorCommand_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for ElevatorCommand_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorCommand_GetResult_Response__init(msg: *mut ElevatorCommand_GetResult_Response) -> bool;
    fn master_interfaces__action__ElevatorCommand_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorCommand_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Response>);
    fn master_interfaces__action__ElevatorCommand_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorCommand_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorCommand_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorCommand_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::ElevatorCommand_Result,

}



impl Default for ElevatorCommand_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorCommand_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorCommand_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorCommand_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorCommand_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorCommand_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorCommand_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorCommand_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__init(msg: *mut ElevatorOccupancyCheck_SendGoal_Request) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Request>);
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::ElevatorOccupancyCheck_Goal,

}



impl Default for ElevatorOccupancyCheck_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__init(msg: *mut ElevatorOccupancyCheck_SendGoal_Response) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Response>);
    fn master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for ElevatorOccupancyCheck_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__init(msg: *mut ElevatorOccupancyCheck_GetResult_Request) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Request>);
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for ElevatorOccupancyCheck_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__init(msg: *mut ElevatorOccupancyCheck_GetResult_Response) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Response>);
    fn master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorOccupancyCheck_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorOccupancyCheck_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::ElevatorOccupancyCheck_Result,

}



impl Default for ElevatorOccupancyCheck_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorOccupancyCheck_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorOccupancyCheck_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorOccupancyCheck_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorOccupancyCheck_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_SendGoal_Request__init(msg: *mut ElevatorStated_SendGoal_Request) -> bool;
    fn master_interfaces__action__ElevatorStated_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Request>);
    fn master_interfaces__action__ElevatorStated_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::ElevatorStated_Goal,

}



impl Default for ElevatorStated_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_SendGoal_Response__init(msg: *mut ElevatorStated_SendGoal_Response) -> bool;
    fn master_interfaces__action__ElevatorStated_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Response>);
    fn master_interfaces__action__ElevatorStated_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for ElevatorStated_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_GetResult_Request__init(msg: *mut ElevatorStated_GetResult_Request) -> bool;
    fn master_interfaces__action__ElevatorStated_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Request>);
    fn master_interfaces__action__ElevatorStated_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for ElevatorStated_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__ElevatorStated_GetResult_Response__init(msg: *mut ElevatorStated_GetResult_Response) -> bool;
    fn master_interfaces__action__ElevatorStated_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__ElevatorStated_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Response>);
    fn master_interfaces__action__ElevatorStated_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ElevatorStated_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__ElevatorStated_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ElevatorStated_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::ElevatorStated_Result,

}



impl Default for ElevatorStated_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__ElevatorStated_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__ElevatorStated_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ElevatorStated_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__ElevatorStated_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ElevatorStated_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ElevatorStated_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/ElevatorStated_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__ElevatorStated_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_SendGoal_Request__init(msg: *mut NavigateTodoor_SendGoal_Request) -> bool;
    fn master_interfaces__action__NavigateTodoor_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Request>);
    fn master_interfaces__action__NavigateTodoor_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::NavigateTodoor_Goal,

}



impl Default for NavigateTodoor_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_SendGoal_Response__init(msg: *mut NavigateTodoor_SendGoal_Response) -> bool;
    fn master_interfaces__action__NavigateTodoor_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Response>);
    fn master_interfaces__action__NavigateTodoor_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for NavigateTodoor_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_GetResult_Request__init(msg: *mut NavigateTodoor_GetResult_Request) -> bool;
    fn master_interfaces__action__NavigateTodoor_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Request>);
    fn master_interfaces__action__NavigateTodoor_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for NavigateTodoor_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__NavigateTodoor_GetResult_Response__init(msg: *mut NavigateTodoor_GetResult_Response) -> bool;
    fn master_interfaces__action__NavigateTodoor_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__NavigateTodoor_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Response>);
    fn master_interfaces__action__NavigateTodoor_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateTodoor_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__NavigateTodoor_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoor_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::NavigateTodoor_Result,

}



impl Default for NavigateTodoor_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__NavigateTodoor_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__NavigateTodoor_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateTodoor_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__NavigateTodoor_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoor_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateTodoor_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/NavigateTodoor_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_SendGoal_Request__init(msg: *mut PhotoUpload_SendGoal_Request) -> bool;
    fn master_interfaces__action__PhotoUpload_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Request>);
    fn master_interfaces__action__PhotoUpload_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::PhotoUpload_Goal,

}



impl Default for PhotoUpload_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_SendGoal_Response__init(msg: *mut PhotoUpload_SendGoal_Response) -> bool;
    fn master_interfaces__action__PhotoUpload_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Response>);
    fn master_interfaces__action__PhotoUpload_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for PhotoUpload_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_GetResult_Request__init(msg: *mut PhotoUpload_GetResult_Request) -> bool;
    fn master_interfaces__action__PhotoUpload_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Request>);
    fn master_interfaces__action__PhotoUpload_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for PhotoUpload_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__PhotoUpload_GetResult_Response__init(msg: *mut PhotoUpload_GetResult_Response) -> bool;
    fn master_interfaces__action__PhotoUpload_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__PhotoUpload_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Response>);
    fn master_interfaces__action__PhotoUpload_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<PhotoUpload_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__PhotoUpload_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PhotoUpload_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::PhotoUpload_Result,

}



impl Default for PhotoUpload_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__PhotoUpload_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__PhotoUpload_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PhotoUpload_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__PhotoUpload_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PhotoUpload_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PhotoUpload_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/PhotoUpload_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__PhotoUpload_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_SendGoal_Request__init(msg: *mut TextToSpeech_SendGoal_Request) -> bool;
    fn master_interfaces__action__TextToSpeech_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Request>);
    fn master_interfaces__action__TextToSpeech_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::TextToSpeech_Goal,

}



impl Default for TextToSpeech_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_SendGoal_Response__init(msg: *mut TextToSpeech_SendGoal_Response) -> bool;
    fn master_interfaces__action__TextToSpeech_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Response>);
    fn master_interfaces__action__TextToSpeech_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for TextToSpeech_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_GetResult_Request__init(msg: *mut TextToSpeech_GetResult_Request) -> bool;
    fn master_interfaces__action__TextToSpeech_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Request>);
    fn master_interfaces__action__TextToSpeech_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for TextToSpeech_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__TextToSpeech_GetResult_Response__init(msg: *mut TextToSpeech_GetResult_Response) -> bool;
    fn master_interfaces__action__TextToSpeech_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__TextToSpeech_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Response>);
    fn master_interfaces__action__TextToSpeech_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<TextToSpeech_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__TextToSpeech_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TextToSpeech_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::TextToSpeech_Result,

}



impl Default for TextToSpeech_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__TextToSpeech_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__TextToSpeech_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for TextToSpeech_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__TextToSpeech_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for TextToSpeech_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for TextToSpeech_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/TextToSpeech_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__TextToSpeech_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Request__init(msg: *mut VisionElevatorStatus_SendGoal_Request) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Request>);
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::VisionElevatorStatus_Goal,

}



impl Default for VisionElevatorStatus_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Response__init(msg: *mut VisionElevatorStatus_SendGoal_Response) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Response>);
    fn master_interfaces__action__VisionElevatorStatus_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for VisionElevatorStatus_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Request__init(msg: *mut VisionElevatorStatus_GetResult_Request) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Request>);
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for VisionElevatorStatus_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Response__init(msg: *mut VisionElevatorStatus_GetResult_Response) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Response>);
    fn master_interfaces__action__VisionElevatorStatus_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::VisionElevatorStatus_Result,

}



impl Default for VisionElevatorStatus_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__VisionElevatorStatus_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__VisionElevatorStatus_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__VisionElevatorStatus_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/VisionElevatorStatus_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Request__init(msg: *mut WebVoicePlayer_SendGoal_Request) -> bool;
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Request>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Request>);
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Request>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_SendGoal_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_SendGoal_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub goal: super::super::action::rmw::WebVoicePlayer_Goal,

}



impl Default for WebVoicePlayer_SendGoal_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_SendGoal_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_SendGoal_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_SendGoal_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_SendGoal_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_SendGoal_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_SendGoal_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_SendGoal_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_SendGoal_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_SendGoal_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Response__init(msg: *mut WebVoicePlayer_SendGoal_Response) -> bool;
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Response>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Response>);
    fn master_interfaces__action__WebVoicePlayer_SendGoal_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_SendGoal_Response>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_SendGoal_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_SendGoal_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub accepted: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for WebVoicePlayer_SendGoal_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_SendGoal_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_SendGoal_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_SendGoal_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_SendGoal_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_SendGoal_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_SendGoal_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_SendGoal_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_SendGoal_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_SendGoal_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_GetResult_Request__init(msg: *mut WebVoicePlayer_GetResult_Request) -> bool;
    fn master_interfaces__action__WebVoicePlayer_GetResult_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Request>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_GetResult_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Request>);
    fn master_interfaces__action__WebVoicePlayer_GetResult_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Request>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_GetResult_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_GetResult_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub goal_id: unique_identifier_msgs::msg::rmw::UUID,

}



impl Default for WebVoicePlayer_GetResult_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_GetResult_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_GetResult_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_GetResult_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_GetResult_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_GetResult_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_GetResult_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_GetResult_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_GetResult_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_GetResult_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__action__WebVoicePlayer_GetResult_Response__init(msg: *mut WebVoicePlayer_GetResult_Response) -> bool;
    fn master_interfaces__action__WebVoicePlayer_GetResult_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Response>, size: usize) -> bool;
    fn master_interfaces__action__WebVoicePlayer_GetResult_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Response>);
    fn master_interfaces__action__WebVoicePlayer_GetResult_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<WebVoicePlayer_GetResult_Response>) -> bool;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_GetResult_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct WebVoicePlayer_GetResult_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub result: super::super::action::rmw::WebVoicePlayer_Result,

}



impl Default for WebVoicePlayer_GetResult_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__action__WebVoicePlayer_GetResult_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__action__WebVoicePlayer_GetResult_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for WebVoicePlayer_GetResult_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_GetResult_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_GetResult_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__action__WebVoicePlayer_GetResult_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for WebVoicePlayer_GetResult_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for WebVoicePlayer_GetResult_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/action/WebVoicePlayer_GetResult_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult_Response() }
  }
}






#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__CargoCommand_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct CargoCommand_SendGoal;

impl rosidl_runtime_rs::Service for CargoCommand_SendGoal {
    type Request = CargoCommand_SendGoal_Request;
    type Response = CargoCommand_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__CargoCommand_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct CargoCommand_GetResult;

impl rosidl_runtime_rs::Service for CargoCommand_GetResult {
    type Request = CargoCommand_GetResult_Request;
    type Response = CargoCommand_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__CargoCommand_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorCommand_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorCommand_SendGoal;

impl rosidl_runtime_rs::Service for ElevatorCommand_SendGoal {
    type Request = ElevatorCommand_SendGoal_Request;
    type Response = ElevatorCommand_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorCommand_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorCommand_GetResult;

impl rosidl_runtime_rs::Service for ElevatorCommand_GetResult {
    type Request = ElevatorCommand_GetResult_Request;
    type Response = ElevatorCommand_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorCommand_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorOccupancyCheck_SendGoal;

impl rosidl_runtime_rs::Service for ElevatorOccupancyCheck_SendGoal {
    type Request = ElevatorOccupancyCheck_SendGoal_Request;
    type Response = ElevatorOccupancyCheck_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorOccupancyCheck_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorOccupancyCheck_GetResult;

impl rosidl_runtime_rs::Service for ElevatorOccupancyCheck_GetResult {
    type Request = ElevatorOccupancyCheck_GetResult_Request;
    type Response = ElevatorOccupancyCheck_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorOccupancyCheck_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorStated_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorStated_SendGoal;

impl rosidl_runtime_rs::Service for ElevatorStated_SendGoal {
    type Request = ElevatorStated_SendGoal_Request;
    type Response = ElevatorStated_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__ElevatorStated_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct ElevatorStated_GetResult;

impl rosidl_runtime_rs::Service for ElevatorStated_GetResult {
    type Request = ElevatorStated_GetResult_Request;
    type Response = ElevatorStated_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__ElevatorStated_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__NavigateTodoor_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateTodoor_SendGoal;

impl rosidl_runtime_rs::Service for NavigateTodoor_SendGoal {
    type Request = NavigateTodoor_SendGoal_Request;
    type Response = NavigateTodoor_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__NavigateTodoor_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateTodoor_GetResult;

impl rosidl_runtime_rs::Service for NavigateTodoor_GetResult {
    type Request = NavigateTodoor_GetResult_Request;
    type Response = NavigateTodoor_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__NavigateTodoor_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__PhotoUpload_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct PhotoUpload_SendGoal;

impl rosidl_runtime_rs::Service for PhotoUpload_SendGoal {
    type Request = PhotoUpload_SendGoal_Request;
    type Response = PhotoUpload_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__PhotoUpload_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct PhotoUpload_GetResult;

impl rosidl_runtime_rs::Service for PhotoUpload_GetResult {
    type Request = PhotoUpload_GetResult_Request;
    type Response = PhotoUpload_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__PhotoUpload_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__TextToSpeech_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct TextToSpeech_SendGoal;

impl rosidl_runtime_rs::Service for TextToSpeech_SendGoal {
    type Request = TextToSpeech_SendGoal_Request;
    type Response = TextToSpeech_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__TextToSpeech_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct TextToSpeech_GetResult;

impl rosidl_runtime_rs::Service for TextToSpeech_GetResult {
    type Request = TextToSpeech_GetResult_Request;
    type Response = TextToSpeech_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__TextToSpeech_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus_SendGoal;

impl rosidl_runtime_rs::Service for VisionElevatorStatus_SendGoal {
    type Request = VisionElevatorStatus_SendGoal_Request;
    type Response = VisionElevatorStatus_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__VisionElevatorStatus_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus_GetResult;

impl rosidl_runtime_rs::Service for VisionElevatorStatus_GetResult {
    type Request = VisionElevatorStatus_GetResult_Request;
    type Response = VisionElevatorStatus_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__VisionElevatorStatus_GetResult() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_SendGoal
#[allow(missing_docs, non_camel_case_types)]
pub struct WebVoicePlayer_SendGoal;

impl rosidl_runtime_rs::Service for WebVoicePlayer_SendGoal {
    type Request = WebVoicePlayer_SendGoal_Request;
    type Response = WebVoicePlayer_SendGoal_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_SendGoal() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__action__WebVoicePlayer_GetResult
#[allow(missing_docs, non_camel_case_types)]
pub struct WebVoicePlayer_GetResult;

impl rosidl_runtime_rs::Service for WebVoicePlayer_GetResult {
    type Request = WebVoicePlayer_GetResult_Request;
    type Response = WebVoicePlayer_GetResult_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__action__WebVoicePlayer_GetResult() }
    }
}


