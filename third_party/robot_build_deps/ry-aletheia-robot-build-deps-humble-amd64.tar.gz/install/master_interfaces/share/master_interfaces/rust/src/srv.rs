#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to master_interfaces__srv__AddPathPoints_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddPathPoints_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub poses: Vec<geometry_msgs::msg::PoseStamped>,

}



impl Default for AddPathPoints_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::AddPathPoints_Request::default())
  }
}

impl rosidl_runtime_rs::Message for AddPathPoints_Request {
  type RmwMsg = super::srv::rmw::AddPathPoints_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        poses: msg.poses
          .into_iter()
          .map(|elem| geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        poses: msg.poses
          .iter()
          .map(|elem| geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      poses: msg.poses
          .into_iter()
          .map(geometry_msgs::msg::PoseStamped::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__AddPathPoints_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddPathPoints_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for AddPathPoints_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::AddPathPoints_Response::default())
  }
}

impl rosidl_runtime_rs::Message for AddPathPoints_Response {
  type RmwMsg = super::srv::rmw::AddPathPoints_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__CancelNavigation_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelNavigation_Request {
    /// 请求部分 (Request)
    /// 要取消的导航任务ID
    /// 如果为空字符串，则取消所有正在执行的导航任务
    pub task_id: std::string::String,

    /// 取消原因 (可选)
    pub reason: std::string::String,

}



impl Default for CancelNavigation_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CancelNavigation_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CancelNavigation_Request {
  type RmwMsg = super::srv::rmw::CancelNavigation_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
        reason: msg.reason.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
        reason: msg.reason.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_id: msg.task_id.to_string(),
      reason: msg.reason.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__CancelNavigation_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelNavigation_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::msg::StandardResponse,

    /// 被取消的任务数量
    pub cancelled_tasks_count: i32,

    /// 被取消的任务ID列表
    pub cancelled_task_ids: Vec<std::string::String>,

}



impl Default for CancelNavigation_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CancelNavigation_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CancelNavigation_Response {
  type RmwMsg = super::srv::rmw::CancelNavigation_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Owned(msg.response)).into_owned(),
        cancelled_tasks_count: msg.cancelled_tasks_count,
        cancelled_task_ids: msg.cancelled_task_ids
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response)).into_owned(),
      cancelled_tasks_count: msg.cancelled_tasks_count,
        cancelled_task_ids: msg.cancelled_task_ids
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: super::msg::StandardResponse::from_rmw_message(msg.response),
      cancelled_tasks_count: msg.cancelled_tasks_count,
      cancelled_task_ids: msg.cancelled_task_ids
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__CancelRecord_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecord_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for CancelRecord_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CancelRecord_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CancelRecord_Request {
  type RmwMsg = super::srv::rmw::CancelRecord_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__CancelRecord_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecord_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for CancelRecord_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CancelRecord_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CancelRecord_Response {
  type RmwMsg = super::srv::rmw::CancelRecord_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
    }
  }
}


// Corresponds to master_interfaces__srv__CancelRecordPath_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecordPath_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for CancelRecordPath_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CancelRecordPath_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CancelRecordPath_Request {
  type RmwMsg = super::srv::rmw::CancelRecordPath_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__CancelRecordPath_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecordPath_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for CancelRecordPath_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CancelRecordPath_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CancelRecordPath_Response {
  type RmwMsg = super::srv::rmw::CancelRecordPath_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
    }
  }
}


// Corresponds to master_interfaces__srv__CaptureCurrentPoint_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CaptureCurrentPoint_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub waypoint_id: std::string::String,

    /// 要保存到的路径文件名（不包含扩展名），如果为空则只添加到当前录制缓冲区
    pub path_name: std::string::String,

    /// 路径类型（community/building-unit/floor-door），仅当path_name不为空时需要
    pub type_: std::string::String,

}



impl Default for CaptureCurrentPoint_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CaptureCurrentPoint_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CaptureCurrentPoint_Request {
  type RmwMsg = super::srv::rmw::CaptureCurrentPoint_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoint_id: msg.waypoint_id.as_str().into(),
        path_name: msg.path_name.as_str().into(),
        type_: msg.type_.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoint_id: msg.waypoint_id.as_str().into(),
        path_name: msg.path_name.as_str().into(),
        type_: msg.type_.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      waypoint_id: msg.waypoint_id.to_string(),
      path_name: msg.path_name.to_string(),
      type_: msg.type_.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__CaptureCurrentPoint_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CaptureCurrentPoint_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pose: geometry_msgs::msg::Pose,

    /// 实际使用的waypoint_id（如果输入为空，返回自动生成的ID）
    pub actual_waypoint_id: std::string::String,

}



impl Default for CaptureCurrentPoint_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CaptureCurrentPoint_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CaptureCurrentPoint_Response {
  type RmwMsg = super::srv::rmw::CaptureCurrentPoint_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
        actual_waypoint_id: msg.actual_waypoint_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
        actual_waypoint_id: msg.actual_waypoint_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      pose: geometry_msgs::msg::Pose::from_rmw_message(msg.pose),
      actual_waypoint_id: msg.actual_waypoint_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__ChangeLocalizer_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ChangeLocalizer_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub pcd_path: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub yaw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pitch: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roll: f32,

}



impl Default for ChangeLocalizer_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ChangeLocalizer_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ChangeLocalizer_Request {
  type RmwMsg = super::srv::rmw::ChangeLocalizer_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        pcd_path: msg.pcd_path.as_str().into(),
        x: msg.x,
        y: msg.y,
        z: msg.z,
        yaw: msg.yaw,
        pitch: msg.pitch,
        roll: msg.roll,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        pcd_path: msg.pcd_path.as_str().into(),
      x: msg.x,
      y: msg.y,
      z: msg.z,
      yaw: msg.yaw,
      pitch: msg.pitch,
      roll: msg.roll,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      pcd_path: msg.pcd_path.to_string(),
      x: msg.x,
      y: msg.y,
      z: msg.z,
      yaw: msg.yaw,
      pitch: msg.pitch,
      roll: msg.roll,
    }
  }
}


// Corresponds to master_interfaces__srv__ChangeLocalizer_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ChangeLocalizer_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for ChangeLocalizer_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ChangeLocalizer_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ChangeLocalizer_Response {
  type RmwMsg = super::srv::rmw::ChangeLocalizer_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__CheckBuildingOccupancy_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CheckBuildingOccupancy_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub building_id: std::string::String,

}



impl Default for CheckBuildingOccupancy_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CheckBuildingOccupancy_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CheckBuildingOccupancy_Request {
  type RmwMsg = super::srv::rmw::CheckBuildingOccupancy_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        building_id: msg.building_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        building_id: msg.building_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      building_id: msg.building_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__CheckBuildingOccupancy_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CheckBuildingOccupancy_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for CheckBuildingOccupancy_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CheckBuildingOccupancy_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CheckBuildingOccupancy_Response {
  type RmwMsg = super::srv::rmw::CheckBuildingOccupancy_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__DeleteBag_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeleteBag_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bag_name: std::string::String,

}



impl Default for DeleteBag_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::DeleteBag_Request::default())
  }
}

impl rosidl_runtime_rs::Message for DeleteBag_Request {
  type RmwMsg = super::srv::rmw::DeleteBag_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        bag_name: msg.bag_name.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        bag_name: msg.bag_name.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      bag_name: msg.bag_name.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__DeleteBag_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeleteBag_Response {
    /// 响应
    pub success: bool,

    /// 操作结果消息
    pub message: std::string::String,

}



impl Default for DeleteBag_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::DeleteBag_Response::default())
  }
}

impl rosidl_runtime_rs::Message for DeleteBag_Response {
  type RmwMsg = super::srv::rmw::DeleteBag_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__DeletePathPoints_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeletePathPoints_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub path_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub poses_to_delete: Vec<geometry_msgs::msg::Pose>,

}



impl Default for DeletePathPoints_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::DeletePathPoints_Request::default())
  }
}

impl rosidl_runtime_rs::Message for DeletePathPoints_Request {
  type RmwMsg = super::srv::rmw::DeletePathPoints_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        path_name: msg.path_name.as_str().into(),
        type_: msg.type_.as_str().into(),
        poses_to_delete: msg.poses_to_delete
          .into_iter()
          .map(|elem| geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        path_name: msg.path_name.as_str().into(),
        type_: msg.type_.as_str().into(),
        poses_to_delete: msg.poses_to_delete
          .iter()
          .map(|elem| geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      path_name: msg.path_name.to_string(),
      type_: msg.type_.to_string(),
      poses_to_delete: msg.poses_to_delete
          .into_iter()
          .map(geometry_msgs::msg::Pose::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__DeletePathPoints_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeletePathPoints_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub remaining_points: i32,

}



impl Default for DeletePathPoints_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::DeletePathPoints_Response::default())
  }
}

impl rosidl_runtime_rs::Message for DeletePathPoints_Response {
  type RmwMsg = super::srv::rmw::DeletePathPoints_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        remaining_points: msg.remaining_points,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      remaining_points: msg.remaining_points,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      remaining_points: msg.remaining_points,
    }
  }
}


// Corresponds to master_interfaces__srv__DoorControl_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DoorControl_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub executeid: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub doorid: std::string::String,

}



impl Default for DoorControl_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::DoorControl_Request::default())
  }
}

impl rosidl_runtime_rs::Message for DoorControl_Request {
  type RmwMsg = super::srv::rmw::DoorControl_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        executeid: msg.executeid,
        doorid: msg.doorid.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      executeid: msg.executeid,
        doorid: msg.doorid.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      executeid: msg.executeid,
      doorid: msg.doorid.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__DoorControl_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DoorControl_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stateid: i32,

}



impl Default for DoorControl_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::DoorControl_Response::default())
  }
}

impl rosidl_runtime_rs::Message for DoorControl_Response {
  type RmwMsg = super::srv::rmw::DoorControl_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        stateid: msg.stateid,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      stateid: msg.stateid,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      stateid: msg.stateid,
    }
  }
}


// Corresponds to master_interfaces__srv__EditTaskWaypoint_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EditTaskWaypoint_Request {
    /// 请求
    /// 任务文件的完整路径
    pub task_file_path: std::string::String,

    /// 路径点的 ID（用于定位）
    pub waypoint_id: i32,

    /// 路径点的位姿（用于定位验证）
    pub pose: geometry_msgs::msg::Pose,

    /// 可编辑字段（空字符串或-1表示不修改）
    /// 任务点 ID，空字符串表示不修改
    pub waypoint_task_id: std::string::String,

    /// 是否为任务点：-1=不修改, 0=false, 1=true
    pub is_task_point: i8,

    /// 速度模式：空字符串表示不修改，可选值："low_speed", "normal", "high_speed"
    pub speed_mode: std::string::String,

    /// 是否倒退：-1=不修改, 0=false, 1=true
    pub is_backward: i8,

    /// 是否为单点：-1=不修改, 0=false, 1=true
    pub is_single_point: i8,

}



impl Default for EditTaskWaypoint_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::EditTaskWaypoint_Request::default())
  }
}

impl rosidl_runtime_rs::Message for EditTaskWaypoint_Request {
  type RmwMsg = super::srv::rmw::EditTaskWaypoint_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_file_path: msg.task_file_path.as_str().into(),
        waypoint_id: msg.waypoint_id,
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
        waypoint_task_id: msg.waypoint_task_id.as_str().into(),
        is_task_point: msg.is_task_point,
        speed_mode: msg.speed_mode.as_str().into(),
        is_backward: msg.is_backward,
        is_single_point: msg.is_single_point,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_file_path: msg.task_file_path.as_str().into(),
      waypoint_id: msg.waypoint_id,
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
        waypoint_task_id: msg.waypoint_task_id.as_str().into(),
      is_task_point: msg.is_task_point,
        speed_mode: msg.speed_mode.as_str().into(),
      is_backward: msg.is_backward,
      is_single_point: msg.is_single_point,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_file_path: msg.task_file_path.to_string(),
      waypoint_id: msg.waypoint_id,
      pose: geometry_msgs::msg::Pose::from_rmw_message(msg.pose),
      waypoint_task_id: msg.waypoint_task_id.to_string(),
      is_task_point: msg.is_task_point,
      speed_mode: msg.speed_mode.to_string(),
      is_backward: msg.is_backward,
      is_single_point: msg.is_single_point,
    }
  }
}


// Corresponds to master_interfaces__srv__EditTaskWaypoint_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EditTaskWaypoint_Response {
    /// 响应
    /// 是否成功编辑
    pub success: bool,

    /// 响应消息
    pub message: std::string::String,

}



impl Default for EditTaskWaypoint_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::EditTaskWaypoint_Response::default())
  }
}

impl rosidl_runtime_rs::Message for EditTaskWaypoint_Response {
  type RmwMsg = super::srv::rmw::EditTaskWaypoint_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__EndRecord_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EndRecord_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for EndRecord_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::EndRecord_Request::default())
  }
}

impl rosidl_runtime_rs::Message for EndRecord_Request {
  type RmwMsg = super::srv::rmw::EndRecord_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__EndRecord_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EndRecord_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub path: std::string::String,

}



impl Default for EndRecord_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::EndRecord_Response::default())
  }
}

impl rosidl_runtime_rs::Message for EndRecord_Response {
  type RmwMsg = super::srv::rmw::EndRecord_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        path: msg.path.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        path: msg.path.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      path: msg.path.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__FollowPath_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FollowPath_Request {
    /// 请求部分 (Request)
    /// 路径信息（含 frame_id 与时间戳）
    pub path: nav_msgs::msg::Path,

    /// 控制器ID，如果为空则使用默认控制器（如 "FollowPath"）
    pub controller_id: std::string::String,

    /// 目标检查器ID
    pub goal_checker_id: std::string::String,

    /// 行为树文件路径，如果为空则使用默认行为树
    pub behavior_tree: std::string::String,

    /// 超时时间 (秒)，0 表示无超时限制
    pub timeout: f64,

    /// 航点类型 (可选)，用于业务逻辑识别
    /// path_point / gate_point / elevator_point / user_door ...
    pub waypoint_type: std::string::String,

}



impl Default for FollowPath_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::FollowPath_Request::default())
  }
}

impl rosidl_runtime_rs::Message for FollowPath_Request {
  type RmwMsg = super::srv::rmw::FollowPath_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        path: nav_msgs::msg::Path::into_rmw_message(std::borrow::Cow::Owned(msg.path)).into_owned(),
        controller_id: msg.controller_id.as_str().into(),
        goal_checker_id: msg.goal_checker_id.as_str().into(),
        behavior_tree: msg.behavior_tree.as_str().into(),
        timeout: msg.timeout,
        waypoint_type: msg.waypoint_type.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        path: nav_msgs::msg::Path::into_rmw_message(std::borrow::Cow::Borrowed(&msg.path)).into_owned(),
        controller_id: msg.controller_id.as_str().into(),
        goal_checker_id: msg.goal_checker_id.as_str().into(),
        behavior_tree: msg.behavior_tree.as_str().into(),
      timeout: msg.timeout,
        waypoint_type: msg.waypoint_type.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      path: nav_msgs::msg::Path::from_rmw_message(msg.path),
      controller_id: msg.controller_id.to_string(),
      goal_checker_id: msg.goal_checker_id.to_string(),
      behavior_tree: msg.behavior_tree.to_string(),
      timeout: msg.timeout,
      waypoint_type: msg.waypoint_type.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__FollowPath_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FollowPath_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::msg::StandardResponse,

    /// 路径跟随任务ID，用于后续查询和取消操作
    pub task_id: std::string::String,

}



impl Default for FollowPath_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::FollowPath_Response::default())
  }
}

impl rosidl_runtime_rs::Message for FollowPath_Response {
  type RmwMsg = super::srv::rmw::FollowPath_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Owned(msg.response)).into_owned(),
        task_id: msg.task_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response)).into_owned(),
        task_id: msg.task_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: super::msg::StandardResponse::from_rmw_message(msg.response),
      task_id: msg.task_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GenerateTask_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GenerateTask_Request {
    /// 请求
    pub community: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,

}



impl Default for GenerateTask_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GenerateTask_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GenerateTask_Request {
  type RmwMsg = super::srv::rmw::GenerateTask_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
        building: msg.building,
        unit: msg.unit,
        floor: msg.floor,
        door: msg.door,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      community: msg.community.to_string(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
    }
  }
}


// Corresponds to master_interfaces__srv__GenerateTask_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GenerateTask_Response {
    /// 响应
    /// 是否成功生成任务文件
    pub success: bool,

    /// 响应消息
    pub message: std::string::String,

    /// 生成的任务文件路径
    pub output_file_path: std::string::String,

}



impl Default for GenerateTask_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GenerateTask_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GenerateTask_Response {
  type RmwMsg = super::srv::rmw::GenerateTask_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        output_file_path: msg.output_file_path.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
        output_file_path: msg.output_file_path.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      output_file_path: msg.output_file_path.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetBagList_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetBagList_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for GetBagList_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetBagList_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetBagList_Request {
  type RmwMsg = super::srv::rmw::GetBagList_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__GetBagList_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetBagList_Response {
    /// 响应
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bags: Vec<super::msg::BagInfo>,

}



impl Default for GetBagList_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetBagList_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetBagList_Response {
  type RmwMsg = super::srv::rmw::GetBagList_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        bags: msg.bags
          .into_iter()
          .map(|elem| super::msg::BagInfo::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        bags: msg.bags
          .iter()
          .map(|elem| super::msg::BagInfo::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      bags: msg.bags
          .into_iter()
          .map(super::msg::BagInfo::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetCargoStatus_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetCargoStatus_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_id: u8,

}

impl GetCargoStatus_Request {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_UPPER: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_LOWER: u8 = 2;

}


impl Default for GetCargoStatus_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetCargoStatus_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetCargoStatus_Request {
  type RmwMsg = super::srv::rmw::GetCargoStatus_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        cargo_id: msg.cargo_id,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      cargo_id: msg.cargo_id,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      cargo_id: msg.cargo_id,
    }
  }
}


// Corresponds to master_interfaces__srv__GetCargoStatus_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetCargoStatus_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub last_operation_code: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_busy: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state_text: std::string::String,

}

impl GetCargoStatus_Response {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UNKNOWN: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_RESET: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UPPER_MANUAL_OPEN: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UPPER_MANUAL_CLOSE: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UPPER_AUTO_UNLOAD: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_LOWER_UNLOCK: u8 = 5;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_LOWER_LOCK: u8 = 6;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_LOWER_OPEN: u8 = 7;

}


impl Default for GetCargoStatus_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetCargoStatus_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetCargoStatus_Response {
  type RmwMsg = super::srv::rmw::GetCargoStatus_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        cargo_id: msg.cargo_id,
        state: msg.state,
        last_operation_code: msg.last_operation_code,
        is_busy: msg.is_busy,
        state_text: msg.state_text.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      cargo_id: msg.cargo_id,
      state: msg.state,
      last_operation_code: msg.last_operation_code,
      is_busy: msg.is_busy,
        state_text: msg.state_text.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      cargo_id: msg.cargo_id,
      state: msg.state,
      last_operation_code: msg.last_operation_code,
      is_busy: msg.is_busy,
      state_text: msg.state_text.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetElevatorId_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetElevatorId_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub community: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,

}



impl Default for GetElevatorId_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetElevatorId_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetElevatorId_Request {
  type RmwMsg = super::srv::rmw::GetElevatorId_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
        building: msg.building,
        unit: msg.unit,
        floor: msg.floor,
        door: msg.door,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      community: msg.community.to_string(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
    }
  }
}


// Corresponds to master_interfaces__srv__GetElevatorId_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetElevatorId_Response {
    /// 响应
    pub success: bool,

    /// 电梯id改string
    pub elevatorid: std::string::String,

}



impl Default for GetElevatorId_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetElevatorId_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetElevatorId_Response {
  type RmwMsg = super::srv::rmw::GetElevatorId_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        elevatorid: msg.elevatorid.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        elevatorid: msg.elevatorid.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      elevatorid: msg.elevatorid.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetEmergencyStop_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetEmergencyStop_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for GetEmergencyStop_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetEmergencyStop_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetEmergencyStop_Request {
  type RmwMsg = super::srv::rmw::GetEmergencyStop_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__GetEmergencyStop_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetEmergencyStop_Response {
    /// 响应
    /// 当前急停状态：true=已按下，false=已释放
    pub is_emergency_stop: bool,

    /// 状态描述信息
    pub message: std::string::String,

}



impl Default for GetEmergencyStop_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetEmergencyStop_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetEmergencyStop_Response {
  type RmwMsg = super::srv::rmw::GetEmergencyStop_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        is_emergency_stop: msg.is_emergency_stop,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      is_emergency_stop: msg.is_emergency_stop,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      is_emergency_stop: msg.is_emergency_stop,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetNavigationStatus_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetNavigationStatus_Request {
    /// 请求部分 (Request)
    /// 要查询的导航任务ID
    /// 如果为空字符串，则返回所有任务的状态
    pub task_id: std::string::String,

}



impl Default for GetNavigationStatus_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetNavigationStatus_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetNavigationStatus_Request {
  type RmwMsg = super::srv::rmw::GetNavigationStatus_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_id: msg.task_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetNavigationStatus_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetNavigationStatus_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::msg::StandardResponse,

    /// 导航状态信息列表
    pub navigation_status: Vec<super::msg::NavigationStatus>,

}



impl Default for GetNavigationStatus_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetNavigationStatus_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetNavigationStatus_Response {
  type RmwMsg = super::srv::rmw::GetNavigationStatus_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Owned(msg.response)).into_owned(),
        navigation_status: msg.navigation_status
          .into_iter()
          .map(|elem| super::msg::NavigationStatus::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response)).into_owned(),
        navigation_status: msg.navigation_status
          .iter()
          .map(|elem| super::msg::NavigationStatus::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: super::msg::StandardResponse::from_rmw_message(msg.response),
      navigation_status: msg.navigation_status
          .into_iter()
          .map(super::msg::NavigationStatus::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetPathList_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathList_Request {
    /// indoor/outdoor or "all" for all types
    pub type_: std::string::String,

}



impl Default for GetPathList_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetPathList_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetPathList_Request {
  type RmwMsg = super::srv::rmw::GetPathList_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        type_: msg.type_.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        type_: msg.type_.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      type_: msg.type_.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetPathList_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathList_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 路径名称列表
    pub path_names: Vec<std::string::String>,

    /// 每个路径的点数量
    pub point_counts: Vec<i32>,

    /// 完整文件路径
    pub file_paths: Vec<std::string::String>,

}



impl Default for GetPathList_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetPathList_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetPathList_Response {
  type RmwMsg = super::srv::rmw::GetPathList_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        path_names: msg.path_names
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
        point_counts: msg.point_counts.into(),
        file_paths: msg.file_paths
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        path_names: msg.path_names
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
        point_counts: msg.point_counts.as_slice().into(),
        file_paths: msg.file_paths
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      path_names: msg.path_names
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
      point_counts: msg.point_counts
          .into_iter()
          .collect(),
      file_paths: msg.file_paths
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetPathPoints_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathPoints_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub path_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: std::string::String,

}



impl Default for GetPathPoints_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetPathPoints_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetPathPoints_Request {
  type RmwMsg = super::srv::rmw::GetPathPoints_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        path_name: msg.path_name.as_str().into(),
        type_: msg.type_.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        path_name: msg.path_name.as_str().into(),
        type_: msg.type_.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      path_name: msg.path_name.to_string(),
      type_: msg.type_.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetPathPoints_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathPoints_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub poses: Vec<geometry_msgs::msg::PoseStamped>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i32,

}



impl Default for GetPathPoints_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetPathPoints_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetPathPoints_Response {
  type RmwMsg = super::srv::rmw::GetPathPoints_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        poses: msg.poses
          .into_iter()
          .map(|elem| geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        num: msg.num,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        poses: msg.poses
          .iter()
          .map(|elem| geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      num: msg.num,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      poses: msg.poses
          .into_iter()
          .map(geometry_msgs::msg::PoseStamped::from_rmw_message)
          .collect(),
      num: msg.num,
    }
  }
}


// Corresponds to master_interfaces__srv__GetPlanStatus_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPlanStatus_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub task_id: std::string::String,

}



impl Default for GetPlanStatus_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetPlanStatus_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetPlanStatus_Request {
  type RmwMsg = super::srv::rmw::GetPlanStatus_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_id: msg.task_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__GetPlanStatus_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPlanStatus_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub code: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub msg: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status: super::msg::PlanStatus,

}



impl Default for GetPlanStatus_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::GetPlanStatus_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetPlanStatus_Response {
  type RmwMsg = super::srv::rmw::GetPlanStatus_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        code: msg.code,
        msg: msg.msg.as_str().into(),
        status: super::msg::PlanStatus::into_rmw_message(std::borrow::Cow::Owned(msg.status)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      code: msg.code,
        msg: msg.msg.as_str().into(),
        status: super::msg::PlanStatus::into_rmw_message(std::borrow::Cow::Borrowed(&msg.status)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      code: msg.code,
      msg: msg.msg.to_string(),
      status: super::msg::PlanStatus::from_rmw_message(msg.status),
    }
  }
}


// Corresponds to master_interfaces__srv__NavigateThroughPoses_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateThroughPoses_Request {
    /// 请求部分 (Request)
    /// 目标位姿序列，顺序执行
    pub poses: Vec<geometry_msgs::msg::PoseStamped>,

    /// 行为树文件路径，如果为空则使用默认行为树
    pub behavior_tree: std::string::String,

    /// 超时时间 (秒)，0 表示无超时限制
    pub timeout: f64,

    /// 航点类型 (可选)，用于业务逻辑识别
    /// path_point / gate_point / elevator_point / user_door ...
    pub waypoint_type: std::string::String,

}



impl Default for NavigateThroughPoses_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::NavigateThroughPoses_Request::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateThroughPoses_Request {
  type RmwMsg = super::srv::rmw::NavigateThroughPoses_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        poses: msg.poses
          .into_iter()
          .map(|elem| geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        behavior_tree: msg.behavior_tree.as_str().into(),
        timeout: msg.timeout,
        waypoint_type: msg.waypoint_type.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        poses: msg.poses
          .iter()
          .map(|elem| geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        behavior_tree: msg.behavior_tree.as_str().into(),
      timeout: msg.timeout,
        waypoint_type: msg.waypoint_type.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      poses: msg.poses
          .into_iter()
          .map(geometry_msgs::msg::PoseStamped::from_rmw_message)
          .collect(),
      behavior_tree: msg.behavior_tree.to_string(),
      timeout: msg.timeout,
      waypoint_type: msg.waypoint_type.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__NavigateThroughPoses_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateThroughPoses_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::msg::StandardResponse,

    /// 任务ID，用于后续查询和取消操作
    pub task_id: std::string::String,

}



impl Default for NavigateThroughPoses_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::NavigateThroughPoses_Response::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateThroughPoses_Response {
  type RmwMsg = super::srv::rmw::NavigateThroughPoses_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Owned(msg.response)).into_owned(),
        task_id: msg.task_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response)).into_owned(),
        task_id: msg.task_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: super::msg::StandardResponse::from_rmw_message(msg.response),
      task_id: msg.task_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__NavigateToPose_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateToPose_Request {
    /// 请求部分 (Request)
    /// 目标位姿信息
    pub target_pose: geometry_msgs::msg::PoseStamped,

    /// 导航行为参数 (可选)
    /// 规划器ID，如果为空则使用默认规划器
    pub planner_id: std::string::String,

    /// 控制器ID，如果为空则使用默认控制器
    pub controller_id: std::string::String,

    /// 行为树文件路径，如果为空则使用默认行为树
    pub behavior_tree: std::string::String,

    /// 导航超时时间 (秒)，0表示无超时限制
    pub timeout: f64,

    /// 航点类型 (可选)，用于业务逻辑识别
    /// path_point / gate_point / elevator_point / user_door ...
    pub waypoint_type: std::string::String,

}



impl Default for NavigateToPose_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::NavigateToPose_Request::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateToPose_Request {
  type RmwMsg = super::srv::rmw::NavigateToPose_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        target_pose: geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Owned(msg.target_pose)).into_owned(),
        planner_id: msg.planner_id.as_str().into(),
        controller_id: msg.controller_id.as_str().into(),
        behavior_tree: msg.behavior_tree.as_str().into(),
        timeout: msg.timeout,
        waypoint_type: msg.waypoint_type.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        target_pose: geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Borrowed(&msg.target_pose)).into_owned(),
        planner_id: msg.planner_id.as_str().into(),
        controller_id: msg.controller_id.as_str().into(),
        behavior_tree: msg.behavior_tree.as_str().into(),
      timeout: msg.timeout,
        waypoint_type: msg.waypoint_type.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      target_pose: geometry_msgs::msg::PoseStamped::from_rmw_message(msg.target_pose),
      planner_id: msg.planner_id.to_string(),
      controller_id: msg.controller_id.to_string(),
      behavior_tree: msg.behavior_tree.to_string(),
      timeout: msg.timeout,
      waypoint_type: msg.waypoint_type.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__NavigateToPose_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateToPose_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::msg::StandardResponse,

    /// 导航任务ID，用于后续查询和取消操作
    pub task_id: std::string::String,

}



impl Default for NavigateToPose_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::NavigateToPose_Response::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateToPose_Response {
  type RmwMsg = super::srv::rmw::NavigateToPose_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Owned(msg.response)).into_owned(),
        task_id: msg.task_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response)).into_owned(),
        task_id: msg.task_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: super::msg::StandardResponse::from_rmw_message(msg.response),
      task_id: msg.task_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__NodeString_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NodeString_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub node_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub node_config: std::string::String,

}



impl Default for NodeString_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::NodeString_Request::default())
  }
}

impl rosidl_runtime_rs::Message for NodeString_Request {
  type RmwMsg = super::srv::rmw::NodeString_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        node_name: msg.node_name.as_str().into(),
        node_config: msg.node_config.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        node_name: msg.node_name.as_str().into(),
        node_config: msg.node_config.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      node_name: msg.node_name.to_string(),
      node_config: msg.node_config.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__NodeString_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NodeString_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for NodeString_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::NodeString_Response::default())
  }
}

impl rosidl_runtime_rs::Message for NodeString_Response {
  type RmwMsg = super::srv::rmw::NodeString_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__PGOMapping_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PGOMapping_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub command: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub file_path: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub save_patches: bool,

}



impl Default for PGOMapping_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::PGOMapping_Request::default())
  }
}

impl rosidl_runtime_rs::Message for PGOMapping_Request {
  type RmwMsg = super::srv::rmw::PGOMapping_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        command: msg.command.as_str().into(),
        file_path: msg.file_path.as_str().into(),
        save_patches: msg.save_patches,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        command: msg.command.as_str().into(),
        file_path: msg.file_path.as_str().into(),
      save_patches: msg.save_patches,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      command: msg.command.to_string(),
      file_path: msg.file_path.to_string(),
      save_patches: msg.save_patches,
    }
  }
}


// Corresponds to master_interfaces__srv__PGOMapping_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PGOMapping_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num_key_poses: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num_loops: i32,

}



impl Default for PGOMapping_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::PGOMapping_Response::default())
  }
}

impl rosidl_runtime_rs::Message for PGOMapping_Response {
  type RmwMsg = super::srv::rmw::PGOMapping_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        num_key_poses: msg.num_key_poses,
        num_loops: msg.num_loops,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      num_key_poses: msg.num_key_poses,
      num_loops: msg.num_loops,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      num_key_poses: msg.num_key_poses,
      num_loops: msg.num_loops,
    }
  }
}


// Corresponds to master_interfaces__srv__Ping_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Ping_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub request_time: builtin_interfaces::msg::Time,

}



impl Default for Ping_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::Ping_Request::default())
  }
}

impl rosidl_runtime_rs::Message for Ping_Request {
  type RmwMsg = super::srv::rmw::Ping_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        message: msg.message.as_str().into(),
        request_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.request_time)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        message: msg.message.as_str().into(),
        request_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.request_time)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      message: msg.message.to_string(),
      request_time: builtin_interfaces::msg::Time::from_rmw_message(msg.request_time),
    }
  }
}


// Corresponds to master_interfaces__srv__Ping_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Ping_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub response: super::msg::StandardResponse,


    // This member is not documented.
    #[allow(missing_docs)]
    pub response_time: builtin_interfaces::msg::Time,

}



impl Default for Ping_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::Ping_Response::default())
  }
}

impl rosidl_runtime_rs::Message for Ping_Response {
  type RmwMsg = super::srv::rmw::Ping_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Owned(msg.response)).into_owned(),
        response_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.response_time)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: super::msg::StandardResponse::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response)).into_owned(),
        response_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.response_time)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: super::msg::StandardResponse::from_rmw_message(msg.response),
      response_time: builtin_interfaces::msg::Time::from_rmw_message(msg.response_time),
    }
  }
}


// Corresponds to master_interfaces__srv__ReportException_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReportException_Request {
    /// 请求（字段与 JSON payload 保持一致）
    /// 可选，请求唯一标识
    pub request_id: std::string::String,

    /// 异常等级，如 Error / Warn
    pub safe_level: std::string::String,

    /// 8位16进制错误码字符串，例如 "0x0000A001"
    pub safe_code: std::string::String,

    /// 异常描述
    pub safe_msg: std::string::String,

    /// 处理措施，可为空
    pub safe_action: std::string::String,

}



impl Default for ReportException_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ReportException_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ReportException_Request {
  type RmwMsg = super::srv::rmw::ReportException_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        request_id: msg.request_id.as_str().into(),
        safe_level: msg.safe_level.as_str().into(),
        safe_code: msg.safe_code.as_str().into(),
        safe_msg: msg.safe_msg.as_str().into(),
        safe_action: msg.safe_action.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        request_id: msg.request_id.as_str().into(),
        safe_level: msg.safe_level.as_str().into(),
        safe_code: msg.safe_code.as_str().into(),
        safe_msg: msg.safe_msg.as_str().into(),
        safe_action: msg.safe_action.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      request_id: msg.request_id.to_string(),
      safe_level: msg.safe_level.to_string(),
      safe_code: msg.safe_code.to_string(),
      safe_msg: msg.safe_msg.to_string(),
      safe_action: msg.safe_action.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__ReportException_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReportException_Response {
    /// 是否成功上报
    pub success: bool,

    /// 错误信息(如果 success=false)
    pub error_message: std::string::String,

}



impl Default for ReportException_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ReportException_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ReportException_Response {
  type RmwMsg = super::srv::rmw::ReportException_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        error_message: msg.error_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        error_message: msg.error_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      error_message: msg.error_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__ResetTaskWaypoint_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ResetTaskWaypoint_Request {
    /// 请求
    /// 任务文件的完整路径
    pub task_file_path: std::string::String,

    /// 路径点的 ID（用于定位）
    pub waypoint_id: i32,

    /// 路径点的位姿（用于定位验证）
    pub pose: geometry_msgs::msg::Pose,

}



impl Default for ResetTaskWaypoint_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ResetTaskWaypoint_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ResetTaskWaypoint_Request {
  type RmwMsg = super::srv::rmw::ResetTaskWaypoint_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_file_path: msg.task_file_path.as_str().into(),
        waypoint_id: msg.waypoint_id,
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_file_path: msg.task_file_path.as_str().into(),
      waypoint_id: msg.waypoint_id,
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_file_path: msg.task_file_path.to_string(),
      waypoint_id: msg.waypoint_id,
      pose: geometry_msgs::msg::Pose::from_rmw_message(msg.pose),
    }
  }
}


// Corresponds to master_interfaces__srv__ResetTaskWaypoint_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ResetTaskWaypoint_Response {
    /// 响应
    /// 是否成功还原
    pub success: bool,

    /// 响应消息
    pub message: std::string::String,

}



impl Default for ResetTaskWaypoint_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ResetTaskWaypoint_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ResetTaskWaypoint_Response {
  type RmwMsg = super::srv::rmw::ResetTaskWaypoint_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__ReturnHome_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReturnHome_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for ReturnHome_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ReturnHome_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ReturnHome_Request {
  type RmwMsg = super::srv::rmw::ReturnHome_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__ReturnHome_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReturnHome_Response {
    /// 响应
    /// 返程是否成功
    pub success: bool,

    /// 返程结果消息
    pub message: std::string::String,

}



impl Default for ReturnHome_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ReturnHome_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ReturnHome_Response {
  type RmwMsg = super::srv::rmw::ReturnHome_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartExecuteTasks_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartExecuteTasks_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub community: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_uuid: std::string::String,

}



impl Default for StartExecuteTasks_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartExecuteTasks_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartExecuteTasks_Request {
  type RmwMsg = super::srv::rmw::StartExecuteTasks_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
        building: msg.building,
        unit: msg.unit,
        floor: msg.floor,
        door: msg.door,
        task_uuid: msg.task_uuid.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
        task_uuid: msg.task_uuid.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      community: msg.community.to_string(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
      task_uuid: msg.task_uuid.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartExecuteTasks_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartExecuteTasks_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for StartExecuteTasks_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartExecuteTasks_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartExecuteTasks_Response {
  type RmwMsg = super::srv::rmw::StartExecuteTasks_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartMapping_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMapping_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub rosbag: std::string::String,

    /// indoor/outdoor
    pub map_type: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub community: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: std::string::String,

}



impl Default for StartMapping_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartMapping_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartMapping_Request {
  type RmwMsg = super::srv::rmw::StartMapping_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        rosbag: msg.rosbag.as_str().into(),
        map_type: msg.map_type.as_str().into(),
        community: msg.community.as_str().into(),
        building: msg.building.as_str().into(),
        unit: msg.unit.as_str().into(),
        floor: msg.floor.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        rosbag: msg.rosbag.as_str().into(),
        map_type: msg.map_type.as_str().into(),
        community: msg.community.as_str().into(),
        building: msg.building.as_str().into(),
        unit: msg.unit.as_str().into(),
        floor: msg.floor.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      rosbag: msg.rosbag.to_string(),
      map_type: msg.map_type.to_string(),
      community: msg.community.to_string(),
      building: msg.building.to_string(),
      unit: msg.unit.to_string(),
      floor: msg.floor.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartMapping_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMapping_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for StartMapping_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartMapping_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartMapping_Response {
  type RmwMsg = super::srv::rmw::StartMapping_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
    }
  }
}


// Corresponds to master_interfaces__srv__StartMultiTasksExecute_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMultiTasksExecute_Request {
    /// Community directory name under /opt/ry/data/tasks/multi_tasks
    pub community: std::string::String,

    /// Whether to start by executing sub_outdoor_eguard.json
    pub out_eguard: bool,

    /// true: finish with sub_outdoor_eguard_r.json
    /// false: finish by returning to the task-start pose recorded from odom -> base_footprint
    pub return_origin: bool,

    /// Ordered delivery sequence.
    /// Example:
    /// [{building: "3", unit: "2", floor: "5", door: "102", cargo_type: 0, delivery_code: "1sdajlf"}]
    pub tasks_seqs: Vec<super::msg::MultiTaskDestination>,

    /// Task tracking UUID
    pub task_uuid: std::string::String,

}



impl Default for StartMultiTasksExecute_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartMultiTasksExecute_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartMultiTasksExecute_Request {
  type RmwMsg = super::srv::rmw::StartMultiTasksExecute_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
        out_eguard: msg.out_eguard,
        return_origin: msg.return_origin,
        tasks_seqs: msg.tasks_seqs
          .into_iter()
          .map(|elem| super::msg::MultiTaskDestination::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        task_uuid: msg.task_uuid.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        community: msg.community.as_str().into(),
      out_eguard: msg.out_eguard,
      return_origin: msg.return_origin,
        tasks_seqs: msg.tasks_seqs
          .iter()
          .map(|elem| super::msg::MultiTaskDestination::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        task_uuid: msg.task_uuid.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      community: msg.community.to_string(),
      out_eguard: msg.out_eguard,
      return_origin: msg.return_origin,
      tasks_seqs: msg.tasks_seqs
          .into_iter()
          .map(super::msg::MultiTaskDestination::from_rmw_message)
          .collect(),
      task_uuid: msg.task_uuid.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartMultiTasksExecute_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMultiTasksExecute_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for StartMultiTasksExecute_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartMultiTasksExecute_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartMultiTasksExecute_Response {
  type RmwMsg = super::srv::rmw::StartMultiTasksExecute_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartNavigateTodoor_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartNavigateTodoor_Request {
    /// Request
    /// 路径点数组
    pub waypoints: Vec<super::msg::NavigateWaypoint>,

}



impl Default for StartNavigateTodoor_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartNavigateTodoor_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartNavigateTodoor_Request {
  type RmwMsg = super::srv::rmw::StartNavigateTodoor_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoints: msg.waypoints
          .into_iter()
          .map(|elem| super::msg::NavigateWaypoint::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoints: msg.waypoints
          .iter()
          .map(|elem| super::msg::NavigateWaypoint::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      waypoints: msg.waypoints
          .into_iter()
          .map(super::msg::NavigateWaypoint::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartNavigateTodoor_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartNavigateTodoor_Response {
    /// Response
    /// 服务是否成功启动
    pub success: bool,

    /// 返回消息
    pub message: std::string::String,

    /// 总路径点数量
    pub total_waypoints: i32,

    /// 任务路径点数量
    pub task_waypoints: i32,

    /// 路径点分组数量
    pub waypoint_groups: i32,

}



impl Default for StartNavigateTodoor_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartNavigateTodoor_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartNavigateTodoor_Response {
  type RmwMsg = super::srv::rmw::StartNavigateTodoor_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
        total_waypoints: msg.total_waypoints,
        task_waypoints: msg.task_waypoints,
        waypoint_groups: msg.waypoint_groups,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      total_waypoints: msg.total_waypoints,
      task_waypoints: msg.task_waypoints,
      waypoint_groups: msg.waypoint_groups,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
      total_waypoints: msg.total_waypoints,
      task_waypoints: msg.task_waypoints,
      waypoint_groups: msg.waypoint_groups,
    }
  }
}


// Corresponds to master_interfaces__srv__StartPlan_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartPlan_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub json_url: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_type: std::string::String,

}



impl Default for StartPlan_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartPlan_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartPlan_Request {
  type RmwMsg = super::srv::rmw::StartPlan_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        json_url: msg.json_url.as_str().into(),
        task_type: msg.task_type.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        json_url: msg.json_url.as_str().into(),
        task_type: msg.task_type.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      json_url: msg.json_url.to_string(),
      task_type: msg.task_type.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartPlan_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartPlan_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub code: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub msg: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_id: std::string::String,

}



impl Default for StartPlan_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartPlan_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartPlan_Response {
  type RmwMsg = super::srv::rmw::StartPlan_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        code: msg.code,
        msg: msg.msg.as_str().into(),
        task_id: msg.task_id.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      code: msg.code,
        msg: msg.msg.as_str().into(),
        task_id: msg.task_id.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      code: msg.code,
      msg: msg.msg.to_string(),
      task_id: msg.task_id.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartRecord_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecord_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bag_name: std::string::String,

}



impl Default for StartRecord_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartRecord_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartRecord_Request {
  type RmwMsg = super::srv::rmw::StartRecord_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        bag_name: msg.bag_name.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        bag_name: msg.bag_name.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      bag_name: msg.bag_name.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StartRecord_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecord_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for StartRecord_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartRecord_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartRecord_Response {
  type RmwMsg = super::srv::rmw::StartRecord_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
    }
  }
}


// Corresponds to master_interfaces__srv__StartRecordPath_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecordPath_Request {
    /// online/offline
    pub mode: std::string::String,

    /// community/building-unit/floor-door
    pub type_: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub community: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub path_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bag_path: std::string::String,

    /// 采点间隔
    pub point_interval: f64,

}



impl Default for StartRecordPath_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartRecordPath_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StartRecordPath_Request {
  type RmwMsg = super::srv::rmw::StartRecordPath_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mode: msg.mode.as_str().into(),
        type_: msg.type_.as_str().into(),
        community: msg.community.as_str().into(),
        building: msg.building,
        unit: msg.unit,
        floor: msg.floor,
        door: msg.door,
        path_name: msg.path_name.as_str().into(),
        bag_path: msg.bag_path.as_str().into(),
        point_interval: msg.point_interval,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mode: msg.mode.as_str().into(),
        type_: msg.type_.as_str().into(),
        community: msg.community.as_str().into(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
        path_name: msg.path_name.as_str().into(),
        bag_path: msg.bag_path.as_str().into(),
      point_interval: msg.point_interval,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      mode: msg.mode.to_string(),
      type_: msg.type_.to_string(),
      community: msg.community.to_string(),
      building: msg.building,
      unit: msg.unit,
      floor: msg.floor,
      door: msg.door,
      path_name: msg.path_name.to_string(),
      bag_path: msg.bag_path.to_string(),
      point_interval: msg.point_interval,
    }
  }
}


// Corresponds to master_interfaces__srv__StartRecordPath_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecordPath_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for StartRecordPath_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StartRecordPath_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StartRecordPath_Response {
  type RmwMsg = super::srv::rmw::StartRecordPath_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
    }
  }
}


// Corresponds to master_interfaces__srv__StopPlayback_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopPlayback_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for StopPlayback_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StopPlayback_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StopPlayback_Request {
  type RmwMsg = super::srv::rmw::StopPlayback_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__StopPlayback_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopPlayback_Response {
    /// 是否成功停止
    pub success: bool,

    /// 返回消息
    pub message: std::string::String,

}



impl Default for StopPlayback_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StopPlayback_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StopPlayback_Response {
  type RmwMsg = super::srv::rmw::StopPlayback_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__StopRecordPath_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopRecordPath_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for StopRecordPath_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StopRecordPath_Request::default())
  }
}

impl rosidl_runtime_rs::Message for StopRecordPath_Request {
  type RmwMsg = super::srv::rmw::StopRecordPath_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


// Corresponds to master_interfaces__srv__StopRecordPath_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopRecordPath_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub path: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i32,

}



impl Default for StopRecordPath_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::StopRecordPath_Response::default())
  }
}

impl rosidl_runtime_rs::Message for StopRecordPath_Response {
  type RmwMsg = super::srv::rmw::StopRecordPath_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        path: msg.path.as_str().into(),
        num: msg.num,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        path: msg.path.as_str().into(),
      num: msg.num,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      path: msg.path.to_string(),
      num: msg.num,
    }
  }
}


// Corresponds to master_interfaces__srv__String_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct String_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub name: std::string::String,

}



impl Default for String_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::String_Request::default())
  }
}

impl rosidl_runtime_rs::Message for String_Request {
  type RmwMsg = super::srv::rmw::String_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        name: msg.name.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        name: msg.name.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      name: msg.name.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__String_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct String_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for String_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::String_Response::default())
  }
}

impl rosidl_runtime_rs::Message for String_Response {
  type RmwMsg = super::srv::rmw::String_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__SwitchMap_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SwitchMap_Request {
    /// 请求字段
    /// 地图 YAML 文件的完整路径（含文件名）
    pub map_yaml_path: std::string::String,

    /// PCD 文件的完整路径（含文件名）
    pub pcd_path: std::string::String,

}



impl Default for SwitchMap_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SwitchMap_Request::default())
  }
}

impl rosidl_runtime_rs::Message for SwitchMap_Request {
  type RmwMsg = super::srv::rmw::SwitchMap_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        map_yaml_path: msg.map_yaml_path.as_str().into(),
        pcd_path: msg.pcd_path.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        map_yaml_path: msg.map_yaml_path.as_str().into(),
        pcd_path: msg.pcd_path.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      map_yaml_path: msg.map_yaml_path.to_string(),
      pcd_path: msg.pcd_path.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__SwitchMap_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SwitchMap_Response {
    /// 响应字段
    /// 服务调用是否成功
    pub success: bool,

    /// 返回的消息或错误说明
    pub message: std::string::String,

}



impl Default for SwitchMap_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SwitchMap_Response::default())
  }
}

impl rosidl_runtime_rs::Message for SwitchMap_Response {
  type RmwMsg = super::srv::rmw::SwitchMap_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__VisionElevatorStatus_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Request {
    /// True=开启检测，False=关闭检测
    pub enable: bool,

    /// 小车状态，进电梯=in,出电梯=out
    pub car_status: std::string::String,

}



impl Default for VisionElevatorStatus_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::VisionElevatorStatus_Request::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Request {
  type RmwMsg = super::srv::rmw::VisionElevatorStatus_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        enable: msg.enable,
        car_status: msg.car_status.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      enable: msg.enable,
        car_status: msg.car_status.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      enable: msg.enable,
      car_status: msg.car_status.to_string(),
    }
  }
}


// Corresponds to master_interfaces__srv__VisionElevatorStatus_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Response {
    /// 门状态：open/closed/half-open/unknown/error
    pub door_state: std::string::String,

    /// 检测置信度（%）
    pub confidence: f32,

    /// 操作是否成功（True/False）
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for VisionElevatorStatus_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::VisionElevatorStatus_Response::default())
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Response {
  type RmwMsg = super::srv::rmw::VisionElevatorStatus_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        door_state: msg.door_state.as_str().into(),
        confidence: msg.confidence,
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        door_state: msg.door_state.as_str().into(),
      confidence: msg.confidence,
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      door_state: msg.door_state.to_string(),
      confidence: msg.confidence,
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}






#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__AddPathPoints() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__AddPathPoints
#[allow(missing_docs, non_camel_case_types)]
pub struct AddPathPoints;

impl rosidl_runtime_rs::Service for AddPathPoints {
    type Request = AddPathPoints_Request;
    type Response = AddPathPoints_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__AddPathPoints() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelNavigation() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CancelNavigation
#[allow(missing_docs, non_camel_case_types)]
pub struct CancelNavigation;

impl rosidl_runtime_rs::Service for CancelNavigation {
    type Request = CancelNavigation_Request;
    type Response = CancelNavigation_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelNavigation() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecord() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CancelRecord
#[allow(missing_docs, non_camel_case_types)]
pub struct CancelRecord;

impl rosidl_runtime_rs::Service for CancelRecord {
    type Request = CancelRecord_Request;
    type Response = CancelRecord_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecord() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecordPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CancelRecordPath
#[allow(missing_docs, non_camel_case_types)]
pub struct CancelRecordPath;

impl rosidl_runtime_rs::Service for CancelRecordPath {
    type Request = CancelRecordPath_Request;
    type Response = CancelRecordPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecordPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CaptureCurrentPoint() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CaptureCurrentPoint
#[allow(missing_docs, non_camel_case_types)]
pub struct CaptureCurrentPoint;

impl rosidl_runtime_rs::Service for CaptureCurrentPoint {
    type Request = CaptureCurrentPoint_Request;
    type Response = CaptureCurrentPoint_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CaptureCurrentPoint() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ChangeLocalizer() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ChangeLocalizer
#[allow(missing_docs, non_camel_case_types)]
pub struct ChangeLocalizer;

impl rosidl_runtime_rs::Service for ChangeLocalizer {
    type Request = ChangeLocalizer_Request;
    type Response = ChangeLocalizer_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ChangeLocalizer() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CheckBuildingOccupancy
#[allow(missing_docs, non_camel_case_types)]
pub struct CheckBuildingOccupancy;

impl rosidl_runtime_rs::Service for CheckBuildingOccupancy {
    type Request = CheckBuildingOccupancy_Request;
    type Response = CheckBuildingOccupancy_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeleteBag() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__DeleteBag
#[allow(missing_docs, non_camel_case_types)]
pub struct DeleteBag;

impl rosidl_runtime_rs::Service for DeleteBag {
    type Request = DeleteBag_Request;
    type Response = DeleteBag_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeleteBag() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeletePathPoints() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__DeletePathPoints
#[allow(missing_docs, non_camel_case_types)]
pub struct DeletePathPoints;

impl rosidl_runtime_rs::Service for DeletePathPoints {
    type Request = DeletePathPoints_Request;
    type Response = DeletePathPoints_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeletePathPoints() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DoorControl() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__DoorControl
#[allow(missing_docs, non_camel_case_types)]
pub struct DoorControl;

impl rosidl_runtime_rs::Service for DoorControl {
    type Request = DoorControl_Request;
    type Response = DoorControl_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DoorControl() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EditTaskWaypoint() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__EditTaskWaypoint
#[allow(missing_docs, non_camel_case_types)]
pub struct EditTaskWaypoint;

impl rosidl_runtime_rs::Service for EditTaskWaypoint {
    type Request = EditTaskWaypoint_Request;
    type Response = EditTaskWaypoint_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EditTaskWaypoint() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EndRecord() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__EndRecord
#[allow(missing_docs, non_camel_case_types)]
pub struct EndRecord;

impl rosidl_runtime_rs::Service for EndRecord {
    type Request = EndRecord_Request;
    type Response = EndRecord_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EndRecord() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__FollowPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__FollowPath
#[allow(missing_docs, non_camel_case_types)]
pub struct FollowPath;

impl rosidl_runtime_rs::Service for FollowPath {
    type Request = FollowPath_Request;
    type Response = FollowPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__FollowPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GenerateTask() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GenerateTask
#[allow(missing_docs, non_camel_case_types)]
pub struct GenerateTask;

impl rosidl_runtime_rs::Service for GenerateTask {
    type Request = GenerateTask_Request;
    type Response = GenerateTask_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GenerateTask() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetBagList() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetBagList
#[allow(missing_docs, non_camel_case_types)]
pub struct GetBagList;

impl rosidl_runtime_rs::Service for GetBagList {
    type Request = GetBagList_Request;
    type Response = GetBagList_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetBagList() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetCargoStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetCargoStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct GetCargoStatus;

impl rosidl_runtime_rs::Service for GetCargoStatus {
    type Request = GetCargoStatus_Request;
    type Response = GetCargoStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetCargoStatus() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetElevatorId() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetElevatorId
#[allow(missing_docs, non_camel_case_types)]
pub struct GetElevatorId;

impl rosidl_runtime_rs::Service for GetElevatorId {
    type Request = GetElevatorId_Request;
    type Response = GetElevatorId_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetElevatorId() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetEmergencyStop() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetEmergencyStop
#[allow(missing_docs, non_camel_case_types)]
pub struct GetEmergencyStop;

impl rosidl_runtime_rs::Service for GetEmergencyStop {
    type Request = GetEmergencyStop_Request;
    type Response = GetEmergencyStop_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetEmergencyStop() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetNavigationStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetNavigationStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct GetNavigationStatus;

impl rosidl_runtime_rs::Service for GetNavigationStatus {
    type Request = GetNavigationStatus_Request;
    type Response = GetNavigationStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetNavigationStatus() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathList() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetPathList
#[allow(missing_docs, non_camel_case_types)]
pub struct GetPathList;

impl rosidl_runtime_rs::Service for GetPathList {
    type Request = GetPathList_Request;
    type Response = GetPathList_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathList() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathPoints() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetPathPoints
#[allow(missing_docs, non_camel_case_types)]
pub struct GetPathPoints;

impl rosidl_runtime_rs::Service for GetPathPoints {
    type Request = GetPathPoints_Request;
    type Response = GetPathPoints_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathPoints() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPlanStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetPlanStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct GetPlanStatus;

impl rosidl_runtime_rs::Service for GetPlanStatus {
    type Request = GetPlanStatus_Request;
    type Response = GetPlanStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPlanStatus() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateThroughPoses() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__NavigateThroughPoses
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateThroughPoses;

impl rosidl_runtime_rs::Service for NavigateThroughPoses {
    type Request = NavigateThroughPoses_Request;
    type Response = NavigateThroughPoses_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateThroughPoses() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateToPose() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__NavigateToPose
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateToPose;

impl rosidl_runtime_rs::Service for NavigateToPose {
    type Request = NavigateToPose_Request;
    type Response = NavigateToPose_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateToPose() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NodeString() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__NodeString
#[allow(missing_docs, non_camel_case_types)]
pub struct NodeString;

impl rosidl_runtime_rs::Service for NodeString {
    type Request = NodeString_Request;
    type Response = NodeString_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NodeString() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__PGOMapping() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__PGOMapping
#[allow(missing_docs, non_camel_case_types)]
pub struct PGOMapping;

impl rosidl_runtime_rs::Service for PGOMapping {
    type Request = PGOMapping_Request;
    type Response = PGOMapping_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__PGOMapping() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__Ping() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__Ping
#[allow(missing_docs, non_camel_case_types)]
pub struct Ping;

impl rosidl_runtime_rs::Service for Ping {
    type Request = Ping_Request;
    type Response = Ping_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__Ping() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReportException() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ReportException
#[allow(missing_docs, non_camel_case_types)]
pub struct ReportException;

impl rosidl_runtime_rs::Service for ReportException {
    type Request = ReportException_Request;
    type Response = ReportException_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReportException() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ResetTaskWaypoint() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ResetTaskWaypoint
#[allow(missing_docs, non_camel_case_types)]
pub struct ResetTaskWaypoint;

impl rosidl_runtime_rs::Service for ResetTaskWaypoint {
    type Request = ResetTaskWaypoint_Request;
    type Response = ResetTaskWaypoint_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ResetTaskWaypoint() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReturnHome() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ReturnHome
#[allow(missing_docs, non_camel_case_types)]
pub struct ReturnHome;

impl rosidl_runtime_rs::Service for ReturnHome {
    type Request = ReturnHome_Request;
    type Response = ReturnHome_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReturnHome() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartExecuteTasks() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartExecuteTasks
#[allow(missing_docs, non_camel_case_types)]
pub struct StartExecuteTasks;

impl rosidl_runtime_rs::Service for StartExecuteTasks {
    type Request = StartExecuteTasks_Request;
    type Response = StartExecuteTasks_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartExecuteTasks() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMapping() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartMapping
#[allow(missing_docs, non_camel_case_types)]
pub struct StartMapping;

impl rosidl_runtime_rs::Service for StartMapping {
    type Request = StartMapping_Request;
    type Response = StartMapping_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMapping() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMultiTasksExecute() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartMultiTasksExecute
#[allow(missing_docs, non_camel_case_types)]
pub struct StartMultiTasksExecute;

impl rosidl_runtime_rs::Service for StartMultiTasksExecute {
    type Request = StartMultiTasksExecute_Request;
    type Response = StartMultiTasksExecute_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMultiTasksExecute() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartNavigateTodoor() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartNavigateTodoor
#[allow(missing_docs, non_camel_case_types)]
pub struct StartNavigateTodoor;

impl rosidl_runtime_rs::Service for StartNavigateTodoor {
    type Request = StartNavigateTodoor_Request;
    type Response = StartNavigateTodoor_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartNavigateTodoor() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartPlan() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartPlan
#[allow(missing_docs, non_camel_case_types)]
pub struct StartPlan;

impl rosidl_runtime_rs::Service for StartPlan {
    type Request = StartPlan_Request;
    type Response = StartPlan_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartPlan() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecord() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartRecord
#[allow(missing_docs, non_camel_case_types)]
pub struct StartRecord;

impl rosidl_runtime_rs::Service for StartRecord {
    type Request = StartRecord_Request;
    type Response = StartRecord_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecord() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecordPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartRecordPath
#[allow(missing_docs, non_camel_case_types)]
pub struct StartRecordPath;

impl rosidl_runtime_rs::Service for StartRecordPath {
    type Request = StartRecordPath_Request;
    type Response = StartRecordPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecordPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopPlayback() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StopPlayback
#[allow(missing_docs, non_camel_case_types)]
pub struct StopPlayback;

impl rosidl_runtime_rs::Service for StopPlayback {
    type Request = StopPlayback_Request;
    type Response = StopPlayback_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopPlayback() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopRecordPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StopRecordPath
#[allow(missing_docs, non_camel_case_types)]
pub struct StopRecordPath;

impl rosidl_runtime_rs::Service for StopRecordPath {
    type Request = StopRecordPath_Request;
    type Response = StopRecordPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopRecordPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__String() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__String
#[allow(missing_docs, non_camel_case_types)]
pub struct String;

impl rosidl_runtime_rs::Service for String {
    type Request = String_Request;
    type Response = String_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__String() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__SwitchMap() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__SwitchMap
#[allow(missing_docs, non_camel_case_types)]
pub struct SwitchMap;

impl rosidl_runtime_rs::Service for SwitchMap {
    type Request = SwitchMap_Request;
    type Response = SwitchMap_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__SwitchMap() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__VisionElevatorStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__VisionElevatorStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus;

impl rosidl_runtime_rs::Service for VisionElevatorStatus {
    type Request = VisionElevatorStatus_Request;
    type Response = VisionElevatorStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__VisionElevatorStatus() }
    }
}


