#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to master_interfaces__msg__BagInfo
/// 数据包信息

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BagInfo {
    /// 数据包名称
    pub name: std::string::String,

    /// 数据包完整路径
    pub path: std::string::String,

    /// 数据包大小（字节）
    pub size_bytes: i64,

    /// 创建时间（Unix 时间戳，秒）
    pub creation_time: i64,

    /// 录制时长（纳秒）
    pub duration_ns: i64,

    /// 消息总数
    pub message_count: i32,

}



impl Default for BagInfo {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BagInfo::default())
  }
}

impl rosidl_runtime_rs::Message for BagInfo {
  type RmwMsg = super::msg::rmw::BagInfo;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        name: msg.name.as_str().into(),
        path: msg.path.as_str().into(),
        size_bytes: msg.size_bytes,
        creation_time: msg.creation_time,
        duration_ns: msg.duration_ns,
        message_count: msg.message_count,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        name: msg.name.as_str().into(),
        path: msg.path.as_str().into(),
      size_bytes: msg.size_bytes,
      creation_time: msg.creation_time,
      duration_ns: msg.duration_ns,
      message_count: msg.message_count,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      name: msg.name.to_string(),
      path: msg.path.to_string(),
      size_bytes: msg.size_bytes,
      creation_time: msg.creation_time,
      duration_ns: msg.duration_ns,
      message_count: msg.message_count,
    }
  }
}


// Corresponds to master_interfaces__msg__Carbuilding

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Carbuilding {

    // This member is not documented.
    #[allow(missing_docs)]
    pub car_id: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building_id: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ent_status: std::string::String,

}



impl Default for Carbuilding {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Carbuilding::default())
  }
}

impl rosidl_runtime_rs::Message for Carbuilding {
  type RmwMsg = super::msg::rmw::Carbuilding;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        car_id: msg.car_id.as_str().into(),
        building_id: msg.building_id.as_str().into(),
        ent_status: msg.ent_status.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        car_id: msg.car_id.as_str().into(),
        building_id: msg.building_id.as_str().into(),
        ent_status: msg.ent_status.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      car_id: msg.car_id.to_string(),
      building_id: msg.building_id.to_string(),
      ent_status: msg.ent_status.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__ErrorCode
/// 标准错误码定义

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ErrorCode {
    /// 当前错误码
    pub code: i32,

    /// 错误详细描述
    pub description: std::string::String,

}

impl ErrorCode {
    /// 操作成功
    pub const SUCCESS: i32 = 0;

    /// 未知错误
    pub const UNKNOWN_ERROR: i32 = 1000;

    /// 网络通信错误
    pub const NETWORK_ERROR: i32 = 1001;

    /// 无效参数
    pub const INVALID_PARAMETER: i32 = 1002;

    /// 服务不可用
    pub const SERVICE_UNAVAILABLE: i32 = 1003;

    /// 操作超时
    pub const TIMEOUT: i32 = 1004;

    /// 资源不存在
    pub const RESOURCE_NOT_FOUND: i32 = 1005;

    /// 权限不足
    pub const PERMISSION_DENIED: i32 = 1006;

    /// 硬件错误
    pub const HARDWARE_ERROR: i32 = 2000;

    /// 导航相关错误
    pub const NAVIGATION_ERROR: i32 = 3000;

}


impl Default for ErrorCode {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ErrorCode::default())
  }
}

impl rosidl_runtime_rs::Message for ErrorCode {
  type RmwMsg = super::msg::rmw::ErrorCode;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        code: msg.code,
        description: msg.description.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      code: msg.code,
        description: msg.description.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      code: msg.code,
      description: msg.description.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__MultiTaskDestination
/// MultiTaskDestination.msg - One destination in a multi-point delivery sequence

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MultiTaskDestination {

    // This member is not documented.
    #[allow(missing_docs)]
    pub building: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_type: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub delivery_code: std::string::String,

}



impl Default for MultiTaskDestination {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MultiTaskDestination::default())
  }
}

impl rosidl_runtime_rs::Message for MultiTaskDestination {
  type RmwMsg = super::msg::rmw::MultiTaskDestination;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        building: msg.building.as_str().into(),
        unit: msg.unit.as_str().into(),
        floor: msg.floor.as_str().into(),
        door: msg.door.as_str().into(),
        cargo_type: msg.cargo_type,
        delivery_code: msg.delivery_code.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        building: msg.building.as_str().into(),
        unit: msg.unit.as_str().into(),
        floor: msg.floor.as_str().into(),
        door: msg.door.as_str().into(),
      cargo_type: msg.cargo_type,
        delivery_code: msg.delivery_code.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      building: msg.building.to_string(),
      unit: msg.unit.to_string(),
      floor: msg.floor.to_string(),
      door: msg.door.to_string(),
      cargo_type: msg.cargo_type,
      delivery_code: msg.delivery_code.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__NavigateTodoorStatus
/// NavigateTodoorStatus.msg - 导航到户详细状态消息
/// 用于发布导航到户任务的详细进度信息

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateTodoorStatus {
    /// 时间戳
    pub stamp: builtin_interfaces::msg::Time,

    /// 导航状态
    /// 状态: "idle", "navigating", "task_executing", "completed", "failed", "successful"
    pub status: std::string::String,

    /// 当前路径点信息
    /// 当前路径点ID
    pub current_waypoint_id: std::string::String,

    /// 当前路径点索引（从0开始）
    pub current_waypoint_index: i32,

    /// 当前路径点位姿
    pub current_pose: geometry_msgs::msg::Pose,

    /// 当前速度模式
    pub current_speed_mode: std::string::String,

    /// 当前任务描述（如果有）
    pub current_task: std::string::String,

    /// 进度信息
    /// 总路径点数
    pub total_waypoints: i32,

    /// 已完成路径点数
    pub completed_waypoints: i32,

    /// 剩余路径点数
    pub remaining_waypoints: i32,

    /// 完成百分比 (0-100)
    pub progress_percentage: f32,

    /// 分组信息
    /// 总分组数
    pub total_groups: i32,

    /// 当前分组索引（从0开始）
    pub current_group_index: i32,

    /// 当前分组内的路径点数
    pub current_group_waypoints: i32,

    /// 已完成分组数
    pub completed_groups: i32,

    /// 距离和时间信息
    /// 距离当前目标的距离（米）
    pub distance_to_current_goal: f32,

    /// 已用时间（秒）
    pub elapsed_time: f32,

    /// 错误信息（如果有）
    /// 错误描述信息
    pub error_message: std::string::String,

}



impl Default for NavigateTodoorStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::NavigateTodoorStatus::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateTodoorStatus {
  type RmwMsg = super::msg::rmw::NavigateTodoorStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
        status: msg.status.as_str().into(),
        current_waypoint_id: msg.current_waypoint_id.as_str().into(),
        current_waypoint_index: msg.current_waypoint_index,
        current_pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.current_pose)).into_owned(),
        current_speed_mode: msg.current_speed_mode.as_str().into(),
        current_task: msg.current_task.as_str().into(),
        total_waypoints: msg.total_waypoints,
        completed_waypoints: msg.completed_waypoints,
        remaining_waypoints: msg.remaining_waypoints,
        progress_percentage: msg.progress_percentage,
        total_groups: msg.total_groups,
        current_group_index: msg.current_group_index,
        current_group_waypoints: msg.current_group_waypoints,
        completed_groups: msg.completed_groups,
        distance_to_current_goal: msg.distance_to_current_goal,
        elapsed_time: msg.elapsed_time,
        error_message: msg.error_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
        status: msg.status.as_str().into(),
        current_waypoint_id: msg.current_waypoint_id.as_str().into(),
      current_waypoint_index: msg.current_waypoint_index,
        current_pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.current_pose)).into_owned(),
        current_speed_mode: msg.current_speed_mode.as_str().into(),
        current_task: msg.current_task.as_str().into(),
      total_waypoints: msg.total_waypoints,
      completed_waypoints: msg.completed_waypoints,
      remaining_waypoints: msg.remaining_waypoints,
      progress_percentage: msg.progress_percentage,
      total_groups: msg.total_groups,
      current_group_index: msg.current_group_index,
      current_group_waypoints: msg.current_group_waypoints,
      completed_groups: msg.completed_groups,
      distance_to_current_goal: msg.distance_to_current_goal,
      elapsed_time: msg.elapsed_time,
        error_message: msg.error_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
      status: msg.status.to_string(),
      current_waypoint_id: msg.current_waypoint_id.to_string(),
      current_waypoint_index: msg.current_waypoint_index,
      current_pose: geometry_msgs::msg::Pose::from_rmw_message(msg.current_pose),
      current_speed_mode: msg.current_speed_mode.to_string(),
      current_task: msg.current_task.to_string(),
      total_waypoints: msg.total_waypoints,
      completed_waypoints: msg.completed_waypoints,
      remaining_waypoints: msg.remaining_waypoints,
      progress_percentage: msg.progress_percentage,
      total_groups: msg.total_groups,
      current_group_index: msg.current_group_index,
      current_group_waypoints: msg.current_group_waypoints,
      completed_groups: msg.completed_groups,
      distance_to_current_goal: msg.distance_to_current_goal,
      elapsed_time: msg.elapsed_time,
      error_message: msg.error_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__NavigateWaypoint
/// NavigateWaypoint.msg - 导航路径点消息
/// 包含位姿、速度模式和任务信息

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateWaypoint {
    /// 路径点唯一标识符（可选，为空表示无ID）
    pub waypoint_id: std::string::String,

    /// 路径点位姿（位置和方向）
    pub pose: geometry_msgs::msg::Pose,

    /// 速度模式（行为树文件路径）
    pub speed_mode: std::string::String,

    /// 路径点任务（行为树文件路径，空字符串表示无任务）
    pub waypoint_task: std::string::String,

}



impl Default for NavigateWaypoint {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::NavigateWaypoint::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateWaypoint {
  type RmwMsg = super::msg::rmw::NavigateWaypoint;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoint_id: msg.waypoint_id.as_str().into(),
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
        speed_mode: msg.speed_mode.as_str().into(),
        waypoint_task: msg.waypoint_task.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoint_id: msg.waypoint_id.as_str().into(),
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
        speed_mode: msg.speed_mode.as_str().into(),
        waypoint_task: msg.waypoint_task.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      waypoint_id: msg.waypoint_id.to_string(),
      pose: geometry_msgs::msg::Pose::from_rmw_message(msg.pose),
      speed_mode: msg.speed_mode.to_string(),
      waypoint_task: msg.waypoint_task.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__NavigateWaypointArray
/// NavigateWaypointArray.msg - 导航路径点数组消息
/// 包含多个导航路径点

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateWaypointArray {
    /// 路径点数组
    pub waypoints: Vec<super::msg::NavigateWaypoint>,

}



impl Default for NavigateWaypointArray {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::NavigateWaypointArray::default())
  }
}

impl rosidl_runtime_rs::Message for NavigateWaypointArray {
  type RmwMsg = super::msg::rmw::NavigateWaypointArray;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoints: msg.waypoints
          .into_iter()
          .map(|elem| super::msg::NavigateWaypoint::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        waypoints: msg.waypoints
          .iter()
          .map(|elem| super::msg::NavigateWaypoint::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      waypoints: msg.waypoints
          .into_iter()
          .map(super::msg::NavigateWaypoint::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to master_interfaces__msg__NavigationStatus
/// NavigationStatus.msg - 导航状态消息
///
/// 描述导航任务的详细状态信息
/// 用于导航状态查询和监控

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigationStatus {
    /// 任务ID
    pub task_id: std::string::String,

    /// 任务状态
    pub status: u8,

    /// 目标位姿
    pub target_pose: geometry_msgs::msg::PoseStamped,

    /// 当前位姿
    pub current_pose: geometry_msgs::msg::PoseStamped,

    /// 剩余距离 (米)
    pub remaining_distance: f64,

    /// 预计剩余时间 (秒)
    pub estimated_time_remaining: f64,

    /// 导航进度 (0.0 - 1.0)
    pub progress: f64,

    /// 当前使用的规划器ID
    pub current_planner_id: std::string::String,

    /// 当前使用的控制器ID
    pub current_controller_id: std::string::String,

    /// 任务创建时间
    pub created_time: builtin_interfaces::msg::Time,

    /// 任务开始时间
    pub started_time: builtin_interfaces::msg::Time,

    /// 任务完成时间 (如果已完成)
    pub completed_time: builtin_interfaces::msg::Time,

    /// 错误信息 (如果失败)
    pub error_message: std::string::String,

    /// 航点类型 (用于业务逻辑识别)
    pub waypoint_type: std::string::String,

    /// 导航相关的额外数据 (JSON格式)
    pub navigation_data: std::string::String,

}

impl NavigationStatus {
    /// 导航状态常量定义
    /// 等待中 - 任务已创建但未开始
    pub const PENDING: u8 = 0;

    /// 规划中 - 正在计算路径
    pub const PLANNING: u8 = 1;

    /// 执行中 - 正在导航
    pub const RUNNING: u8 = 2;

    /// 成功 - 导航任务成功完成
    pub const SUCCEEDED: u8 = 3;

    /// 失败 - 导航任务失败
    pub const FAILED: u8 = 4;

    /// 已取消 - 导航任务被取消
    pub const CANCELLED: u8 = 5;

    /// 暂停中 - 导航任务暂停
    pub const PAUSED: u8 = 6;

}


impl Default for NavigationStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::NavigationStatus::default())
  }
}

impl rosidl_runtime_rs::Message for NavigationStatus {
  type RmwMsg = super::msg::rmw::NavigationStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
        status: msg.status,
        target_pose: geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Owned(msg.target_pose)).into_owned(),
        current_pose: geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Owned(msg.current_pose)).into_owned(),
        remaining_distance: msg.remaining_distance,
        estimated_time_remaining: msg.estimated_time_remaining,
        progress: msg.progress,
        current_planner_id: msg.current_planner_id.as_str().into(),
        current_controller_id: msg.current_controller_id.as_str().into(),
        created_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.created_time)).into_owned(),
        started_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.started_time)).into_owned(),
        completed_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.completed_time)).into_owned(),
        error_message: msg.error_message.as_str().into(),
        waypoint_type: msg.waypoint_type.as_str().into(),
        navigation_data: msg.navigation_data.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
      status: msg.status,
        target_pose: geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Borrowed(&msg.target_pose)).into_owned(),
        current_pose: geometry_msgs::msg::PoseStamped::into_rmw_message(std::borrow::Cow::Borrowed(&msg.current_pose)).into_owned(),
      remaining_distance: msg.remaining_distance,
      estimated_time_remaining: msg.estimated_time_remaining,
      progress: msg.progress,
        current_planner_id: msg.current_planner_id.as_str().into(),
        current_controller_id: msg.current_controller_id.as_str().into(),
        created_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.created_time)).into_owned(),
        started_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.started_time)).into_owned(),
        completed_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.completed_time)).into_owned(),
        error_message: msg.error_message.as_str().into(),
        waypoint_type: msg.waypoint_type.as_str().into(),
        navigation_data: msg.navigation_data.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_id: msg.task_id.to_string(),
      status: msg.status,
      target_pose: geometry_msgs::msg::PoseStamped::from_rmw_message(msg.target_pose),
      current_pose: geometry_msgs::msg::PoseStamped::from_rmw_message(msg.current_pose),
      remaining_distance: msg.remaining_distance,
      estimated_time_remaining: msg.estimated_time_remaining,
      progress: msg.progress,
      current_planner_id: msg.current_planner_id.to_string(),
      current_controller_id: msg.current_controller_id.to_string(),
      created_time: builtin_interfaces::msg::Time::from_rmw_message(msg.created_time),
      started_time: builtin_interfaces::msg::Time::from_rmw_message(msg.started_time),
      completed_time: builtin_interfaces::msg::Time::from_rmw_message(msg.completed_time),
      error_message: msg.error_message.to_string(),
      waypoint_type: msg.waypoint_type.to_string(),
      navigation_data: msg.navigation_data.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__PlanStatus
/// 任务状态骨架消息

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PlanStatus {
    /// 任务UID
    pub task_id: std::string::String,

    /// 任务状态
    pub state: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub detail: std::string::String,

}



impl Default for PlanStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PlanStatus::default())
  }
}

impl rosidl_runtime_rs::Message for PlanStatus {
  type RmwMsg = super::msg::rmw::PlanStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
        state: msg.state,
        detail: msg.detail.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        task_id: msg.task_id.as_str().into(),
      state: msg.state,
        detail: msg.detail.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      task_id: msg.task_id.to_string(),
      state: msg.state,
      detail: msg.detail.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__RobotState
/// RobotState.msg - 机器人综合状态信息
///
/// 提供机器人在某一时刻的完整运行状态，用于监控与调试。
/// 该消息与 master_SDK_server/RobotStateServer 实现保持一致。

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobotState {
    /// 标准头部（时间戳 + 坐标系）
    pub header: std_msgs::msg::Header,

    /// 机器人唯一标识（一般使用节点名或序列号）
    pub robot_id: std::string::String,

    /// 机器人位姿（包含协方差）
    pub pose: geometry_msgs::msg::PoseWithCovarianceStamped,

    /// 机器人速度（包含协方差）
    pub twist: geometry_msgs::msg::TwistWithCovariance,

    /// 电池电量百分比 (0-100)
    pub battery_percentage: f64,

    /// 电池电压 (V)
    pub battery_voltage: f64,

    /// 当前是否在充电
    pub is_charging: bool,

    /// 系统状态 (参考 master_interfaces/msg/SystemState 常量)
    pub system_state: u8,

    /// 系统状态文字描述
    pub state_description: std::string::String,

    /// 机器人已运行时间 (秒)
    pub uptime: f64,

    /// 健康状态文字描述，如 "健康"、"警告: 电池电量低"
    pub health_status: std::string::String,

    /// 与平台（MQTT / ROS2 等）的连接状态
    pub is_connected: bool,

    /// 错误信息（非空表示出现异常）
    pub error_message: std::string::String,

}



impl Default for RobotState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::RobotState::default())
  }
}

impl rosidl_runtime_rs::Message for RobotState {
  type RmwMsg = super::msg::rmw::RobotState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        robot_id: msg.robot_id.as_str().into(),
        pose: geometry_msgs::msg::PoseWithCovarianceStamped::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
        twist: geometry_msgs::msg::TwistWithCovariance::into_rmw_message(std::borrow::Cow::Owned(msg.twist)).into_owned(),
        battery_percentage: msg.battery_percentage,
        battery_voltage: msg.battery_voltage,
        is_charging: msg.is_charging,
        system_state: msg.system_state,
        state_description: msg.state_description.as_str().into(),
        uptime: msg.uptime,
        health_status: msg.health_status.as_str().into(),
        is_connected: msg.is_connected,
        error_message: msg.error_message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        robot_id: msg.robot_id.as_str().into(),
        pose: geometry_msgs::msg::PoseWithCovarianceStamped::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
        twist: geometry_msgs::msg::TwistWithCovariance::into_rmw_message(std::borrow::Cow::Borrowed(&msg.twist)).into_owned(),
      battery_percentage: msg.battery_percentage,
      battery_voltage: msg.battery_voltage,
      is_charging: msg.is_charging,
      system_state: msg.system_state,
        state_description: msg.state_description.as_str().into(),
      uptime: msg.uptime,
        health_status: msg.health_status.as_str().into(),
      is_connected: msg.is_connected,
        error_message: msg.error_message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      robot_id: msg.robot_id.to_string(),
      pose: geometry_msgs::msg::PoseWithCovarianceStamped::from_rmw_message(msg.pose),
      twist: geometry_msgs::msg::TwistWithCovariance::from_rmw_message(msg.twist),
      battery_percentage: msg.battery_percentage,
      battery_voltage: msg.battery_voltage,
      is_charging: msg.is_charging,
      system_state: msg.system_state,
      state_description: msg.state_description.to_string(),
      uptime: msg.uptime,
      health_status: msg.health_status.to_string(),
      is_connected: msg.is_connected,
      error_message: msg.error_message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__StandardResponse
/// 标准响应消息格式

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StandardResponse {
    /// 操作是否成功
    pub success: bool,

    /// 错误信息（success=false时使用）
    pub error_code: super::msg::ErrorCode,

    /// 响应时间戳
    pub timestamp: builtin_interfaces::msg::Time,

    /// 可选的额外数据
    pub data: std::string::String,

    /// 可选的额外消息
    pub message: std::string::String,

}



impl Default for StandardResponse {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::StandardResponse::default())
  }
}

impl rosidl_runtime_rs::Message for StandardResponse {
  type RmwMsg = super::msg::rmw::StandardResponse;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        error_code: super::msg::ErrorCode::into_rmw_message(std::borrow::Cow::Owned(msg.error_code)).into_owned(),
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
        data: msg.data.as_str().into(),
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        error_code: super::msg::ErrorCode::into_rmw_message(std::borrow::Cow::Borrowed(&msg.error_code)).into_owned(),
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
        data: msg.data.as_str().into(),
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      error_code: super::msg::ErrorCode::from_rmw_message(msg.error_code),
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
      data: msg.data.to_string(),
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__StateTransition
/// StateTransition.msg - 状态转换消息
///
/// 描述系统状态转换的详细信息
/// 用于状态机的状态转换记录和调试

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StateTransition {
    /// 转换ID (唯一标识符)
    pub transition_id: std::string::String,

    /// 源状态
    pub from_state: u8,

    /// 目标状态
    pub to_state: u8,

    /// 转换类型
    pub transition_type: u8,

    /// 转换结果
    pub transition_result: u8,

    /// 触发转换的事件或条件
    pub trigger_event: std::string::String,

    /// 转换开始时间
    pub transition_start_time: builtin_interfaces::msg::Time,

    /// 转换完成时间
    pub transition_end_time: builtin_interfaces::msg::Time,

    /// 转换持续时间 (毫秒)
    pub transition_duration_ms: i64,

    /// 转换原因或描述
    pub reason: std::string::String,

    /// 转换失败时的错误信息
    pub error_message: std::string::String,

    /// 转换相关的额外数据 (JSON格式)
    pub transition_data: std::string::String,

}

impl StateTransition {
    /// 转换类型常量
    /// 自动转换
    pub const AUTOMATIC: u8 = 0;

    /// 手动触发转换
    pub const MANUAL: u8 = 1;

    /// 事件触发转换
    pub const EVENT_TRIGGERED: u8 = 2;

    /// 错误触发转换
    pub const ERROR_TRIGGERED: u8 = 3;

    /// 超时触发转换
    pub const TIMEOUT_TRIGGERED: u8 = 4;

    /// 转换结果常量
    /// 转换成功
    pub const SUCCESS: u8 = 0;

    /// 转换失败
    pub const FAILED: u8 = 1;

    /// 转换被拒绝
    pub const REJECTED: u8 = 2;

    /// 转换进行中
    pub const PENDING: u8 = 3;

}


impl Default for StateTransition {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::StateTransition::default())
  }
}

impl rosidl_runtime_rs::Message for StateTransition {
  type RmwMsg = super::msg::rmw::StateTransition;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        transition_id: msg.transition_id.as_str().into(),
        from_state: msg.from_state,
        to_state: msg.to_state,
        transition_type: msg.transition_type,
        transition_result: msg.transition_result,
        trigger_event: msg.trigger_event.as_str().into(),
        transition_start_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.transition_start_time)).into_owned(),
        transition_end_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.transition_end_time)).into_owned(),
        transition_duration_ms: msg.transition_duration_ms,
        reason: msg.reason.as_str().into(),
        error_message: msg.error_message.as_str().into(),
        transition_data: msg.transition_data.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        transition_id: msg.transition_id.as_str().into(),
      from_state: msg.from_state,
      to_state: msg.to_state,
      transition_type: msg.transition_type,
      transition_result: msg.transition_result,
        trigger_event: msg.trigger_event.as_str().into(),
        transition_start_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.transition_start_time)).into_owned(),
        transition_end_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.transition_end_time)).into_owned(),
      transition_duration_ms: msg.transition_duration_ms,
        reason: msg.reason.as_str().into(),
        error_message: msg.error_message.as_str().into(),
        transition_data: msg.transition_data.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      transition_id: msg.transition_id.to_string(),
      from_state: msg.from_state,
      to_state: msg.to_state,
      transition_type: msg.transition_type,
      transition_result: msg.transition_result,
      trigger_event: msg.trigger_event.to_string(),
      transition_start_time: builtin_interfaces::msg::Time::from_rmw_message(msg.transition_start_time),
      transition_end_time: builtin_interfaces::msg::Time::from_rmw_message(msg.transition_end_time),
      transition_duration_ms: msg.transition_duration_ms,
      reason: msg.reason.to_string(),
      error_message: msg.error_message.to_string(),
      transition_data: msg.transition_data.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__SystemState
/// SystemState.msg - 系统状态消息
///
/// 定义机器人系统的宏观状态，用于状态机管理
/// 该消息描述了系统当前所处的主要状态

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SystemState {
    /// 当前系统状态
    pub current_state: u8,

    /// 前一个系统状态
    pub previous_state: u8,

    /// 状态描述信息
    pub state_description: std::string::String,

    /// 状态进入时间
    pub state_entered_time: builtin_interfaces::msg::Time,

    /// 状态持续时间 (秒)
    pub state_duration: f64,

    /// 状态相关的额外信息 (JSON格式)
    pub state_data: std::string::String,

}

impl SystemState {
    /// 状态常量定义
    /// 未知状态
    pub const UNKNOWN: u8 = 0;

    /// 初始化中
    pub const INITIALIZING: u8 = 1;

    /// 空闲状态 - 系统已就绪但未执行任务
    pub const IDLE: u8 = 2;

    /// 激活状态 - 系统已激活，可以接收任务
    pub const ACTIVE: u8 = 3;

    /// 导航中 - 正在执行导航任务
    pub const NAVIGATING: u8 = 4;

    /// 建图中 - 正在执行SLAM建图
    pub const MAPPING: u8 = 5;

    /// 定位中 - 正在执行重定位
    pub const LOCALIZING: u8 = 6;

    /// 充电中 - 机器人正在充电
    pub const CHARGING: u8 = 7;

    /// 错误状态 - 系统出现错误需要处理
    pub const ERROR: u8 = 8;

    /// 紧急停止 - 系统紧急停止
    pub const EMERGENCY_STOP: u8 = 9;

    /// 维护模式 - 系统处于维护状态
    pub const MAINTENANCE: u8 = 10;

    /// 关机中 - 系统正在关闭
    pub const SHUTDOWN: u8 = 11;

}


impl Default for SystemState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SystemState::default())
  }
}

impl rosidl_runtime_rs::Message for SystemState {
  type RmwMsg = super::msg::rmw::SystemState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        current_state: msg.current_state,
        previous_state: msg.previous_state,
        state_description: msg.state_description.as_str().into(),
        state_entered_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.state_entered_time)).into_owned(),
        state_duration: msg.state_duration,
        state_data: msg.state_data.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      current_state: msg.current_state,
      previous_state: msg.previous_state,
        state_description: msg.state_description.as_str().into(),
        state_entered_time: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.state_entered_time)).into_owned(),
      state_duration: msg.state_duration,
        state_data: msg.state_data.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      current_state: msg.current_state,
      previous_state: msg.previous_state,
      state_description: msg.state_description.to_string(),
      state_entered_time: builtin_interfaces::msg::Time::from_rmw_message(msg.state_entered_time),
      state_duration: msg.state_duration,
      state_data: msg.state_data.to_string(),
    }
  }
}


// Corresponds to master_interfaces__msg__TaskStatus
/// Author: Ming Yu Li & Alex
/// Email: 1323653732@qq.com

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct TaskStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status_code: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_uuid: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for TaskStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::TaskStatus::default())
  }
}

impl rosidl_runtime_rs::Message for TaskStatus {
  type RmwMsg = super::msg::rmw::TaskStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status_code: msg.status_code.as_str().into(),
        task_uuid: msg.task_uuid.as_str().into(),
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status_code: msg.status_code.as_str().into(),
        task_uuid: msg.task_uuid.as_str().into(),
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status_code: msg.status_code.to_string(),
      task_uuid: msg.task_uuid.to_string(),
      message: msg.message.to_string(),
    }
  }
}


