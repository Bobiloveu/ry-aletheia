#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__AddPathPoints_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__AddPathPoints_Request__init(msg: *mut AddPathPoints_Request) -> bool;
    fn master_interfaces__srv__AddPathPoints_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AddPathPoints_Request>, size: usize) -> bool;
    fn master_interfaces__srv__AddPathPoints_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AddPathPoints_Request>);
    fn master_interfaces__srv__AddPathPoints_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AddPathPoints_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<AddPathPoints_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__AddPathPoints_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddPathPoints_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub poses: rosidl_runtime_rs::Sequence<geometry_msgs::msg::rmw::PoseStamped>,

}



impl Default for AddPathPoints_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__AddPathPoints_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__AddPathPoints_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AddPathPoints_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__AddPathPoints_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__AddPathPoints_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__AddPathPoints_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AddPathPoints_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AddPathPoints_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/AddPathPoints_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__AddPathPoints_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__AddPathPoints_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__AddPathPoints_Response__init(msg: *mut AddPathPoints_Response) -> bool;
    fn master_interfaces__srv__AddPathPoints_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AddPathPoints_Response>, size: usize) -> bool;
    fn master_interfaces__srv__AddPathPoints_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AddPathPoints_Response>);
    fn master_interfaces__srv__AddPathPoints_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AddPathPoints_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<AddPathPoints_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__AddPathPoints_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddPathPoints_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for AddPathPoints_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__AddPathPoints_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__AddPathPoints_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AddPathPoints_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__AddPathPoints_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__AddPathPoints_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__AddPathPoints_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AddPathPoints_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AddPathPoints_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/AddPathPoints_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__AddPathPoints_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelNavigation_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CancelNavigation_Request__init(msg: *mut CancelNavigation_Request) -> bool;
    fn master_interfaces__srv__CancelNavigation_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CancelNavigation_Request>, size: usize) -> bool;
    fn master_interfaces__srv__CancelNavigation_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CancelNavigation_Request>);
    fn master_interfaces__srv__CancelNavigation_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CancelNavigation_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CancelNavigation_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__CancelNavigation_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelNavigation_Request {
    /// 请求部分 (Request)
    /// 要取消的导航任务ID
    /// 如果为空字符串，则取消所有正在执行的导航任务
    pub task_id: rosidl_runtime_rs::String,

    /// 取消原因 (可选)
    pub reason: rosidl_runtime_rs::String,

}



impl Default for CancelNavigation_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CancelNavigation_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CancelNavigation_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CancelNavigation_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelNavigation_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelNavigation_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelNavigation_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CancelNavigation_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CancelNavigation_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CancelNavigation_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelNavigation_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelNavigation_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CancelNavigation_Response__init(msg: *mut CancelNavigation_Response) -> bool;
    fn master_interfaces__srv__CancelNavigation_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CancelNavigation_Response>, size: usize) -> bool;
    fn master_interfaces__srv__CancelNavigation_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CancelNavigation_Response>);
    fn master_interfaces__srv__CancelNavigation_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CancelNavigation_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CancelNavigation_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__CancelNavigation_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelNavigation_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::super::msg::rmw::StandardResponse,

    /// 被取消的任务数量
    pub cancelled_tasks_count: i32,

    /// 被取消的任务ID列表
    pub cancelled_task_ids: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for CancelNavigation_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CancelNavigation_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CancelNavigation_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CancelNavigation_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelNavigation_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelNavigation_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelNavigation_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CancelNavigation_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CancelNavigation_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CancelNavigation_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelNavigation_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecord_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CancelRecord_Request__init(msg: *mut CancelRecord_Request) -> bool;
    fn master_interfaces__srv__CancelRecord_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CancelRecord_Request>, size: usize) -> bool;
    fn master_interfaces__srv__CancelRecord_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CancelRecord_Request>);
    fn master_interfaces__srv__CancelRecord_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CancelRecord_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CancelRecord_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__CancelRecord_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecord_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for CancelRecord_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CancelRecord_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CancelRecord_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CancelRecord_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecord_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecord_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecord_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CancelRecord_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CancelRecord_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CancelRecord_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecord_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecord_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CancelRecord_Response__init(msg: *mut CancelRecord_Response) -> bool;
    fn master_interfaces__srv__CancelRecord_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CancelRecord_Response>, size: usize) -> bool;
    fn master_interfaces__srv__CancelRecord_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CancelRecord_Response>);
    fn master_interfaces__srv__CancelRecord_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CancelRecord_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CancelRecord_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__CancelRecord_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecord_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for CancelRecord_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CancelRecord_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CancelRecord_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CancelRecord_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecord_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecord_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecord_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CancelRecord_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CancelRecord_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CancelRecord_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecord_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecordPath_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CancelRecordPath_Request__init(msg: *mut CancelRecordPath_Request) -> bool;
    fn master_interfaces__srv__CancelRecordPath_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CancelRecordPath_Request>, size: usize) -> bool;
    fn master_interfaces__srv__CancelRecordPath_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CancelRecordPath_Request>);
    fn master_interfaces__srv__CancelRecordPath_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CancelRecordPath_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CancelRecordPath_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__CancelRecordPath_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecordPath_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for CancelRecordPath_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CancelRecordPath_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CancelRecordPath_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CancelRecordPath_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecordPath_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecordPath_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecordPath_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CancelRecordPath_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CancelRecordPath_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CancelRecordPath_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecordPath_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecordPath_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CancelRecordPath_Response__init(msg: *mut CancelRecordPath_Response) -> bool;
    fn master_interfaces__srv__CancelRecordPath_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CancelRecordPath_Response>, size: usize) -> bool;
    fn master_interfaces__srv__CancelRecordPath_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CancelRecordPath_Response>);
    fn master_interfaces__srv__CancelRecordPath_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CancelRecordPath_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CancelRecordPath_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__CancelRecordPath_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CancelRecordPath_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for CancelRecordPath_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CancelRecordPath_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CancelRecordPath_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CancelRecordPath_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecordPath_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecordPath_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CancelRecordPath_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CancelRecordPath_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CancelRecordPath_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CancelRecordPath_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CancelRecordPath_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CaptureCurrentPoint_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CaptureCurrentPoint_Request__init(msg: *mut CaptureCurrentPoint_Request) -> bool;
    fn master_interfaces__srv__CaptureCurrentPoint_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Request>, size: usize) -> bool;
    fn master_interfaces__srv__CaptureCurrentPoint_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Request>);
    fn master_interfaces__srv__CaptureCurrentPoint_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__CaptureCurrentPoint_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CaptureCurrentPoint_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub waypoint_id: rosidl_runtime_rs::String,

    /// 要保存到的路径文件名（不包含扩展名），如果为空则只添加到当前录制缓冲区
    pub path_name: rosidl_runtime_rs::String,

    /// 路径类型（community/building-unit/floor-door），仅当path_name不为空时需要
    pub type_: rosidl_runtime_rs::String,

}



impl Default for CaptureCurrentPoint_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CaptureCurrentPoint_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CaptureCurrentPoint_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CaptureCurrentPoint_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CaptureCurrentPoint_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CaptureCurrentPoint_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CaptureCurrentPoint_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CaptureCurrentPoint_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CaptureCurrentPoint_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CaptureCurrentPoint_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CaptureCurrentPoint_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CaptureCurrentPoint_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CaptureCurrentPoint_Response__init(msg: *mut CaptureCurrentPoint_Response) -> bool;
    fn master_interfaces__srv__CaptureCurrentPoint_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Response>, size: usize) -> bool;
    fn master_interfaces__srv__CaptureCurrentPoint_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Response>);
    fn master_interfaces__srv__CaptureCurrentPoint_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CaptureCurrentPoint_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__CaptureCurrentPoint_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CaptureCurrentPoint_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pose: geometry_msgs::msg::rmw::Pose,

    /// 实际使用的waypoint_id（如果输入为空，返回自动生成的ID）
    pub actual_waypoint_id: rosidl_runtime_rs::String,

}



impl Default for CaptureCurrentPoint_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CaptureCurrentPoint_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CaptureCurrentPoint_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CaptureCurrentPoint_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CaptureCurrentPoint_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CaptureCurrentPoint_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CaptureCurrentPoint_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CaptureCurrentPoint_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CaptureCurrentPoint_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CaptureCurrentPoint_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CaptureCurrentPoint_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ChangeLocalizer_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ChangeLocalizer_Request__init(msg: *mut ChangeLocalizer_Request) -> bool;
    fn master_interfaces__srv__ChangeLocalizer_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ChangeLocalizer_Request>, size: usize) -> bool;
    fn master_interfaces__srv__ChangeLocalizer_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ChangeLocalizer_Request>);
    fn master_interfaces__srv__ChangeLocalizer_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ChangeLocalizer_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ChangeLocalizer_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__ChangeLocalizer_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ChangeLocalizer_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub pcd_path: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub z: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub yaw: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pitch: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roll: f32,

}



impl Default for ChangeLocalizer_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ChangeLocalizer_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ChangeLocalizer_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ChangeLocalizer_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ChangeLocalizer_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ChangeLocalizer_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ChangeLocalizer_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ChangeLocalizer_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ChangeLocalizer_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ChangeLocalizer_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ChangeLocalizer_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ChangeLocalizer_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ChangeLocalizer_Response__init(msg: *mut ChangeLocalizer_Response) -> bool;
    fn master_interfaces__srv__ChangeLocalizer_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ChangeLocalizer_Response>, size: usize) -> bool;
    fn master_interfaces__srv__ChangeLocalizer_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ChangeLocalizer_Response>);
    fn master_interfaces__srv__ChangeLocalizer_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ChangeLocalizer_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ChangeLocalizer_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__ChangeLocalizer_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ChangeLocalizer_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for ChangeLocalizer_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ChangeLocalizer_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ChangeLocalizer_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ChangeLocalizer_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ChangeLocalizer_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ChangeLocalizer_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ChangeLocalizer_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ChangeLocalizer_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ChangeLocalizer_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ChangeLocalizer_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ChangeLocalizer_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CheckBuildingOccupancy_Request__init(msg: *mut CheckBuildingOccupancy_Request) -> bool;
    fn master_interfaces__srv__CheckBuildingOccupancy_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Request>, size: usize) -> bool;
    fn master_interfaces__srv__CheckBuildingOccupancy_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Request>);
    fn master_interfaces__srv__CheckBuildingOccupancy_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__CheckBuildingOccupancy_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CheckBuildingOccupancy_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub building_id: rosidl_runtime_rs::String,

}



impl Default for CheckBuildingOccupancy_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CheckBuildingOccupancy_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CheckBuildingOccupancy_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CheckBuildingOccupancy_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CheckBuildingOccupancy_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CheckBuildingOccupancy_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CheckBuildingOccupancy_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CheckBuildingOccupancy_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CheckBuildingOccupancy_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CheckBuildingOccupancy_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__CheckBuildingOccupancy_Response__init(msg: *mut CheckBuildingOccupancy_Response) -> bool;
    fn master_interfaces__srv__CheckBuildingOccupancy_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Response>, size: usize) -> bool;
    fn master_interfaces__srv__CheckBuildingOccupancy_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Response>);
    fn master_interfaces__srv__CheckBuildingOccupancy_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CheckBuildingOccupancy_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__CheckBuildingOccupancy_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CheckBuildingOccupancy_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for CheckBuildingOccupancy_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__CheckBuildingOccupancy_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__CheckBuildingOccupancy_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CheckBuildingOccupancy_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CheckBuildingOccupancy_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CheckBuildingOccupancy_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__CheckBuildingOccupancy_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CheckBuildingOccupancy_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CheckBuildingOccupancy_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/CheckBuildingOccupancy_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeleteBag_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__DeleteBag_Request__init(msg: *mut DeleteBag_Request) -> bool;
    fn master_interfaces__srv__DeleteBag_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DeleteBag_Request>, size: usize) -> bool;
    fn master_interfaces__srv__DeleteBag_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DeleteBag_Request>);
    fn master_interfaces__srv__DeleteBag_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DeleteBag_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<DeleteBag_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__DeleteBag_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeleteBag_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bag_name: rosidl_runtime_rs::String,

}



impl Default for DeleteBag_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__DeleteBag_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__DeleteBag_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DeleteBag_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeleteBag_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeleteBag_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeleteBag_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DeleteBag_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DeleteBag_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/DeleteBag_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeleteBag_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeleteBag_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__DeleteBag_Response__init(msg: *mut DeleteBag_Response) -> bool;
    fn master_interfaces__srv__DeleteBag_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DeleteBag_Response>, size: usize) -> bool;
    fn master_interfaces__srv__DeleteBag_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DeleteBag_Response>);
    fn master_interfaces__srv__DeleteBag_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DeleteBag_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<DeleteBag_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__DeleteBag_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeleteBag_Response {
    /// 响应
    pub success: bool,

    /// 操作结果消息
    pub message: rosidl_runtime_rs::String,

}



impl Default for DeleteBag_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__DeleteBag_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__DeleteBag_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DeleteBag_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeleteBag_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeleteBag_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeleteBag_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DeleteBag_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DeleteBag_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/DeleteBag_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeleteBag_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeletePathPoints_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__DeletePathPoints_Request__init(msg: *mut DeletePathPoints_Request) -> bool;
    fn master_interfaces__srv__DeletePathPoints_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DeletePathPoints_Request>, size: usize) -> bool;
    fn master_interfaces__srv__DeletePathPoints_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DeletePathPoints_Request>);
    fn master_interfaces__srv__DeletePathPoints_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DeletePathPoints_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<DeletePathPoints_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__DeletePathPoints_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeletePathPoints_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub path_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub poses_to_delete: rosidl_runtime_rs::Sequence<geometry_msgs::msg::rmw::Pose>,

}



impl Default for DeletePathPoints_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__DeletePathPoints_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__DeletePathPoints_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DeletePathPoints_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeletePathPoints_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeletePathPoints_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeletePathPoints_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DeletePathPoints_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DeletePathPoints_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/DeletePathPoints_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeletePathPoints_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeletePathPoints_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__DeletePathPoints_Response__init(msg: *mut DeletePathPoints_Response) -> bool;
    fn master_interfaces__srv__DeletePathPoints_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DeletePathPoints_Response>, size: usize) -> bool;
    fn master_interfaces__srv__DeletePathPoints_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DeletePathPoints_Response>);
    fn master_interfaces__srv__DeletePathPoints_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DeletePathPoints_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<DeletePathPoints_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__DeletePathPoints_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DeletePathPoints_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub remaining_points: i32,

}



impl Default for DeletePathPoints_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__DeletePathPoints_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__DeletePathPoints_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DeletePathPoints_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeletePathPoints_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeletePathPoints_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DeletePathPoints_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DeletePathPoints_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DeletePathPoints_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/DeletePathPoints_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DeletePathPoints_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DoorControl_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__DoorControl_Request__init(msg: *mut DoorControl_Request) -> bool;
    fn master_interfaces__srv__DoorControl_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DoorControl_Request>, size: usize) -> bool;
    fn master_interfaces__srv__DoorControl_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DoorControl_Request>);
    fn master_interfaces__srv__DoorControl_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DoorControl_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<DoorControl_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__DoorControl_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DoorControl_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub executeid: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub doorid: rosidl_runtime_rs::String,

}



impl Default for DoorControl_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__DoorControl_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__DoorControl_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DoorControl_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DoorControl_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DoorControl_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DoorControl_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DoorControl_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DoorControl_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/DoorControl_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DoorControl_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DoorControl_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__DoorControl_Response__init(msg: *mut DoorControl_Response) -> bool;
    fn master_interfaces__srv__DoorControl_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DoorControl_Response>, size: usize) -> bool;
    fn master_interfaces__srv__DoorControl_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DoorControl_Response>);
    fn master_interfaces__srv__DoorControl_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DoorControl_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<DoorControl_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__DoorControl_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DoorControl_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stateid: i32,

}



impl Default for DoorControl_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__DoorControl_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__DoorControl_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DoorControl_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DoorControl_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DoorControl_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__DoorControl_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DoorControl_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DoorControl_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/DoorControl_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__DoorControl_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EditTaskWaypoint_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__EditTaskWaypoint_Request__init(msg: *mut EditTaskWaypoint_Request) -> bool;
    fn master_interfaces__srv__EditTaskWaypoint_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<EditTaskWaypoint_Request>, size: usize) -> bool;
    fn master_interfaces__srv__EditTaskWaypoint_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<EditTaskWaypoint_Request>);
    fn master_interfaces__srv__EditTaskWaypoint_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<EditTaskWaypoint_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<EditTaskWaypoint_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__EditTaskWaypoint_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EditTaskWaypoint_Request {
    /// 请求
    /// 任务文件的完整路径
    pub task_file_path: rosidl_runtime_rs::String,

    /// 路径点的 ID（用于定位）
    pub waypoint_id: i32,

    /// 路径点的位姿（用于定位验证）
    pub pose: geometry_msgs::msg::rmw::Pose,

    /// 可编辑字段（空字符串或-1表示不修改）
    /// 任务点 ID，空字符串表示不修改
    pub waypoint_task_id: rosidl_runtime_rs::String,

    /// 是否为任务点：-1=不修改, 0=false, 1=true
    pub is_task_point: i8,

    /// 速度模式：空字符串表示不修改，可选值："low_speed", "normal", "high_speed"
    pub speed_mode: rosidl_runtime_rs::String,

    /// 是否倒退：-1=不修改, 0=false, 1=true
    pub is_backward: i8,

    /// 是否为单点：-1=不修改, 0=false, 1=true
    pub is_single_point: i8,

}



impl Default for EditTaskWaypoint_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__EditTaskWaypoint_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__EditTaskWaypoint_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for EditTaskWaypoint_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EditTaskWaypoint_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EditTaskWaypoint_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EditTaskWaypoint_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for EditTaskWaypoint_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for EditTaskWaypoint_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/EditTaskWaypoint_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EditTaskWaypoint_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EditTaskWaypoint_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__EditTaskWaypoint_Response__init(msg: *mut EditTaskWaypoint_Response) -> bool;
    fn master_interfaces__srv__EditTaskWaypoint_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<EditTaskWaypoint_Response>, size: usize) -> bool;
    fn master_interfaces__srv__EditTaskWaypoint_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<EditTaskWaypoint_Response>);
    fn master_interfaces__srv__EditTaskWaypoint_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<EditTaskWaypoint_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<EditTaskWaypoint_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__EditTaskWaypoint_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EditTaskWaypoint_Response {
    /// 响应
    /// 是否成功编辑
    pub success: bool,

    /// 响应消息
    pub message: rosidl_runtime_rs::String,

}



impl Default for EditTaskWaypoint_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__EditTaskWaypoint_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__EditTaskWaypoint_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for EditTaskWaypoint_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EditTaskWaypoint_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EditTaskWaypoint_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EditTaskWaypoint_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for EditTaskWaypoint_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for EditTaskWaypoint_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/EditTaskWaypoint_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EditTaskWaypoint_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EndRecord_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__EndRecord_Request__init(msg: *mut EndRecord_Request) -> bool;
    fn master_interfaces__srv__EndRecord_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<EndRecord_Request>, size: usize) -> bool;
    fn master_interfaces__srv__EndRecord_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<EndRecord_Request>);
    fn master_interfaces__srv__EndRecord_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<EndRecord_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<EndRecord_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__EndRecord_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EndRecord_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for EndRecord_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__EndRecord_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__EndRecord_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for EndRecord_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EndRecord_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EndRecord_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EndRecord_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for EndRecord_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for EndRecord_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/EndRecord_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EndRecord_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EndRecord_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__EndRecord_Response__init(msg: *mut EndRecord_Response) -> bool;
    fn master_interfaces__srv__EndRecord_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<EndRecord_Response>, size: usize) -> bool;
    fn master_interfaces__srv__EndRecord_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<EndRecord_Response>);
    fn master_interfaces__srv__EndRecord_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<EndRecord_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<EndRecord_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__EndRecord_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct EndRecord_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub path: rosidl_runtime_rs::String,

}



impl Default for EndRecord_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__EndRecord_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__EndRecord_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for EndRecord_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EndRecord_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EndRecord_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__EndRecord_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for EndRecord_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for EndRecord_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/EndRecord_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__EndRecord_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__FollowPath_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__FollowPath_Request__init(msg: *mut FollowPath_Request) -> bool;
    fn master_interfaces__srv__FollowPath_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<FollowPath_Request>, size: usize) -> bool;
    fn master_interfaces__srv__FollowPath_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<FollowPath_Request>);
    fn master_interfaces__srv__FollowPath_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<FollowPath_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<FollowPath_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__FollowPath_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FollowPath_Request {
    /// 请求部分 (Request)
    /// 路径信息（含 frame_id 与时间戳）
    pub path: nav_msgs::msg::rmw::Path,

    /// 控制器ID，如果为空则使用默认控制器（如 "FollowPath"）
    pub controller_id: rosidl_runtime_rs::String,

    /// 目标检查器ID
    pub goal_checker_id: rosidl_runtime_rs::String,

    /// 行为树文件路径，如果为空则使用默认行为树
    pub behavior_tree: rosidl_runtime_rs::String,

    /// 超时时间 (秒)，0 表示无超时限制
    pub timeout: f64,

    /// 航点类型 (可选)，用于业务逻辑识别
    /// path_point / gate_point / elevator_point / user_door ...
    pub waypoint_type: rosidl_runtime_rs::String,

}



impl Default for FollowPath_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__FollowPath_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__FollowPath_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for FollowPath_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__FollowPath_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__FollowPath_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__FollowPath_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for FollowPath_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for FollowPath_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/FollowPath_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__FollowPath_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__FollowPath_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__FollowPath_Response__init(msg: *mut FollowPath_Response) -> bool;
    fn master_interfaces__srv__FollowPath_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<FollowPath_Response>, size: usize) -> bool;
    fn master_interfaces__srv__FollowPath_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<FollowPath_Response>);
    fn master_interfaces__srv__FollowPath_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<FollowPath_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<FollowPath_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__FollowPath_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FollowPath_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::super::msg::rmw::StandardResponse,

    /// 路径跟随任务ID，用于后续查询和取消操作
    pub task_id: rosidl_runtime_rs::String,

}



impl Default for FollowPath_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__FollowPath_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__FollowPath_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for FollowPath_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__FollowPath_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__FollowPath_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__FollowPath_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for FollowPath_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for FollowPath_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/FollowPath_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__FollowPath_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GenerateTask_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GenerateTask_Request__init(msg: *mut GenerateTask_Request) -> bool;
    fn master_interfaces__srv__GenerateTask_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GenerateTask_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GenerateTask_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GenerateTask_Request>);
    fn master_interfaces__srv__GenerateTask_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GenerateTask_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GenerateTask_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GenerateTask_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GenerateTask_Request {
    /// 请求
    pub community: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,

}



impl Default for GenerateTask_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GenerateTask_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GenerateTask_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GenerateTask_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GenerateTask_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GenerateTask_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GenerateTask_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GenerateTask_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GenerateTask_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GenerateTask_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GenerateTask_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GenerateTask_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GenerateTask_Response__init(msg: *mut GenerateTask_Response) -> bool;
    fn master_interfaces__srv__GenerateTask_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GenerateTask_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GenerateTask_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GenerateTask_Response>);
    fn master_interfaces__srv__GenerateTask_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GenerateTask_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GenerateTask_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GenerateTask_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GenerateTask_Response {
    /// 响应
    /// 是否成功生成任务文件
    pub success: bool,

    /// 响应消息
    pub message: rosidl_runtime_rs::String,

    /// 生成的任务文件路径
    pub output_file_path: rosidl_runtime_rs::String,

}



impl Default for GenerateTask_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GenerateTask_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GenerateTask_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GenerateTask_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GenerateTask_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GenerateTask_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GenerateTask_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GenerateTask_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GenerateTask_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GenerateTask_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GenerateTask_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetBagList_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetBagList_Request__init(msg: *mut GetBagList_Request) -> bool;
    fn master_interfaces__srv__GetBagList_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetBagList_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetBagList_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetBagList_Request>);
    fn master_interfaces__srv__GetBagList_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetBagList_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetBagList_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetBagList_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetBagList_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for GetBagList_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetBagList_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetBagList_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetBagList_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetBagList_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetBagList_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetBagList_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetBagList_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetBagList_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetBagList_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetBagList_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetBagList_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetBagList_Response__init(msg: *mut GetBagList_Response) -> bool;
    fn master_interfaces__srv__GetBagList_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetBagList_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetBagList_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetBagList_Response>);
    fn master_interfaces__srv__GetBagList_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetBagList_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetBagList_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetBagList_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetBagList_Response {
    /// 响应
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bags: rosidl_runtime_rs::Sequence<super::super::msg::rmw::BagInfo>,

}



impl Default for GetBagList_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetBagList_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetBagList_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetBagList_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetBagList_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetBagList_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetBagList_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetBagList_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetBagList_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetBagList_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetBagList_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetCargoStatus_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetCargoStatus_Request__init(msg: *mut GetCargoStatus_Request) -> bool;
    fn master_interfaces__srv__GetCargoStatus_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetCargoStatus_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetCargoStatus_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetCargoStatus_Request>);
    fn master_interfaces__srv__GetCargoStatus_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetCargoStatus_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetCargoStatus_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetCargoStatus_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetCargoStatus_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_id: u8,

}

impl GetCargoStatus_Request {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_UPPER: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const CARGO_LOWER: u8 = 2;

}


impl Default for GetCargoStatus_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetCargoStatus_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetCargoStatus_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetCargoStatus_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetCargoStatus_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetCargoStatus_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetCargoStatus_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetCargoStatus_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetCargoStatus_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetCargoStatus_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetCargoStatus_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetCargoStatus_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetCargoStatus_Response__init(msg: *mut GetCargoStatus_Response) -> bool;
    fn master_interfaces__srv__GetCargoStatus_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetCargoStatus_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetCargoStatus_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetCargoStatus_Response>);
    fn master_interfaces__srv__GetCargoStatus_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetCargoStatus_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetCargoStatus_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetCargoStatus_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetCargoStatus_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cargo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub last_operation_code: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_busy: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state_text: rosidl_runtime_rs::String,

}

impl GetCargoStatus_Response {

    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UNKNOWN: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_RESET: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UPPER_MANUAL_OPEN: u8 = 2;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UPPER_MANUAL_CLOSE: u8 = 3;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_UPPER_AUTO_UNLOAD: u8 = 4;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_LOWER_UNLOCK: u8 = 5;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_LOWER_LOCK: u8 = 6;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const STATE_LOWER_OPEN: u8 = 7;

}


impl Default for GetCargoStatus_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetCargoStatus_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetCargoStatus_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetCargoStatus_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetCargoStatus_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetCargoStatus_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetCargoStatus_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetCargoStatus_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetCargoStatus_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetCargoStatus_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetCargoStatus_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetElevatorId_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetElevatorId_Request__init(msg: *mut GetElevatorId_Request) -> bool;
    fn master_interfaces__srv__GetElevatorId_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetElevatorId_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetElevatorId_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetElevatorId_Request>);
    fn master_interfaces__srv__GetElevatorId_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetElevatorId_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetElevatorId_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetElevatorId_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetElevatorId_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub community: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,

}



impl Default for GetElevatorId_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetElevatorId_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetElevatorId_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetElevatorId_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetElevatorId_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetElevatorId_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetElevatorId_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetElevatorId_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetElevatorId_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetElevatorId_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetElevatorId_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetElevatorId_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetElevatorId_Response__init(msg: *mut GetElevatorId_Response) -> bool;
    fn master_interfaces__srv__GetElevatorId_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetElevatorId_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetElevatorId_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetElevatorId_Response>);
    fn master_interfaces__srv__GetElevatorId_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetElevatorId_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetElevatorId_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetElevatorId_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetElevatorId_Response {
    /// 响应
    pub success: bool,

    /// 电梯id改string
    pub elevatorid: rosidl_runtime_rs::String,

}



impl Default for GetElevatorId_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetElevatorId_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetElevatorId_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetElevatorId_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetElevatorId_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetElevatorId_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetElevatorId_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetElevatorId_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetElevatorId_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetElevatorId_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetElevatorId_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetEmergencyStop_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetEmergencyStop_Request__init(msg: *mut GetEmergencyStop_Request) -> bool;
    fn master_interfaces__srv__GetEmergencyStop_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetEmergencyStop_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetEmergencyStop_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetEmergencyStop_Request>);
    fn master_interfaces__srv__GetEmergencyStop_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetEmergencyStop_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetEmergencyStop_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetEmergencyStop_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetEmergencyStop_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for GetEmergencyStop_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetEmergencyStop_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetEmergencyStop_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetEmergencyStop_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetEmergencyStop_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetEmergencyStop_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetEmergencyStop_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetEmergencyStop_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetEmergencyStop_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetEmergencyStop_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetEmergencyStop_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetEmergencyStop_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetEmergencyStop_Response__init(msg: *mut GetEmergencyStop_Response) -> bool;
    fn master_interfaces__srv__GetEmergencyStop_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetEmergencyStop_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetEmergencyStop_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetEmergencyStop_Response>);
    fn master_interfaces__srv__GetEmergencyStop_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetEmergencyStop_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetEmergencyStop_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetEmergencyStop_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetEmergencyStop_Response {
    /// 响应
    /// 当前急停状态：true=已按下，false=已释放
    pub is_emergency_stop: bool,

    /// 状态描述信息
    pub message: rosidl_runtime_rs::String,

}



impl Default for GetEmergencyStop_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetEmergencyStop_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetEmergencyStop_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetEmergencyStop_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetEmergencyStop_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetEmergencyStop_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetEmergencyStop_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetEmergencyStop_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetEmergencyStop_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetEmergencyStop_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetEmergencyStop_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetNavigationStatus_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetNavigationStatus_Request__init(msg: *mut GetNavigationStatus_Request) -> bool;
    fn master_interfaces__srv__GetNavigationStatus_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetNavigationStatus_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetNavigationStatus_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetNavigationStatus_Request>);
    fn master_interfaces__srv__GetNavigationStatus_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetNavigationStatus_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetNavigationStatus_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetNavigationStatus_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetNavigationStatus_Request {
    /// 请求部分 (Request)
    /// 要查询的导航任务ID
    /// 如果为空字符串，则返回所有任务的状态
    pub task_id: rosidl_runtime_rs::String,

}



impl Default for GetNavigationStatus_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetNavigationStatus_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetNavigationStatus_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetNavigationStatus_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetNavigationStatus_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetNavigationStatus_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetNavigationStatus_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetNavigationStatus_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetNavigationStatus_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetNavigationStatus_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetNavigationStatus_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetNavigationStatus_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetNavigationStatus_Response__init(msg: *mut GetNavigationStatus_Response) -> bool;
    fn master_interfaces__srv__GetNavigationStatus_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetNavigationStatus_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetNavigationStatus_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetNavigationStatus_Response>);
    fn master_interfaces__srv__GetNavigationStatus_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetNavigationStatus_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetNavigationStatus_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetNavigationStatus_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetNavigationStatus_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::super::msg::rmw::StandardResponse,

    /// 导航状态信息列表
    pub navigation_status: rosidl_runtime_rs::Sequence<super::super::msg::rmw::NavigationStatus>,

}



impl Default for GetNavigationStatus_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetNavigationStatus_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetNavigationStatus_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetNavigationStatus_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetNavigationStatus_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetNavigationStatus_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetNavigationStatus_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetNavigationStatus_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetNavigationStatus_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetNavigationStatus_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetNavigationStatus_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathList_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetPathList_Request__init(msg: *mut GetPathList_Request) -> bool;
    fn master_interfaces__srv__GetPathList_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetPathList_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetPathList_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetPathList_Request>);
    fn master_interfaces__srv__GetPathList_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetPathList_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetPathList_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetPathList_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathList_Request {
    /// indoor/outdoor or "all" for all types
    pub type_: rosidl_runtime_rs::String,

}



impl Default for GetPathList_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetPathList_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetPathList_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetPathList_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathList_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathList_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathList_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetPathList_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetPathList_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetPathList_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathList_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathList_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetPathList_Response__init(msg: *mut GetPathList_Response) -> bool;
    fn master_interfaces__srv__GetPathList_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetPathList_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetPathList_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetPathList_Response>);
    fn master_interfaces__srv__GetPathList_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetPathList_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetPathList_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetPathList_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathList_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

    /// 路径名称列表
    pub path_names: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

    /// 每个路径的点数量
    pub point_counts: rosidl_runtime_rs::Sequence<i32>,

    /// 完整文件路径
    pub file_paths: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,

}



impl Default for GetPathList_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetPathList_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetPathList_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetPathList_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathList_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathList_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathList_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetPathList_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetPathList_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetPathList_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathList_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathPoints_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetPathPoints_Request__init(msg: *mut GetPathPoints_Request) -> bool;
    fn master_interfaces__srv__GetPathPoints_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetPathPoints_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetPathPoints_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetPathPoints_Request>);
    fn master_interfaces__srv__GetPathPoints_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetPathPoints_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetPathPoints_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetPathPoints_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathPoints_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub path_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: rosidl_runtime_rs::String,

}



impl Default for GetPathPoints_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetPathPoints_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetPathPoints_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetPathPoints_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathPoints_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathPoints_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathPoints_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetPathPoints_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetPathPoints_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetPathPoints_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathPoints_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathPoints_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetPathPoints_Response__init(msg: *mut GetPathPoints_Response) -> bool;
    fn master_interfaces__srv__GetPathPoints_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetPathPoints_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetPathPoints_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetPathPoints_Response>);
    fn master_interfaces__srv__GetPathPoints_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetPathPoints_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetPathPoints_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetPathPoints_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPathPoints_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub poses: rosidl_runtime_rs::Sequence<geometry_msgs::msg::rmw::PoseStamped>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i32,

}



impl Default for GetPathPoints_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetPathPoints_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetPathPoints_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetPathPoints_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathPoints_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathPoints_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPathPoints_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetPathPoints_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetPathPoints_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetPathPoints_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPathPoints_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPlanStatus_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetPlanStatus_Request__init(msg: *mut GetPlanStatus_Request) -> bool;
    fn master_interfaces__srv__GetPlanStatus_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetPlanStatus_Request>, size: usize) -> bool;
    fn master_interfaces__srv__GetPlanStatus_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetPlanStatus_Request>);
    fn master_interfaces__srv__GetPlanStatus_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetPlanStatus_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetPlanStatus_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__GetPlanStatus_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPlanStatus_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub task_id: rosidl_runtime_rs::String,

}



impl Default for GetPlanStatus_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetPlanStatus_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetPlanStatus_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetPlanStatus_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPlanStatus_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPlanStatus_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPlanStatus_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetPlanStatus_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetPlanStatus_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetPlanStatus_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPlanStatus_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPlanStatus_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__GetPlanStatus_Response__init(msg: *mut GetPlanStatus_Response) -> bool;
    fn master_interfaces__srv__GetPlanStatus_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetPlanStatus_Response>, size: usize) -> bool;
    fn master_interfaces__srv__GetPlanStatus_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetPlanStatus_Response>);
    fn master_interfaces__srv__GetPlanStatus_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetPlanStatus_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetPlanStatus_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__GetPlanStatus_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetPlanStatus_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub code: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub msg: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status: super::super::msg::rmw::PlanStatus,

}



impl Default for GetPlanStatus_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__GetPlanStatus_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__GetPlanStatus_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetPlanStatus_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPlanStatus_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPlanStatus_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__GetPlanStatus_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetPlanStatus_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetPlanStatus_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/GetPlanStatus_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__GetPlanStatus_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateThroughPoses_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__NavigateThroughPoses_Request__init(msg: *mut NavigateThroughPoses_Request) -> bool;
    fn master_interfaces__srv__NavigateThroughPoses_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateThroughPoses_Request>, size: usize) -> bool;
    fn master_interfaces__srv__NavigateThroughPoses_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateThroughPoses_Request>);
    fn master_interfaces__srv__NavigateThroughPoses_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateThroughPoses_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateThroughPoses_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__NavigateThroughPoses_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateThroughPoses_Request {
    /// 请求部分 (Request)
    /// 目标位姿序列，顺序执行
    pub poses: rosidl_runtime_rs::Sequence<geometry_msgs::msg::rmw::PoseStamped>,

    /// 行为树文件路径，如果为空则使用默认行为树
    pub behavior_tree: rosidl_runtime_rs::String,

    /// 超时时间 (秒)，0 表示无超时限制
    pub timeout: f64,

    /// 航点类型 (可选)，用于业务逻辑识别
    /// path_point / gate_point / elevator_point / user_door ...
    pub waypoint_type: rosidl_runtime_rs::String,

}



impl Default for NavigateThroughPoses_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__NavigateThroughPoses_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__NavigateThroughPoses_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateThroughPoses_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateThroughPoses_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateThroughPoses_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateThroughPoses_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateThroughPoses_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateThroughPoses_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/NavigateThroughPoses_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateThroughPoses_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateThroughPoses_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__NavigateThroughPoses_Response__init(msg: *mut NavigateThroughPoses_Response) -> bool;
    fn master_interfaces__srv__NavigateThroughPoses_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateThroughPoses_Response>, size: usize) -> bool;
    fn master_interfaces__srv__NavigateThroughPoses_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateThroughPoses_Response>);
    fn master_interfaces__srv__NavigateThroughPoses_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateThroughPoses_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateThroughPoses_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__NavigateThroughPoses_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateThroughPoses_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::super::msg::rmw::StandardResponse,

    /// 任务ID，用于后续查询和取消操作
    pub task_id: rosidl_runtime_rs::String,

}



impl Default for NavigateThroughPoses_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__NavigateThroughPoses_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__NavigateThroughPoses_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateThroughPoses_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateThroughPoses_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateThroughPoses_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateThroughPoses_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateThroughPoses_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateThroughPoses_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/NavigateThroughPoses_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateThroughPoses_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateToPose_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__NavigateToPose_Request__init(msg: *mut NavigateToPose_Request) -> bool;
    fn master_interfaces__srv__NavigateToPose_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateToPose_Request>, size: usize) -> bool;
    fn master_interfaces__srv__NavigateToPose_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateToPose_Request>);
    fn master_interfaces__srv__NavigateToPose_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateToPose_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateToPose_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__NavigateToPose_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateToPose_Request {
    /// 请求部分 (Request)
    /// 目标位姿信息
    pub target_pose: geometry_msgs::msg::rmw::PoseStamped,

    /// 导航行为参数 (可选)
    /// 规划器ID，如果为空则使用默认规划器
    pub planner_id: rosidl_runtime_rs::String,

    /// 控制器ID，如果为空则使用默认控制器
    pub controller_id: rosidl_runtime_rs::String,

    /// 行为树文件路径，如果为空则使用默认行为树
    pub behavior_tree: rosidl_runtime_rs::String,

    /// 导航超时时间 (秒)，0表示无超时限制
    pub timeout: f64,

    /// 航点类型 (可选)，用于业务逻辑识别
    /// path_point / gate_point / elevator_point / user_door ...
    pub waypoint_type: rosidl_runtime_rs::String,

}



impl Default for NavigateToPose_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__NavigateToPose_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__NavigateToPose_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateToPose_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateToPose_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateToPose_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateToPose_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateToPose_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateToPose_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/NavigateToPose_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateToPose_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateToPose_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__NavigateToPose_Response__init(msg: *mut NavigateToPose_Response) -> bool;
    fn master_interfaces__srv__NavigateToPose_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NavigateToPose_Response>, size: usize) -> bool;
    fn master_interfaces__srv__NavigateToPose_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NavigateToPose_Response>);
    fn master_interfaces__srv__NavigateToPose_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NavigateToPose_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<NavigateToPose_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__NavigateToPose_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NavigateToPose_Response {
    /// 响应部分 (Response)
    /// 标准响应格式
    pub response: super::super::msg::rmw::StandardResponse,

    /// 导航任务ID，用于后续查询和取消操作
    pub task_id: rosidl_runtime_rs::String,

}



impl Default for NavigateToPose_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__NavigateToPose_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__NavigateToPose_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NavigateToPose_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateToPose_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateToPose_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NavigateToPose_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NavigateToPose_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NavigateToPose_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/NavigateToPose_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NavigateToPose_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NodeString_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__NodeString_Request__init(msg: *mut NodeString_Request) -> bool;
    fn master_interfaces__srv__NodeString_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NodeString_Request>, size: usize) -> bool;
    fn master_interfaces__srv__NodeString_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NodeString_Request>);
    fn master_interfaces__srv__NodeString_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NodeString_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<NodeString_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__NodeString_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NodeString_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub node_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub node_config: rosidl_runtime_rs::String,

}



impl Default for NodeString_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__NodeString_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__NodeString_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NodeString_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NodeString_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NodeString_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NodeString_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NodeString_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NodeString_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/NodeString_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NodeString_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NodeString_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__NodeString_Response__init(msg: *mut NodeString_Response) -> bool;
    fn master_interfaces__srv__NodeString_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<NodeString_Response>, size: usize) -> bool;
    fn master_interfaces__srv__NodeString_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<NodeString_Response>);
    fn master_interfaces__srv__NodeString_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<NodeString_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<NodeString_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__NodeString_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct NodeString_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for NodeString_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__NodeString_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__NodeString_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for NodeString_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NodeString_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NodeString_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__NodeString_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for NodeString_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for NodeString_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/NodeString_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__NodeString_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__PGOMapping_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__PGOMapping_Request__init(msg: *mut PGOMapping_Request) -> bool;
    fn master_interfaces__srv__PGOMapping_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PGOMapping_Request>, size: usize) -> bool;
    fn master_interfaces__srv__PGOMapping_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PGOMapping_Request>);
    fn master_interfaces__srv__PGOMapping_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PGOMapping_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<PGOMapping_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__PGOMapping_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PGOMapping_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub command: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub file_path: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub save_patches: bool,

}



impl Default for PGOMapping_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__PGOMapping_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__PGOMapping_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PGOMapping_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__PGOMapping_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__PGOMapping_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__PGOMapping_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PGOMapping_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PGOMapping_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/PGOMapping_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__PGOMapping_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__PGOMapping_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__PGOMapping_Response__init(msg: *mut PGOMapping_Response) -> bool;
    fn master_interfaces__srv__PGOMapping_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PGOMapping_Response>, size: usize) -> bool;
    fn master_interfaces__srv__PGOMapping_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PGOMapping_Response>);
    fn master_interfaces__srv__PGOMapping_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PGOMapping_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<PGOMapping_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__PGOMapping_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PGOMapping_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num_key_poses: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num_loops: i32,

}



impl Default for PGOMapping_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__PGOMapping_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__PGOMapping_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PGOMapping_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__PGOMapping_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__PGOMapping_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__PGOMapping_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PGOMapping_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PGOMapping_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/PGOMapping_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__PGOMapping_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__Ping_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__Ping_Request__init(msg: *mut Ping_Request) -> bool;
    fn master_interfaces__srv__Ping_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Ping_Request>, size: usize) -> bool;
    fn master_interfaces__srv__Ping_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Ping_Request>);
    fn master_interfaces__srv__Ping_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Ping_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<Ping_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__Ping_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Ping_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub request_time: builtin_interfaces::msg::rmw::Time,

}



impl Default for Ping_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__Ping_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__Ping_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Ping_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__Ping_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__Ping_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__Ping_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Ping_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Ping_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/Ping_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__Ping_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__Ping_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__Ping_Response__init(msg: *mut Ping_Response) -> bool;
    fn master_interfaces__srv__Ping_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Ping_Response>, size: usize) -> bool;
    fn master_interfaces__srv__Ping_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Ping_Response>);
    fn master_interfaces__srv__Ping_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Ping_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<Ping_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__Ping_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Ping_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub response: super::super::msg::rmw::StandardResponse,


    // This member is not documented.
    #[allow(missing_docs)]
    pub response_time: builtin_interfaces::msg::rmw::Time,

}



impl Default for Ping_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__Ping_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__Ping_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Ping_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__Ping_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__Ping_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__Ping_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Ping_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Ping_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/Ping_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__Ping_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReportException_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ReportException_Request__init(msg: *mut ReportException_Request) -> bool;
    fn master_interfaces__srv__ReportException_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ReportException_Request>, size: usize) -> bool;
    fn master_interfaces__srv__ReportException_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ReportException_Request>);
    fn master_interfaces__srv__ReportException_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ReportException_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ReportException_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__ReportException_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReportException_Request {
    /// 请求（字段与 JSON payload 保持一致）
    /// 可选，请求唯一标识
    pub request_id: rosidl_runtime_rs::String,

    /// 异常等级，如 Error / Warn
    pub safe_level: rosidl_runtime_rs::String,

    /// 8位16进制错误码字符串，例如 "0x0000A001"
    pub safe_code: rosidl_runtime_rs::String,

    /// 异常描述
    pub safe_msg: rosidl_runtime_rs::String,

    /// 处理措施，可为空
    pub safe_action: rosidl_runtime_rs::String,

}



impl Default for ReportException_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ReportException_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ReportException_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ReportException_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReportException_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReportException_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReportException_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ReportException_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ReportException_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ReportException_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReportException_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReportException_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ReportException_Response__init(msg: *mut ReportException_Response) -> bool;
    fn master_interfaces__srv__ReportException_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ReportException_Response>, size: usize) -> bool;
    fn master_interfaces__srv__ReportException_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ReportException_Response>);
    fn master_interfaces__srv__ReportException_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ReportException_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ReportException_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__ReportException_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReportException_Response {
    /// 是否成功上报
    pub success: bool,

    /// 错误信息(如果 success=false)
    pub error_message: rosidl_runtime_rs::String,

}



impl Default for ReportException_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ReportException_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ReportException_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ReportException_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReportException_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReportException_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReportException_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ReportException_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ReportException_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ReportException_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReportException_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ResetTaskWaypoint_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ResetTaskWaypoint_Request__init(msg: *mut ResetTaskWaypoint_Request) -> bool;
    fn master_interfaces__srv__ResetTaskWaypoint_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Request>, size: usize) -> bool;
    fn master_interfaces__srv__ResetTaskWaypoint_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Request>);
    fn master_interfaces__srv__ResetTaskWaypoint_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__ResetTaskWaypoint_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ResetTaskWaypoint_Request {
    /// 请求
    /// 任务文件的完整路径
    pub task_file_path: rosidl_runtime_rs::String,

    /// 路径点的 ID（用于定位）
    pub waypoint_id: i32,

    /// 路径点的位姿（用于定位验证）
    pub pose: geometry_msgs::msg::rmw::Pose,

}



impl Default for ResetTaskWaypoint_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ResetTaskWaypoint_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ResetTaskWaypoint_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ResetTaskWaypoint_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ResetTaskWaypoint_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ResetTaskWaypoint_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ResetTaskWaypoint_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ResetTaskWaypoint_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ResetTaskWaypoint_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ResetTaskWaypoint_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ResetTaskWaypoint_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ResetTaskWaypoint_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ResetTaskWaypoint_Response__init(msg: *mut ResetTaskWaypoint_Response) -> bool;
    fn master_interfaces__srv__ResetTaskWaypoint_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Response>, size: usize) -> bool;
    fn master_interfaces__srv__ResetTaskWaypoint_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Response>);
    fn master_interfaces__srv__ResetTaskWaypoint_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ResetTaskWaypoint_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__ResetTaskWaypoint_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ResetTaskWaypoint_Response {
    /// 响应
    /// 是否成功还原
    pub success: bool,

    /// 响应消息
    pub message: rosidl_runtime_rs::String,

}



impl Default for ResetTaskWaypoint_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ResetTaskWaypoint_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ResetTaskWaypoint_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ResetTaskWaypoint_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ResetTaskWaypoint_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ResetTaskWaypoint_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ResetTaskWaypoint_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ResetTaskWaypoint_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ResetTaskWaypoint_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ResetTaskWaypoint_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ResetTaskWaypoint_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReturnHome_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ReturnHome_Request__init(msg: *mut ReturnHome_Request) -> bool;
    fn master_interfaces__srv__ReturnHome_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ReturnHome_Request>, size: usize) -> bool;
    fn master_interfaces__srv__ReturnHome_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ReturnHome_Request>);
    fn master_interfaces__srv__ReturnHome_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ReturnHome_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ReturnHome_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__ReturnHome_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReturnHome_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for ReturnHome_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ReturnHome_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ReturnHome_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ReturnHome_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReturnHome_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReturnHome_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReturnHome_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ReturnHome_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ReturnHome_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ReturnHome_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReturnHome_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReturnHome_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__ReturnHome_Response__init(msg: *mut ReturnHome_Response) -> bool;
    fn master_interfaces__srv__ReturnHome_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ReturnHome_Response>, size: usize) -> bool;
    fn master_interfaces__srv__ReturnHome_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ReturnHome_Response>);
    fn master_interfaces__srv__ReturnHome_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ReturnHome_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ReturnHome_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__ReturnHome_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReturnHome_Response {
    /// 响应
    /// 返程是否成功
    pub success: bool,

    /// 返程结果消息
    pub message: rosidl_runtime_rs::String,

}



impl Default for ReturnHome_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__ReturnHome_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__ReturnHome_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ReturnHome_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReturnHome_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReturnHome_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__ReturnHome_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ReturnHome_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ReturnHome_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/ReturnHome_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__ReturnHome_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartExecuteTasks_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartExecuteTasks_Request__init(msg: *mut StartExecuteTasks_Request) -> bool;
    fn master_interfaces__srv__StartExecuteTasks_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartExecuteTasks_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartExecuteTasks_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartExecuteTasks_Request>);
    fn master_interfaces__srv__StartExecuteTasks_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartExecuteTasks_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartExecuteTasks_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartExecuteTasks_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartExecuteTasks_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub community: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_uuid: rosidl_runtime_rs::String,

}



impl Default for StartExecuteTasks_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartExecuteTasks_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartExecuteTasks_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartExecuteTasks_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartExecuteTasks_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartExecuteTasks_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartExecuteTasks_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartExecuteTasks_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartExecuteTasks_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartExecuteTasks_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartExecuteTasks_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartExecuteTasks_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartExecuteTasks_Response__init(msg: *mut StartExecuteTasks_Response) -> bool;
    fn master_interfaces__srv__StartExecuteTasks_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartExecuteTasks_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartExecuteTasks_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartExecuteTasks_Response>);
    fn master_interfaces__srv__StartExecuteTasks_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartExecuteTasks_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartExecuteTasks_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartExecuteTasks_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartExecuteTasks_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for StartExecuteTasks_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartExecuteTasks_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartExecuteTasks_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartExecuteTasks_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartExecuteTasks_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartExecuteTasks_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartExecuteTasks_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartExecuteTasks_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartExecuteTasks_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartExecuteTasks_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartExecuteTasks_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMapping_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartMapping_Request__init(msg: *mut StartMapping_Request) -> bool;
    fn master_interfaces__srv__StartMapping_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartMapping_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartMapping_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartMapping_Request>);
    fn master_interfaces__srv__StartMapping_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartMapping_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartMapping_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartMapping_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMapping_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub rosbag: rosidl_runtime_rs::String,

    /// indoor/outdoor
    pub map_type: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub community: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: rosidl_runtime_rs::String,

}



impl Default for StartMapping_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartMapping_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartMapping_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartMapping_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMapping_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMapping_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMapping_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartMapping_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartMapping_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartMapping_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMapping_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMapping_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartMapping_Response__init(msg: *mut StartMapping_Response) -> bool;
    fn master_interfaces__srv__StartMapping_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartMapping_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartMapping_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartMapping_Response>);
    fn master_interfaces__srv__StartMapping_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartMapping_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartMapping_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartMapping_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMapping_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for StartMapping_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartMapping_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartMapping_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartMapping_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMapping_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMapping_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMapping_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartMapping_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartMapping_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartMapping_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMapping_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMultiTasksExecute_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartMultiTasksExecute_Request__init(msg: *mut StartMultiTasksExecute_Request) -> bool;
    fn master_interfaces__srv__StartMultiTasksExecute_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartMultiTasksExecute_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Request>);
    fn master_interfaces__srv__StartMultiTasksExecute_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartMultiTasksExecute_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMultiTasksExecute_Request {
    /// Community directory name under /opt/ry/data/tasks/multi_tasks
    pub community: rosidl_runtime_rs::String,

    /// Whether to start by executing sub_outdoor_eguard.json
    pub out_eguard: bool,

    /// true: finish with sub_outdoor_eguard_r.json
    /// false: finish by returning to the task-start pose recorded from odom -> base_footprint
    pub return_origin: bool,

    /// Ordered delivery sequence.
    /// Example:
    /// [{building: "3", unit: "2", floor: "5", door: "102", cargo_type: 0, delivery_code: "1sdajlf"}]
    pub tasks_seqs: rosidl_runtime_rs::Sequence<super::super::msg::rmw::MultiTaskDestination>,

    /// Task tracking UUID
    pub task_uuid: rosidl_runtime_rs::String,

}



impl Default for StartMultiTasksExecute_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartMultiTasksExecute_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartMultiTasksExecute_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartMultiTasksExecute_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMultiTasksExecute_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMultiTasksExecute_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMultiTasksExecute_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartMultiTasksExecute_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartMultiTasksExecute_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartMultiTasksExecute_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMultiTasksExecute_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMultiTasksExecute_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartMultiTasksExecute_Response__init(msg: *mut StartMultiTasksExecute_Response) -> bool;
    fn master_interfaces__srv__StartMultiTasksExecute_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartMultiTasksExecute_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Response>);
    fn master_interfaces__srv__StartMultiTasksExecute_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartMultiTasksExecute_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartMultiTasksExecute_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartMultiTasksExecute_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for StartMultiTasksExecute_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartMultiTasksExecute_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartMultiTasksExecute_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartMultiTasksExecute_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMultiTasksExecute_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMultiTasksExecute_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartMultiTasksExecute_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartMultiTasksExecute_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartMultiTasksExecute_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartMultiTasksExecute_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartMultiTasksExecute_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartNavigateTodoor_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartNavigateTodoor_Request__init(msg: *mut StartNavigateTodoor_Request) -> bool;
    fn master_interfaces__srv__StartNavigateTodoor_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartNavigateTodoor_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartNavigateTodoor_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartNavigateTodoor_Request>);
    fn master_interfaces__srv__StartNavigateTodoor_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartNavigateTodoor_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartNavigateTodoor_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartNavigateTodoor_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartNavigateTodoor_Request {
    /// Request
    /// 路径点数组
    pub waypoints: rosidl_runtime_rs::Sequence<super::super::msg::rmw::NavigateWaypoint>,

}



impl Default for StartNavigateTodoor_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartNavigateTodoor_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartNavigateTodoor_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartNavigateTodoor_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartNavigateTodoor_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartNavigateTodoor_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartNavigateTodoor_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartNavigateTodoor_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartNavigateTodoor_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartNavigateTodoor_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartNavigateTodoor_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartNavigateTodoor_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartNavigateTodoor_Response__init(msg: *mut StartNavigateTodoor_Response) -> bool;
    fn master_interfaces__srv__StartNavigateTodoor_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartNavigateTodoor_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartNavigateTodoor_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartNavigateTodoor_Response>);
    fn master_interfaces__srv__StartNavigateTodoor_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartNavigateTodoor_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartNavigateTodoor_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartNavigateTodoor_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartNavigateTodoor_Response {
    /// Response
    /// 服务是否成功启动
    pub success: bool,

    /// 返回消息
    pub message: rosidl_runtime_rs::String,

    /// 总路径点数量
    pub total_waypoints: i32,

    /// 任务路径点数量
    pub task_waypoints: i32,

    /// 路径点分组数量
    pub waypoint_groups: i32,

}



impl Default for StartNavigateTodoor_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartNavigateTodoor_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartNavigateTodoor_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartNavigateTodoor_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartNavigateTodoor_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartNavigateTodoor_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartNavigateTodoor_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartNavigateTodoor_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartNavigateTodoor_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartNavigateTodoor_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartNavigateTodoor_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartPlan_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartPlan_Request__init(msg: *mut StartPlan_Request) -> bool;
    fn master_interfaces__srv__StartPlan_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartPlan_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartPlan_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartPlan_Request>);
    fn master_interfaces__srv__StartPlan_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartPlan_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartPlan_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartPlan_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartPlan_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub json_url: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_type: rosidl_runtime_rs::String,

}



impl Default for StartPlan_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartPlan_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartPlan_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartPlan_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartPlan_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartPlan_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartPlan_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartPlan_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartPlan_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartPlan_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartPlan_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartPlan_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartPlan_Response__init(msg: *mut StartPlan_Response) -> bool;
    fn master_interfaces__srv__StartPlan_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartPlan_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartPlan_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartPlan_Response>);
    fn master_interfaces__srv__StartPlan_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartPlan_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartPlan_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartPlan_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartPlan_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub code: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub msg: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub task_id: rosidl_runtime_rs::String,

}



impl Default for StartPlan_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartPlan_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartPlan_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartPlan_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartPlan_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartPlan_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartPlan_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartPlan_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartPlan_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartPlan_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartPlan_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecord_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartRecord_Request__init(msg: *mut StartRecord_Request) -> bool;
    fn master_interfaces__srv__StartRecord_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartRecord_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartRecord_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartRecord_Request>);
    fn master_interfaces__srv__StartRecord_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartRecord_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartRecord_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartRecord_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecord_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bag_name: rosidl_runtime_rs::String,

}



impl Default for StartRecord_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartRecord_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartRecord_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartRecord_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecord_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecord_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecord_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartRecord_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartRecord_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartRecord_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecord_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecord_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartRecord_Response__init(msg: *mut StartRecord_Response) -> bool;
    fn master_interfaces__srv__StartRecord_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartRecord_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartRecord_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartRecord_Response>);
    fn master_interfaces__srv__StartRecord_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartRecord_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartRecord_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartRecord_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecord_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for StartRecord_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartRecord_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartRecord_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartRecord_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecord_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecord_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecord_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartRecord_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartRecord_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartRecord_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecord_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecordPath_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartRecordPath_Request__init(msg: *mut StartRecordPath_Request) -> bool;
    fn master_interfaces__srv__StartRecordPath_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartRecordPath_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StartRecordPath_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartRecordPath_Request>);
    fn master_interfaces__srv__StartRecordPath_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartRecordPath_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StartRecordPath_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StartRecordPath_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecordPath_Request {
    /// online/offline
    pub mode: rosidl_runtime_rs::String,

    /// community/building-unit/floor-door
    pub type_: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub community: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub building: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub unit: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub floor: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub door: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub path_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bag_path: rosidl_runtime_rs::String,

    /// 采点间隔
    pub point_interval: f64,

}



impl Default for StartRecordPath_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartRecordPath_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartRecordPath_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartRecordPath_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecordPath_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecordPath_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecordPath_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartRecordPath_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartRecordPath_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartRecordPath_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecordPath_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecordPath_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StartRecordPath_Response__init(msg: *mut StartRecordPath_Response) -> bool;
    fn master_interfaces__srv__StartRecordPath_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StartRecordPath_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StartRecordPath_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StartRecordPath_Response>);
    fn master_interfaces__srv__StartRecordPath_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StartRecordPath_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StartRecordPath_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StartRecordPath_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StartRecordPath_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,

}



impl Default for StartRecordPath_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StartRecordPath_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StartRecordPath_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StartRecordPath_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecordPath_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecordPath_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StartRecordPath_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StartRecordPath_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StartRecordPath_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StartRecordPath_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StartRecordPath_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopPlayback_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StopPlayback_Request__init(msg: *mut StopPlayback_Request) -> bool;
    fn master_interfaces__srv__StopPlayback_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StopPlayback_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StopPlayback_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StopPlayback_Request>);
    fn master_interfaces__srv__StopPlayback_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StopPlayback_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StopPlayback_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StopPlayback_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopPlayback_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for StopPlayback_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StopPlayback_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StopPlayback_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StopPlayback_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopPlayback_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopPlayback_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopPlayback_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StopPlayback_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StopPlayback_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StopPlayback_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopPlayback_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopPlayback_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StopPlayback_Response__init(msg: *mut StopPlayback_Response) -> bool;
    fn master_interfaces__srv__StopPlayback_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StopPlayback_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StopPlayback_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StopPlayback_Response>);
    fn master_interfaces__srv__StopPlayback_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StopPlayback_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StopPlayback_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StopPlayback_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopPlayback_Response {
    /// 是否成功停止
    pub success: bool,

    /// 返回消息
    pub message: rosidl_runtime_rs::String,

}



impl Default for StopPlayback_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StopPlayback_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StopPlayback_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StopPlayback_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopPlayback_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopPlayback_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopPlayback_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StopPlayback_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StopPlayback_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StopPlayback_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopPlayback_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopRecordPath_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StopRecordPath_Request__init(msg: *mut StopRecordPath_Request) -> bool;
    fn master_interfaces__srv__StopRecordPath_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StopRecordPath_Request>, size: usize) -> bool;
    fn master_interfaces__srv__StopRecordPath_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StopRecordPath_Request>);
    fn master_interfaces__srv__StopRecordPath_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StopRecordPath_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<StopRecordPath_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__StopRecordPath_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopRecordPath_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub structure_needs_at_least_one_member: u8,

}



impl Default for StopRecordPath_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StopRecordPath_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StopRecordPath_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StopRecordPath_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopRecordPath_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopRecordPath_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopRecordPath_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StopRecordPath_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StopRecordPath_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StopRecordPath_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopRecordPath_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopRecordPath_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__StopRecordPath_Response__init(msg: *mut StopRecordPath_Response) -> bool;
    fn master_interfaces__srv__StopRecordPath_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<StopRecordPath_Response>, size: usize) -> bool;
    fn master_interfaces__srv__StopRecordPath_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<StopRecordPath_Response>);
    fn master_interfaces__srv__StopRecordPath_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<StopRecordPath_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<StopRecordPath_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__StopRecordPath_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct StopRecordPath_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub path: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub num: i32,

}



impl Default for StopRecordPath_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__StopRecordPath_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__StopRecordPath_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for StopRecordPath_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopRecordPath_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopRecordPath_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__StopRecordPath_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for StopRecordPath_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for StopRecordPath_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/StopRecordPath_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__StopRecordPath_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__String_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__String_Request__init(msg: *mut String_Request) -> bool;
    fn master_interfaces__srv__String_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<String_Request>, size: usize) -> bool;
    fn master_interfaces__srv__String_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<String_Request>);
    fn master_interfaces__srv__String_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<String_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<String_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__String_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct String_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub name: rosidl_runtime_rs::String,

}



impl Default for String_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__String_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__String_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for String_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__String_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__String_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__String_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for String_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for String_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/String_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__String_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__String_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__String_Response__init(msg: *mut String_Response) -> bool;
    fn master_interfaces__srv__String_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<String_Response>, size: usize) -> bool;
    fn master_interfaces__srv__String_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<String_Response>);
    fn master_interfaces__srv__String_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<String_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<String_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__String_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct String_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for String_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__String_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__String_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for String_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__String_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__String_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__String_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for String_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for String_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/String_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__String_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__SwitchMap_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__SwitchMap_Request__init(msg: *mut SwitchMap_Request) -> bool;
    fn master_interfaces__srv__SwitchMap_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SwitchMap_Request>, size: usize) -> bool;
    fn master_interfaces__srv__SwitchMap_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SwitchMap_Request>);
    fn master_interfaces__srv__SwitchMap_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SwitchMap_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<SwitchMap_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__SwitchMap_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SwitchMap_Request {
    /// 请求字段
    /// 地图 YAML 文件的完整路径（含文件名）
    pub map_yaml_path: rosidl_runtime_rs::String,

    /// PCD 文件的完整路径（含文件名）
    pub pcd_path: rosidl_runtime_rs::String,

}



impl Default for SwitchMap_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__SwitchMap_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__SwitchMap_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SwitchMap_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__SwitchMap_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__SwitchMap_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__SwitchMap_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SwitchMap_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SwitchMap_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/SwitchMap_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__SwitchMap_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__SwitchMap_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__SwitchMap_Response__init(msg: *mut SwitchMap_Response) -> bool;
    fn master_interfaces__srv__SwitchMap_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SwitchMap_Response>, size: usize) -> bool;
    fn master_interfaces__srv__SwitchMap_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SwitchMap_Response>);
    fn master_interfaces__srv__SwitchMap_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SwitchMap_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<SwitchMap_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__SwitchMap_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SwitchMap_Response {
    /// 响应字段
    /// 服务调用是否成功
    pub success: bool,

    /// 返回的消息或错误说明
    pub message: rosidl_runtime_rs::String,

}



impl Default for SwitchMap_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__SwitchMap_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__SwitchMap_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SwitchMap_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__SwitchMap_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__SwitchMap_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__SwitchMap_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SwitchMap_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SwitchMap_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/SwitchMap_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__SwitchMap_Response() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__VisionElevatorStatus_Request() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__VisionElevatorStatus_Request__init(msg: *mut VisionElevatorStatus_Request) -> bool;
    fn master_interfaces__srv__VisionElevatorStatus_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Request>, size: usize) -> bool;
    fn master_interfaces__srv__VisionElevatorStatus_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Request>);
    fn master_interfaces__srv__VisionElevatorStatus_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Request>) -> bool;
}

// Corresponds to master_interfaces__srv__VisionElevatorStatus_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Request {
    /// True=开启检测，False=关闭检测
    pub enable: bool,

    /// 小车状态，进电梯=in,出电梯=out
    pub car_status: rosidl_runtime_rs::String,

}



impl Default for VisionElevatorStatus_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__VisionElevatorStatus_Request__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__VisionElevatorStatus_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__VisionElevatorStatus_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__VisionElevatorStatus_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__VisionElevatorStatus_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_Request where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/VisionElevatorStatus_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__VisionElevatorStatus_Request() }
  }
}


#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__VisionElevatorStatus_Response() -> *const std::ffi::c_void;
}

#[link(name = "master_interfaces__rosidl_generator_c")]
extern "C" {
    fn master_interfaces__srv__VisionElevatorStatus_Response__init(msg: *mut VisionElevatorStatus_Response) -> bool;
    fn master_interfaces__srv__VisionElevatorStatus_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Response>, size: usize) -> bool;
    fn master_interfaces__srv__VisionElevatorStatus_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Response>);
    fn master_interfaces__srv__VisionElevatorStatus_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<VisionElevatorStatus_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<VisionElevatorStatus_Response>) -> bool;
}

// Corresponds to master_interfaces__srv__VisionElevatorStatus_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct VisionElevatorStatus_Response {
    /// 门状态：open/closed/half-open/unknown/error
    pub door_state: rosidl_runtime_rs::String,

    /// 检测置信度（%）
    pub confidence: f32,

    /// 操作是否成功（True/False）
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for VisionElevatorStatus_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !master_interfaces__srv__VisionElevatorStatus_Response__init(&mut msg as *mut _) {
        panic!("Call to master_interfaces__srv__VisionElevatorStatus_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for VisionElevatorStatus_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__VisionElevatorStatus_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__VisionElevatorStatus_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { master_interfaces__srv__VisionElevatorStatus_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for VisionElevatorStatus_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for VisionElevatorStatus_Response where Self: Sized {
  const TYPE_NAME: &'static str = "master_interfaces/srv/VisionElevatorStatus_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__master_interfaces__srv__VisionElevatorStatus_Response() }
  }
}






#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__AddPathPoints() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__AddPathPoints
#[allow(missing_docs, non_camel_case_types)]
pub struct AddPathPoints;

impl rosidl_runtime_rs::Service for AddPathPoints {
    type Request = AddPathPoints_Request;
    type Response = AddPathPoints_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__AddPathPoints() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelNavigation() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CancelNavigation
#[allow(missing_docs, non_camel_case_types)]
pub struct CancelNavigation;

impl rosidl_runtime_rs::Service for CancelNavigation {
    type Request = CancelNavigation_Request;
    type Response = CancelNavigation_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelNavigation() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecord() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CancelRecord
#[allow(missing_docs, non_camel_case_types)]
pub struct CancelRecord;

impl rosidl_runtime_rs::Service for CancelRecord {
    type Request = CancelRecord_Request;
    type Response = CancelRecord_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecord() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecordPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CancelRecordPath
#[allow(missing_docs, non_camel_case_types)]
pub struct CancelRecordPath;

impl rosidl_runtime_rs::Service for CancelRecordPath {
    type Request = CancelRecordPath_Request;
    type Response = CancelRecordPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CancelRecordPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CaptureCurrentPoint() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CaptureCurrentPoint
#[allow(missing_docs, non_camel_case_types)]
pub struct CaptureCurrentPoint;

impl rosidl_runtime_rs::Service for CaptureCurrentPoint {
    type Request = CaptureCurrentPoint_Request;
    type Response = CaptureCurrentPoint_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CaptureCurrentPoint() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ChangeLocalizer() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ChangeLocalizer
#[allow(missing_docs, non_camel_case_types)]
pub struct ChangeLocalizer;

impl rosidl_runtime_rs::Service for ChangeLocalizer {
    type Request = ChangeLocalizer_Request;
    type Response = ChangeLocalizer_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ChangeLocalizer() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__CheckBuildingOccupancy
#[allow(missing_docs, non_camel_case_types)]
pub struct CheckBuildingOccupancy;

impl rosidl_runtime_rs::Service for CheckBuildingOccupancy {
    type Request = CheckBuildingOccupancy_Request;
    type Response = CheckBuildingOccupancy_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__CheckBuildingOccupancy() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeleteBag() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__DeleteBag
#[allow(missing_docs, non_camel_case_types)]
pub struct DeleteBag;

impl rosidl_runtime_rs::Service for DeleteBag {
    type Request = DeleteBag_Request;
    type Response = DeleteBag_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeleteBag() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeletePathPoints() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__DeletePathPoints
#[allow(missing_docs, non_camel_case_types)]
pub struct DeletePathPoints;

impl rosidl_runtime_rs::Service for DeletePathPoints {
    type Request = DeletePathPoints_Request;
    type Response = DeletePathPoints_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DeletePathPoints() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DoorControl() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__DoorControl
#[allow(missing_docs, non_camel_case_types)]
pub struct DoorControl;

impl rosidl_runtime_rs::Service for DoorControl {
    type Request = DoorControl_Request;
    type Response = DoorControl_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__DoorControl() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EditTaskWaypoint() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__EditTaskWaypoint
#[allow(missing_docs, non_camel_case_types)]
pub struct EditTaskWaypoint;

impl rosidl_runtime_rs::Service for EditTaskWaypoint {
    type Request = EditTaskWaypoint_Request;
    type Response = EditTaskWaypoint_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EditTaskWaypoint() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EndRecord() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__EndRecord
#[allow(missing_docs, non_camel_case_types)]
pub struct EndRecord;

impl rosidl_runtime_rs::Service for EndRecord {
    type Request = EndRecord_Request;
    type Response = EndRecord_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__EndRecord() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__FollowPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__FollowPath
#[allow(missing_docs, non_camel_case_types)]
pub struct FollowPath;

impl rosidl_runtime_rs::Service for FollowPath {
    type Request = FollowPath_Request;
    type Response = FollowPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__FollowPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GenerateTask() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GenerateTask
#[allow(missing_docs, non_camel_case_types)]
pub struct GenerateTask;

impl rosidl_runtime_rs::Service for GenerateTask {
    type Request = GenerateTask_Request;
    type Response = GenerateTask_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GenerateTask() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetBagList() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetBagList
#[allow(missing_docs, non_camel_case_types)]
pub struct GetBagList;

impl rosidl_runtime_rs::Service for GetBagList {
    type Request = GetBagList_Request;
    type Response = GetBagList_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetBagList() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetCargoStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetCargoStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct GetCargoStatus;

impl rosidl_runtime_rs::Service for GetCargoStatus {
    type Request = GetCargoStatus_Request;
    type Response = GetCargoStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetCargoStatus() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetElevatorId() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetElevatorId
#[allow(missing_docs, non_camel_case_types)]
pub struct GetElevatorId;

impl rosidl_runtime_rs::Service for GetElevatorId {
    type Request = GetElevatorId_Request;
    type Response = GetElevatorId_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetElevatorId() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetEmergencyStop() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetEmergencyStop
#[allow(missing_docs, non_camel_case_types)]
pub struct GetEmergencyStop;

impl rosidl_runtime_rs::Service for GetEmergencyStop {
    type Request = GetEmergencyStop_Request;
    type Response = GetEmergencyStop_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetEmergencyStop() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetNavigationStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetNavigationStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct GetNavigationStatus;

impl rosidl_runtime_rs::Service for GetNavigationStatus {
    type Request = GetNavigationStatus_Request;
    type Response = GetNavigationStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetNavigationStatus() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathList() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetPathList
#[allow(missing_docs, non_camel_case_types)]
pub struct GetPathList;

impl rosidl_runtime_rs::Service for GetPathList {
    type Request = GetPathList_Request;
    type Response = GetPathList_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathList() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathPoints() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetPathPoints
#[allow(missing_docs, non_camel_case_types)]
pub struct GetPathPoints;

impl rosidl_runtime_rs::Service for GetPathPoints {
    type Request = GetPathPoints_Request;
    type Response = GetPathPoints_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPathPoints() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPlanStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__GetPlanStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct GetPlanStatus;

impl rosidl_runtime_rs::Service for GetPlanStatus {
    type Request = GetPlanStatus_Request;
    type Response = GetPlanStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__GetPlanStatus() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateThroughPoses() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__NavigateThroughPoses
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateThroughPoses;

impl rosidl_runtime_rs::Service for NavigateThroughPoses {
    type Request = NavigateThroughPoses_Request;
    type Response = NavigateThroughPoses_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateThroughPoses() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateToPose() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__NavigateToPose
#[allow(missing_docs, non_camel_case_types)]
pub struct NavigateToPose;

impl rosidl_runtime_rs::Service for NavigateToPose {
    type Request = NavigateToPose_Request;
    type Response = NavigateToPose_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NavigateToPose() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NodeString() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__NodeString
#[allow(missing_docs, non_camel_case_types)]
pub struct NodeString;

impl rosidl_runtime_rs::Service for NodeString {
    type Request = NodeString_Request;
    type Response = NodeString_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__NodeString() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__PGOMapping() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__PGOMapping
#[allow(missing_docs, non_camel_case_types)]
pub struct PGOMapping;

impl rosidl_runtime_rs::Service for PGOMapping {
    type Request = PGOMapping_Request;
    type Response = PGOMapping_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__PGOMapping() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__Ping() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__Ping
#[allow(missing_docs, non_camel_case_types)]
pub struct Ping;

impl rosidl_runtime_rs::Service for Ping {
    type Request = Ping_Request;
    type Response = Ping_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__Ping() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReportException() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ReportException
#[allow(missing_docs, non_camel_case_types)]
pub struct ReportException;

impl rosidl_runtime_rs::Service for ReportException {
    type Request = ReportException_Request;
    type Response = ReportException_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReportException() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ResetTaskWaypoint() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ResetTaskWaypoint
#[allow(missing_docs, non_camel_case_types)]
pub struct ResetTaskWaypoint;

impl rosidl_runtime_rs::Service for ResetTaskWaypoint {
    type Request = ResetTaskWaypoint_Request;
    type Response = ResetTaskWaypoint_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ResetTaskWaypoint() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReturnHome() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__ReturnHome
#[allow(missing_docs, non_camel_case_types)]
pub struct ReturnHome;

impl rosidl_runtime_rs::Service for ReturnHome {
    type Request = ReturnHome_Request;
    type Response = ReturnHome_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__ReturnHome() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartExecuteTasks() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartExecuteTasks
#[allow(missing_docs, non_camel_case_types)]
pub struct StartExecuteTasks;

impl rosidl_runtime_rs::Service for StartExecuteTasks {
    type Request = StartExecuteTasks_Request;
    type Response = StartExecuteTasks_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartExecuteTasks() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMapping() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartMapping
#[allow(missing_docs, non_camel_case_types)]
pub struct StartMapping;

impl rosidl_runtime_rs::Service for StartMapping {
    type Request = StartMapping_Request;
    type Response = StartMapping_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMapping() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMultiTasksExecute() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartMultiTasksExecute
#[allow(missing_docs, non_camel_case_types)]
pub struct StartMultiTasksExecute;

impl rosidl_runtime_rs::Service for StartMultiTasksExecute {
    type Request = StartMultiTasksExecute_Request;
    type Response = StartMultiTasksExecute_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartMultiTasksExecute() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartNavigateTodoor() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartNavigateTodoor
#[allow(missing_docs, non_camel_case_types)]
pub struct StartNavigateTodoor;

impl rosidl_runtime_rs::Service for StartNavigateTodoor {
    type Request = StartNavigateTodoor_Request;
    type Response = StartNavigateTodoor_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartNavigateTodoor() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartPlan() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartPlan
#[allow(missing_docs, non_camel_case_types)]
pub struct StartPlan;

impl rosidl_runtime_rs::Service for StartPlan {
    type Request = StartPlan_Request;
    type Response = StartPlan_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartPlan() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecord() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartRecord
#[allow(missing_docs, non_camel_case_types)]
pub struct StartRecord;

impl rosidl_runtime_rs::Service for StartRecord {
    type Request = StartRecord_Request;
    type Response = StartRecord_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecord() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecordPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StartRecordPath
#[allow(missing_docs, non_camel_case_types)]
pub struct StartRecordPath;

impl rosidl_runtime_rs::Service for StartRecordPath {
    type Request = StartRecordPath_Request;
    type Response = StartRecordPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StartRecordPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopPlayback() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StopPlayback
#[allow(missing_docs, non_camel_case_types)]
pub struct StopPlayback;

impl rosidl_runtime_rs::Service for StopPlayback {
    type Request = StopPlayback_Request;
    type Response = StopPlayback_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopPlayback() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopRecordPath() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__StopRecordPath
#[allow(missing_docs, non_camel_case_types)]
pub struct StopRecordPath;

impl rosidl_runtime_rs::Service for StopRecordPath {
    type Request = StopRecordPath_Request;
    type Response = StopRecordPath_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__StopRecordPath() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__String() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__String
#[allow(missing_docs, non_camel_case_types)]
pub struct String;

impl rosidl_runtime_rs::Service for String {
    type Request = String_Request;
    type Response = String_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__String() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__SwitchMap() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__SwitchMap
#[allow(missing_docs, non_camel_case_types)]
pub struct SwitchMap;

impl rosidl_runtime_rs::Service for SwitchMap {
    type Request = SwitchMap_Request;
    type Response = SwitchMap_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__SwitchMap() }
    }
}




#[link(name = "master_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__VisionElevatorStatus() -> *const std::ffi::c_void;
}

// Corresponds to master_interfaces__srv__VisionElevatorStatus
#[allow(missing_docs, non_camel_case_types)]
pub struct VisionElevatorStatus;

impl rosidl_runtime_rs::Service for VisionElevatorStatus {
    type Request = VisionElevatorStatus_Request;
    type Response = VisionElevatorStatus_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__master_interfaces__srv__VisionElevatorStatus() }
    }
}


