#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "master_interfaces::master_interfaces__rosidl_typesupport_c" for configuration "MinSizeRel"
set_property(TARGET master_interfaces::master_interfaces__rosidl_typesupport_c APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(master_interfaces::master_interfaces__rosidl_typesupport_c PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_MINSIZEREL "rosidl_runtime_c::rosidl_runtime_c;rosidl_typesupport_c::rosidl_typesupport_c"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libmaster_interfaces__rosidl_typesupport_c.so"
  IMPORTED_SONAME_MINSIZEREL "libmaster_interfaces__rosidl_typesupport_c.so"
  )

list(APPEND _cmake_import_check_targets master_interfaces::master_interfaces__rosidl_typesupport_c )
list(APPEND _cmake_import_check_files_for_master_interfaces::master_interfaces__rosidl_typesupport_c "${_IMPORT_PREFIX}/lib/libmaster_interfaces__rosidl_typesupport_c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
