# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/FollowPath.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_FollowPath_Request(type):
    """Metaclass of message 'FollowPath_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.FollowPath_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__follow_path__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__follow_path__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__follow_path__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__follow_path__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__follow_path__request

            from nav_msgs.msg import Path
            if Path.__class__._TYPE_SUPPORT is None:
                Path.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class FollowPath_Request(metaclass=Metaclass_FollowPath_Request):
    """Message class 'FollowPath_Request'."""

    __slots__ = [
        '_path',
        '_controller_id',
        '_goal_checker_id',
        '_behavior_tree',
        '_timeout',
        '_waypoint_type',
    ]

    _fields_and_field_types = {
        'path': 'nav_msgs/Path',
        'controller_id': 'string',
        'goal_checker_id': 'string',
        'behavior_tree': 'string',
        'timeout': 'double',
        'waypoint_type': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['nav_msgs', 'msg'], 'Path'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from nav_msgs.msg import Path
        self.path = kwargs.get('path', Path())
        self.controller_id = kwargs.get('controller_id', str())
        self.goal_checker_id = kwargs.get('goal_checker_id', str())
        self.behavior_tree = kwargs.get('behavior_tree', str())
        self.timeout = kwargs.get('timeout', float())
        self.waypoint_type = kwargs.get('waypoint_type', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.path != other.path:
            return False
        if self.controller_id != other.controller_id:
            return False
        if self.goal_checker_id != other.goal_checker_id:
            return False
        if self.behavior_tree != other.behavior_tree:
            return False
        if self.timeout != other.timeout:
            return False
        if self.waypoint_type != other.waypoint_type:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def path(self):
        """Message field 'path'."""
        return self._path

    @path.setter
    def path(self, value):
        if __debug__:
            from nav_msgs.msg import Path
            assert \
                isinstance(value, Path), \
                "The 'path' field must be a sub message of type 'Path'"
        self._path = value

    @builtins.property
    def controller_id(self):
        """Message field 'controller_id'."""
        return self._controller_id

    @controller_id.setter
    def controller_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'controller_id' field must be of type 'str'"
        self._controller_id = value

    @builtins.property
    def goal_checker_id(self):
        """Message field 'goal_checker_id'."""
        return self._goal_checker_id

    @goal_checker_id.setter
    def goal_checker_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'goal_checker_id' field must be of type 'str'"
        self._goal_checker_id = value

    @builtins.property
    def behavior_tree(self):
        """Message field 'behavior_tree'."""
        return self._behavior_tree

    @behavior_tree.setter
    def behavior_tree(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'behavior_tree' field must be of type 'str'"
        self._behavior_tree = value

    @builtins.property
    def timeout(self):
        """Message field 'timeout'."""
        return self._timeout

    @timeout.setter
    def timeout(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'timeout' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'timeout' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._timeout = value

    @builtins.property
    def waypoint_type(self):
        """Message field 'waypoint_type'."""
        return self._waypoint_type

    @waypoint_type.setter
    def waypoint_type(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'waypoint_type' field must be of type 'str'"
        self._waypoint_type = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_FollowPath_Response(type):
    """Metaclass of message 'FollowPath_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.FollowPath_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__follow_path__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__follow_path__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__follow_path__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__follow_path__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__follow_path__response

            from master_interfaces.msg import StandardResponse
            if StandardResponse.__class__._TYPE_SUPPORT is None:
                StandardResponse.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class FollowPath_Response(metaclass=Metaclass_FollowPath_Response):
    """Message class 'FollowPath_Response'."""

    __slots__ = [
        '_response',
        '_task_id',
    ]

    _fields_and_field_types = {
        'response': 'master_interfaces/StandardResponse',
        'task_id': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'msg'], 'StandardResponse'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from master_interfaces.msg import StandardResponse
        self.response = kwargs.get('response', StandardResponse())
        self.task_id = kwargs.get('task_id', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.response != other.response:
            return False
        if self.task_id != other.task_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def response(self):
        """Message field 'response'."""
        return self._response

    @response.setter
    def response(self, value):
        if __debug__:
            from master_interfaces.msg import StandardResponse
            assert \
                isinstance(value, StandardResponse), \
                "The 'response' field must be a sub message of type 'StandardResponse'"
        self._response = value

    @builtins.property
    def task_id(self):
        """Message field 'task_id'."""
        return self._task_id

    @task_id.setter
    def task_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'task_id' field must be of type 'str'"
        self._task_id = value


class Metaclass_FollowPath(type):
    """Metaclass of service 'FollowPath'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.FollowPath')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__follow_path

            from master_interfaces.srv import _follow_path
            if _follow_path.Metaclass_FollowPath_Request._TYPE_SUPPORT is None:
                _follow_path.Metaclass_FollowPath_Request.__import_type_support__()
            if _follow_path.Metaclass_FollowPath_Response._TYPE_SUPPORT is None:
                _follow_path.Metaclass_FollowPath_Response.__import_type_support__()


class FollowPath(metaclass=Metaclass_FollowPath):
    from master_interfaces.srv._follow_path import FollowPath_Request as Request
    from master_interfaces.srv._follow_path import FollowPath_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
