# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/EditTaskWaypoint.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_EditTaskWaypoint_Request(type):
    """Metaclass of message 'EditTaskWaypoint_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.EditTaskWaypoint_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__edit_task_waypoint__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__edit_task_waypoint__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__edit_task_waypoint__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__edit_task_waypoint__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__edit_task_waypoint__request

            from geometry_msgs.msg import Pose
            if Pose.__class__._TYPE_SUPPORT is None:
                Pose.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class EditTaskWaypoint_Request(metaclass=Metaclass_EditTaskWaypoint_Request):
    """Message class 'EditTaskWaypoint_Request'."""

    __slots__ = [
        '_task_file_path',
        '_waypoint_id',
        '_pose',
        '_waypoint_task_id',
        '_is_task_point',
        '_speed_mode',
        '_is_backward',
        '_is_single_point',
    ]

    _fields_and_field_types = {
        'task_file_path': 'string',
        'waypoint_id': 'int32',
        'pose': 'geometry_msgs/Pose',
        'waypoint_task_id': 'string',
        'is_task_point': 'int8',
        'speed_mode': 'string',
        'is_backward': 'int8',
        'is_single_point': 'int8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Pose'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.task_file_path = kwargs.get('task_file_path', str())
        self.waypoint_id = kwargs.get('waypoint_id', int())
        from geometry_msgs.msg import Pose
        self.pose = kwargs.get('pose', Pose())
        self.waypoint_task_id = kwargs.get('waypoint_task_id', str())
        self.is_task_point = kwargs.get('is_task_point', int())
        self.speed_mode = kwargs.get('speed_mode', str())
        self.is_backward = kwargs.get('is_backward', int())
        self.is_single_point = kwargs.get('is_single_point', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.task_file_path != other.task_file_path:
            return False
        if self.waypoint_id != other.waypoint_id:
            return False
        if self.pose != other.pose:
            return False
        if self.waypoint_task_id != other.waypoint_task_id:
            return False
        if self.is_task_point != other.is_task_point:
            return False
        if self.speed_mode != other.speed_mode:
            return False
        if self.is_backward != other.is_backward:
            return False
        if self.is_single_point != other.is_single_point:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def task_file_path(self):
        """Message field 'task_file_path'."""
        return self._task_file_path

    @task_file_path.setter
    def task_file_path(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'task_file_path' field must be of type 'str'"
        self._task_file_path = value

    @builtins.property
    def waypoint_id(self):
        """Message field 'waypoint_id'."""
        return self._waypoint_id

    @waypoint_id.setter
    def waypoint_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'waypoint_id' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'waypoint_id' field must be an integer in [-2147483648, 2147483647]"
        self._waypoint_id = value

    @builtins.property
    def pose(self):
        """Message field 'pose'."""
        return self._pose

    @pose.setter
    def pose(self, value):
        if __debug__:
            from geometry_msgs.msg import Pose
            assert \
                isinstance(value, Pose), \
                "The 'pose' field must be a sub message of type 'Pose'"
        self._pose = value

    @builtins.property
    def waypoint_task_id(self):
        """Message field 'waypoint_task_id'."""
        return self._waypoint_task_id

    @waypoint_task_id.setter
    def waypoint_task_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'waypoint_task_id' field must be of type 'str'"
        self._waypoint_task_id = value

    @builtins.property
    def is_task_point(self):
        """Message field 'is_task_point'."""
        return self._is_task_point

    @is_task_point.setter
    def is_task_point(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'is_task_point' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'is_task_point' field must be an integer in [-128, 127]"
        self._is_task_point = value

    @builtins.property
    def speed_mode(self):
        """Message field 'speed_mode'."""
        return self._speed_mode

    @speed_mode.setter
    def speed_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'speed_mode' field must be of type 'str'"
        self._speed_mode = value

    @builtins.property
    def is_backward(self):
        """Message field 'is_backward'."""
        return self._is_backward

    @is_backward.setter
    def is_backward(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'is_backward' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'is_backward' field must be an integer in [-128, 127]"
        self._is_backward = value

    @builtins.property
    def is_single_point(self):
        """Message field 'is_single_point'."""
        return self._is_single_point

    @is_single_point.setter
    def is_single_point(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'is_single_point' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'is_single_point' field must be an integer in [-128, 127]"
        self._is_single_point = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_EditTaskWaypoint_Response(type):
    """Metaclass of message 'EditTaskWaypoint_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.EditTaskWaypoint_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__edit_task_waypoint__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__edit_task_waypoint__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__edit_task_waypoint__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__edit_task_waypoint__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__edit_task_waypoint__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class EditTaskWaypoint_Response(metaclass=Metaclass_EditTaskWaypoint_Response):
    """Message class 'EditTaskWaypoint_Response'."""

    __slots__ = [
        '_success',
        '_message',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value


class Metaclass_EditTaskWaypoint(type):
    """Metaclass of service 'EditTaskWaypoint'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.EditTaskWaypoint')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__edit_task_waypoint

            from master_interfaces.srv import _edit_task_waypoint
            if _edit_task_waypoint.Metaclass_EditTaskWaypoint_Request._TYPE_SUPPORT is None:
                _edit_task_waypoint.Metaclass_EditTaskWaypoint_Request.__import_type_support__()
            if _edit_task_waypoint.Metaclass_EditTaskWaypoint_Response._TYPE_SUPPORT is None:
                _edit_task_waypoint.Metaclass_EditTaskWaypoint_Response.__import_type_support__()


class EditTaskWaypoint(metaclass=Metaclass_EditTaskWaypoint):
    from master_interfaces.srv._edit_task_waypoint import EditTaskWaypoint_Request as Request
    from master_interfaces.srv._edit_task_waypoint import EditTaskWaypoint_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
