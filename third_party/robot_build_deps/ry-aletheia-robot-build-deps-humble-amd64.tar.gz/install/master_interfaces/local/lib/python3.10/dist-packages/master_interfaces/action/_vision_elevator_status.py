# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:action/VisionElevatorStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_VisionElevatorStatus_Goal(type):
    """Metaclass of message 'VisionElevatorStatus_Goal'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_Goal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__goal
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__goal
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__goal
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__goal
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__goal

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_Goal(metaclass=Metaclass_VisionElevatorStatus_Goal):
    """Message class 'VisionElevatorStatus_Goal'."""

    __slots__ = [
        '_enable',
        '_car_status',
    ]

    _fields_and_field_types = {
        'enable': 'boolean',
        'car_status': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.enable = kwargs.get('enable', bool())
        self.car_status = kwargs.get('car_status', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.enable != other.enable:
            return False
        if self.car_status != other.car_status:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def enable(self):
        """Message field 'enable'."""
        return self._enable

    @enable.setter
    def enable(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'enable' field must be of type 'bool'"
        self._enable = value

    @builtins.property
    def car_status(self):
        """Message field 'car_status'."""
        return self._car_status

    @car_status.setter
    def car_status(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'car_status' field must be of type 'str'"
        self._car_status = value


# Import statements for member types

# already imported above
# import builtins

import math  # noqa: E402, I100

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_Result(type):
    """Metaclass of message 'VisionElevatorStatus_Result'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_Result')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__result
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__result
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__result
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__result
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__result

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_Result(metaclass=Metaclass_VisionElevatorStatus_Result):
    """Message class 'VisionElevatorStatus_Result'."""

    __slots__ = [
        '_door_state',
        '_confidence',
        '_success',
        '_message',
    ]

    _fields_and_field_types = {
        'door_state': 'string',
        'confidence': 'float',
        'success': 'boolean',
        'message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.door_state = kwargs.get('door_state', str())
        self.confidence = kwargs.get('confidence', float())
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.door_state != other.door_state:
            return False
        if self.confidence != other.confidence:
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def door_state(self):
        """Message field 'door_state'."""
        return self._door_state

    @door_state.setter
    def door_state(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'door_state' field must be of type 'str'"
        self._door_state = value

    @builtins.property
    def confidence(self):
        """Message field 'confidence'."""
        return self._confidence

    @confidence.setter
    def confidence(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'confidence' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'confidence' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._confidence = value

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import math

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_Feedback(type):
    """Metaclass of message 'VisionElevatorStatus_Feedback'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_Feedback')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__feedback
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__feedback
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__feedback
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__feedback
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__feedback

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_Feedback(metaclass=Metaclass_VisionElevatorStatus_Feedback):
    """Message class 'VisionElevatorStatus_Feedback'."""

    __slots__ = [
        '_collected_frames',
        '_target_frames',
        '_current_state',
        '_current_confidence',
        '_progress_percentage',
        '_status_message',
    ]

    _fields_and_field_types = {
        'collected_frames': 'int32',
        'target_frames': 'int32',
        'current_state': 'string',
        'current_confidence': 'float',
        'progress_percentage': 'float',
        'status_message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.collected_frames = kwargs.get('collected_frames', int())
        self.target_frames = kwargs.get('target_frames', int())
        self.current_state = kwargs.get('current_state', str())
        self.current_confidence = kwargs.get('current_confidence', float())
        self.progress_percentage = kwargs.get('progress_percentage', float())
        self.status_message = kwargs.get('status_message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.collected_frames != other.collected_frames:
            return False
        if self.target_frames != other.target_frames:
            return False
        if self.current_state != other.current_state:
            return False
        if self.current_confidence != other.current_confidence:
            return False
        if self.progress_percentage != other.progress_percentage:
            return False
        if self.status_message != other.status_message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def collected_frames(self):
        """Message field 'collected_frames'."""
        return self._collected_frames

    @collected_frames.setter
    def collected_frames(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'collected_frames' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'collected_frames' field must be an integer in [-2147483648, 2147483647]"
        self._collected_frames = value

    @builtins.property
    def target_frames(self):
        """Message field 'target_frames'."""
        return self._target_frames

    @target_frames.setter
    def target_frames(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'target_frames' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'target_frames' field must be an integer in [-2147483648, 2147483647]"
        self._target_frames = value

    @builtins.property
    def current_state(self):
        """Message field 'current_state'."""
        return self._current_state

    @current_state.setter
    def current_state(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_state' field must be of type 'str'"
        self._current_state = value

    @builtins.property
    def current_confidence(self):
        """Message field 'current_confidence'."""
        return self._current_confidence

    @current_confidence.setter
    def current_confidence(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'current_confidence' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'current_confidence' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._current_confidence = value

    @builtins.property
    def progress_percentage(self):
        """Message field 'progress_percentage'."""
        return self._progress_percentage

    @progress_percentage.setter
    def progress_percentage(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'progress_percentage' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'progress_percentage' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._progress_percentage = value

    @builtins.property
    def status_message(self):
        """Message field 'status_message'."""
        return self._status_message

    @status_message.setter
    def status_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'status_message' field must be of type 'str'"
        self._status_message = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_SendGoal_Request(type):
    """Metaclass of message 'VisionElevatorStatus_SendGoal_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_SendGoal_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__send_goal__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__send_goal__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__send_goal__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__send_goal__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__send_goal__request

            from master_interfaces.action import VisionElevatorStatus
            if VisionElevatorStatus.Goal.__class__._TYPE_SUPPORT is None:
                VisionElevatorStatus.Goal.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_SendGoal_Request(metaclass=Metaclass_VisionElevatorStatus_SendGoal_Request):
    """Message class 'VisionElevatorStatus_SendGoal_Request'."""

    __slots__ = [
        '_goal_id',
        '_goal',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'goal': 'master_interfaces/VisionElevatorStatus_Goal',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'VisionElevatorStatus_Goal'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Goal
        self.goal = kwargs.get('goal', VisionElevatorStatus_Goal())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.goal != other.goal:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def goal(self):
        """Message field 'goal'."""
        return self._goal

    @goal.setter
    def goal(self, value):
        if __debug__:
            from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Goal
            assert \
                isinstance(value, VisionElevatorStatus_Goal), \
                "The 'goal' field must be a sub message of type 'VisionElevatorStatus_Goal'"
        self._goal = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_SendGoal_Response(type):
    """Metaclass of message 'VisionElevatorStatus_SendGoal_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_SendGoal_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__send_goal__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__send_goal__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__send_goal__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__send_goal__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__send_goal__response

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_SendGoal_Response(metaclass=Metaclass_VisionElevatorStatus_SendGoal_Response):
    """Message class 'VisionElevatorStatus_SendGoal_Response'."""

    __slots__ = [
        '_accepted',
        '_stamp',
    ]

    _fields_and_field_types = {
        'accepted': 'boolean',
        'stamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.accepted = kwargs.get('accepted', bool())
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.accepted != other.accepted:
            return False
        if self.stamp != other.stamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def accepted(self):
        """Message field 'accepted'."""
        return self._accepted

    @accepted.setter
    def accepted(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'accepted' field must be of type 'bool'"
        self._accepted = value

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value


class Metaclass_VisionElevatorStatus_SendGoal(type):
    """Metaclass of service 'VisionElevatorStatus_SendGoal'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_SendGoal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__vision_elevator_status__send_goal

            from master_interfaces.action import _vision_elevator_status
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_SendGoal_Request._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_SendGoal_Request.__import_type_support__()
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_SendGoal_Response._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_SendGoal_Response.__import_type_support__()


class VisionElevatorStatus_SendGoal(metaclass=Metaclass_VisionElevatorStatus_SendGoal):
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_SendGoal_Request as Request
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_SendGoal_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_GetResult_Request(type):
    """Metaclass of message 'VisionElevatorStatus_GetResult_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_GetResult_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__get_result__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__get_result__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__get_result__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__get_result__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__get_result__request

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_GetResult_Request(metaclass=Metaclass_VisionElevatorStatus_GetResult_Request):
    """Message class 'VisionElevatorStatus_GetResult_Request'."""

    __slots__ = [
        '_goal_id',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_GetResult_Response(type):
    """Metaclass of message 'VisionElevatorStatus_GetResult_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_GetResult_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__get_result__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__get_result__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__get_result__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__get_result__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__get_result__response

            from master_interfaces.action import VisionElevatorStatus
            if VisionElevatorStatus.Result.__class__._TYPE_SUPPORT is None:
                VisionElevatorStatus.Result.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_GetResult_Response(metaclass=Metaclass_VisionElevatorStatus_GetResult_Response):
    """Message class 'VisionElevatorStatus_GetResult_Response'."""

    __slots__ = [
        '_status',
        '_result',
    ]

    _fields_and_field_types = {
        'status': 'int8',
        'result': 'master_interfaces/VisionElevatorStatus_Result',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'VisionElevatorStatus_Result'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Result
        self.result = kwargs.get('result', VisionElevatorStatus_Result())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.result != other.result:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'status' field must be an integer in [-128, 127]"
        self._status = value

    @builtins.property
    def result(self):
        """Message field 'result'."""
        return self._result

    @result.setter
    def result(self, value):
        if __debug__:
            from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Result
            assert \
                isinstance(value, VisionElevatorStatus_Result), \
                "The 'result' field must be a sub message of type 'VisionElevatorStatus_Result'"
        self._result = value


class Metaclass_VisionElevatorStatus_GetResult(type):
    """Metaclass of service 'VisionElevatorStatus_GetResult'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_GetResult')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__vision_elevator_status__get_result

            from master_interfaces.action import _vision_elevator_status
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_GetResult_Request._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_GetResult_Request.__import_type_support__()
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_GetResult_Response._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_GetResult_Response.__import_type_support__()


class VisionElevatorStatus_GetResult(metaclass=Metaclass_VisionElevatorStatus_GetResult):
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_GetResult_Request as Request
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_GetResult_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_VisionElevatorStatus_FeedbackMessage(type):
    """Metaclass of message 'VisionElevatorStatus_FeedbackMessage'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus_FeedbackMessage')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__vision_elevator_status__feedback_message
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__vision_elevator_status__feedback_message
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__vision_elevator_status__feedback_message
            cls._TYPE_SUPPORT = module.type_support_msg__action__vision_elevator_status__feedback_message
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__vision_elevator_status__feedback_message

            from master_interfaces.action import VisionElevatorStatus
            if VisionElevatorStatus.Feedback.__class__._TYPE_SUPPORT is None:
                VisionElevatorStatus.Feedback.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class VisionElevatorStatus_FeedbackMessage(metaclass=Metaclass_VisionElevatorStatus_FeedbackMessage):
    """Message class 'VisionElevatorStatus_FeedbackMessage'."""

    __slots__ = [
        '_goal_id',
        '_feedback',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'feedback': 'master_interfaces/VisionElevatorStatus_Feedback',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'VisionElevatorStatus_Feedback'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Feedback
        self.feedback = kwargs.get('feedback', VisionElevatorStatus_Feedback())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.feedback != other.feedback:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def feedback(self):
        """Message field 'feedback'."""
        return self._feedback

    @feedback.setter
    def feedback(self, value):
        if __debug__:
            from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Feedback
            assert \
                isinstance(value, VisionElevatorStatus_Feedback), \
                "The 'feedback' field must be a sub message of type 'VisionElevatorStatus_Feedback'"
        self._feedback = value


class Metaclass_VisionElevatorStatus(type):
    """Metaclass of action 'VisionElevatorStatus'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.VisionElevatorStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_action__action__vision_elevator_status

            from action_msgs.msg import _goal_status_array
            if _goal_status_array.Metaclass_GoalStatusArray._TYPE_SUPPORT is None:
                _goal_status_array.Metaclass_GoalStatusArray.__import_type_support__()
            from action_msgs.srv import _cancel_goal
            if _cancel_goal.Metaclass_CancelGoal._TYPE_SUPPORT is None:
                _cancel_goal.Metaclass_CancelGoal.__import_type_support__()

            from master_interfaces.action import _vision_elevator_status
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_SendGoal._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_SendGoal.__import_type_support__()
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_GetResult._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_GetResult.__import_type_support__()
            if _vision_elevator_status.Metaclass_VisionElevatorStatus_FeedbackMessage._TYPE_SUPPORT is None:
                _vision_elevator_status.Metaclass_VisionElevatorStatus_FeedbackMessage.__import_type_support__()


class VisionElevatorStatus(metaclass=Metaclass_VisionElevatorStatus):

    # The goal message defined in the action definition.
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Goal as Goal
    # The result message defined in the action definition.
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Result as Result
    # The feedback message defined in the action definition.
    from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_Feedback as Feedback

    class Impl:

        # The send_goal service using a wrapped version of the goal message as a request.
        from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_SendGoal as SendGoalService
        # The get_result service using a wrapped version of the result message as a response.
        from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_GetResult as GetResultService
        # The feedback message with generic fields which wraps the feedback message.
        from master_interfaces.action._vision_elevator_status import VisionElevatorStatus_FeedbackMessage as FeedbackMessage

        # The generic service to cancel a goal.
        from action_msgs.srv._cancel_goal import CancelGoal as CancelGoalService
        # The generic message for get the status of a goal.
        from action_msgs.msg._goal_status_array import GoalStatusArray as GoalStatusMessage

    def __init__(self):
        raise NotImplementedError('Action classes can not be instantiated')
