# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/CaptureCurrentPoint.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_CaptureCurrentPoint_Request(type):
    """Metaclass of message 'CaptureCurrentPoint_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.CaptureCurrentPoint_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__capture_current_point__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__capture_current_point__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__capture_current_point__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__capture_current_point__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__capture_current_point__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CaptureCurrentPoint_Request(metaclass=Metaclass_CaptureCurrentPoint_Request):
    """Message class 'CaptureCurrentPoint_Request'."""

    __slots__ = [
        '_waypoint_id',
        '_path_name',
        '_type',
    ]

    _fields_and_field_types = {
        'waypoint_id': 'string',
        'path_name': 'string',
        'type': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.waypoint_id = kwargs.get('waypoint_id', str())
        self.path_name = kwargs.get('path_name', str())
        self.type = kwargs.get('type', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.waypoint_id != other.waypoint_id:
            return False
        if self.path_name != other.path_name:
            return False
        if self.type != other.type:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def waypoint_id(self):
        """Message field 'waypoint_id'."""
        return self._waypoint_id

    @waypoint_id.setter
    def waypoint_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'waypoint_id' field must be of type 'str'"
        self._waypoint_id = value

    @builtins.property
    def path_name(self):
        """Message field 'path_name'."""
        return self._path_name

    @path_name.setter
    def path_name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'path_name' field must be of type 'str'"
        self._path_name = value

    @builtins.property  # noqa: A003
    def type(self):  # noqa: A003
        """Message field 'type'."""
        return self._type

    @type.setter  # noqa: A003
    def type(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'type' field must be of type 'str'"
        self._type = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CaptureCurrentPoint_Response(type):
    """Metaclass of message 'CaptureCurrentPoint_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.CaptureCurrentPoint_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__capture_current_point__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__capture_current_point__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__capture_current_point__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__capture_current_point__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__capture_current_point__response

            from geometry_msgs.msg import Pose
            if Pose.__class__._TYPE_SUPPORT is None:
                Pose.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CaptureCurrentPoint_Response(metaclass=Metaclass_CaptureCurrentPoint_Response):
    """Message class 'CaptureCurrentPoint_Response'."""

    __slots__ = [
        '_success',
        '_message',
        '_pose',
        '_actual_waypoint_id',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'pose': 'geometry_msgs/Pose',
        'actual_waypoint_id': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Pose'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        from geometry_msgs.msg import Pose
        self.pose = kwargs.get('pose', Pose())
        self.actual_waypoint_id = kwargs.get('actual_waypoint_id', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.pose != other.pose:
            return False
        if self.actual_waypoint_id != other.actual_waypoint_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def pose(self):
        """Message field 'pose'."""
        return self._pose

    @pose.setter
    def pose(self, value):
        if __debug__:
            from geometry_msgs.msg import Pose
            assert \
                isinstance(value, Pose), \
                "The 'pose' field must be a sub message of type 'Pose'"
        self._pose = value

    @builtins.property
    def actual_waypoint_id(self):
        """Message field 'actual_waypoint_id'."""
        return self._actual_waypoint_id

    @actual_waypoint_id.setter
    def actual_waypoint_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'actual_waypoint_id' field must be of type 'str'"
        self._actual_waypoint_id = value


class Metaclass_CaptureCurrentPoint(type):
    """Metaclass of service 'CaptureCurrentPoint'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.CaptureCurrentPoint')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__capture_current_point

            from master_interfaces.srv import _capture_current_point
            if _capture_current_point.Metaclass_CaptureCurrentPoint_Request._TYPE_SUPPORT is None:
                _capture_current_point.Metaclass_CaptureCurrentPoint_Request.__import_type_support__()
            if _capture_current_point.Metaclass_CaptureCurrentPoint_Response._TYPE_SUPPORT is None:
                _capture_current_point.Metaclass_CaptureCurrentPoint_Response.__import_type_support__()


class CaptureCurrentPoint(metaclass=Metaclass_CaptureCurrentPoint):
    from master_interfaces.srv._capture_current_point import CaptureCurrentPoint_Request as Request
    from master_interfaces.srv._capture_current_point import CaptureCurrentPoint_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
