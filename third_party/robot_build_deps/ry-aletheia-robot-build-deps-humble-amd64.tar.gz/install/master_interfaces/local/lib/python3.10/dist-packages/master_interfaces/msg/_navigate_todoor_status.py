# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/NavigateTodoorStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_NavigateTodoorStatus(type):
    """Metaclass of message 'NavigateTodoorStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.NavigateTodoorStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__navigate_todoor_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__navigate_todoor_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__navigate_todoor_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__navigate_todoor_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__navigate_todoor_status

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

            from geometry_msgs.msg import Pose
            if Pose.__class__._TYPE_SUPPORT is None:
                Pose.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class NavigateTodoorStatus(metaclass=Metaclass_NavigateTodoorStatus):
    """Message class 'NavigateTodoorStatus'."""

    __slots__ = [
        '_stamp',
        '_status',
        '_current_waypoint_id',
        '_current_waypoint_index',
        '_current_pose',
        '_current_speed_mode',
        '_current_task',
        '_total_waypoints',
        '_completed_waypoints',
        '_remaining_waypoints',
        '_progress_percentage',
        '_total_groups',
        '_current_group_index',
        '_current_group_waypoints',
        '_completed_groups',
        '_distance_to_current_goal',
        '_elapsed_time',
        '_error_message',
    ]

    _fields_and_field_types = {
        'stamp': 'builtin_interfaces/Time',
        'status': 'string',
        'current_waypoint_id': 'string',
        'current_waypoint_index': 'int32',
        'current_pose': 'geometry_msgs/Pose',
        'current_speed_mode': 'string',
        'current_task': 'string',
        'total_waypoints': 'int32',
        'completed_waypoints': 'int32',
        'remaining_waypoints': 'int32',
        'progress_percentage': 'float',
        'total_groups': 'int32',
        'current_group_index': 'int32',
        'current_group_waypoints': 'int32',
        'completed_groups': 'int32',
        'distance_to_current_goal': 'float',
        'elapsed_time': 'float',
        'error_message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Pose'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())
        self.status = kwargs.get('status', str())
        self.current_waypoint_id = kwargs.get('current_waypoint_id', str())
        self.current_waypoint_index = kwargs.get('current_waypoint_index', int())
        from geometry_msgs.msg import Pose
        self.current_pose = kwargs.get('current_pose', Pose())
        self.current_speed_mode = kwargs.get('current_speed_mode', str())
        self.current_task = kwargs.get('current_task', str())
        self.total_waypoints = kwargs.get('total_waypoints', int())
        self.completed_waypoints = kwargs.get('completed_waypoints', int())
        self.remaining_waypoints = kwargs.get('remaining_waypoints', int())
        self.progress_percentage = kwargs.get('progress_percentage', float())
        self.total_groups = kwargs.get('total_groups', int())
        self.current_group_index = kwargs.get('current_group_index', int())
        self.current_group_waypoints = kwargs.get('current_group_waypoints', int())
        self.completed_groups = kwargs.get('completed_groups', int())
        self.distance_to_current_goal = kwargs.get('distance_to_current_goal', float())
        self.elapsed_time = kwargs.get('elapsed_time', float())
        self.error_message = kwargs.get('error_message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.stamp != other.stamp:
            return False
        if self.status != other.status:
            return False
        if self.current_waypoint_id != other.current_waypoint_id:
            return False
        if self.current_waypoint_index != other.current_waypoint_index:
            return False
        if self.current_pose != other.current_pose:
            return False
        if self.current_speed_mode != other.current_speed_mode:
            return False
        if self.current_task != other.current_task:
            return False
        if self.total_waypoints != other.total_waypoints:
            return False
        if self.completed_waypoints != other.completed_waypoints:
            return False
        if self.remaining_waypoints != other.remaining_waypoints:
            return False
        if self.progress_percentage != other.progress_percentage:
            return False
        if self.total_groups != other.total_groups:
            return False
        if self.current_group_index != other.current_group_index:
            return False
        if self.current_group_waypoints != other.current_group_waypoints:
            return False
        if self.completed_groups != other.completed_groups:
            return False
        if self.distance_to_current_goal != other.distance_to_current_goal:
            return False
        if self.elapsed_time != other.elapsed_time:
            return False
        if self.error_message != other.error_message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'status' field must be of type 'str'"
        self._status = value

    @builtins.property
    def current_waypoint_id(self):
        """Message field 'current_waypoint_id'."""
        return self._current_waypoint_id

    @current_waypoint_id.setter
    def current_waypoint_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_waypoint_id' field must be of type 'str'"
        self._current_waypoint_id = value

    @builtins.property
    def current_waypoint_index(self):
        """Message field 'current_waypoint_index'."""
        return self._current_waypoint_index

    @current_waypoint_index.setter
    def current_waypoint_index(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'current_waypoint_index' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'current_waypoint_index' field must be an integer in [-2147483648, 2147483647]"
        self._current_waypoint_index = value

    @builtins.property
    def current_pose(self):
        """Message field 'current_pose'."""
        return self._current_pose

    @current_pose.setter
    def current_pose(self, value):
        if __debug__:
            from geometry_msgs.msg import Pose
            assert \
                isinstance(value, Pose), \
                "The 'current_pose' field must be a sub message of type 'Pose'"
        self._current_pose = value

    @builtins.property
    def current_speed_mode(self):
        """Message field 'current_speed_mode'."""
        return self._current_speed_mode

    @current_speed_mode.setter
    def current_speed_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_speed_mode' field must be of type 'str'"
        self._current_speed_mode = value

    @builtins.property
    def current_task(self):
        """Message field 'current_task'."""
        return self._current_task

    @current_task.setter
    def current_task(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_task' field must be of type 'str'"
        self._current_task = value

    @builtins.property
    def total_waypoints(self):
        """Message field 'total_waypoints'."""
        return self._total_waypoints

    @total_waypoints.setter
    def total_waypoints(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'total_waypoints' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'total_waypoints' field must be an integer in [-2147483648, 2147483647]"
        self._total_waypoints = value

    @builtins.property
    def completed_waypoints(self):
        """Message field 'completed_waypoints'."""
        return self._completed_waypoints

    @completed_waypoints.setter
    def completed_waypoints(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'completed_waypoints' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'completed_waypoints' field must be an integer in [-2147483648, 2147483647]"
        self._completed_waypoints = value

    @builtins.property
    def remaining_waypoints(self):
        """Message field 'remaining_waypoints'."""
        return self._remaining_waypoints

    @remaining_waypoints.setter
    def remaining_waypoints(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'remaining_waypoints' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'remaining_waypoints' field must be an integer in [-2147483648, 2147483647]"
        self._remaining_waypoints = value

    @builtins.property
    def progress_percentage(self):
        """Message field 'progress_percentage'."""
        return self._progress_percentage

    @progress_percentage.setter
    def progress_percentage(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'progress_percentage' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'progress_percentage' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._progress_percentage = value

    @builtins.property
    def total_groups(self):
        """Message field 'total_groups'."""
        return self._total_groups

    @total_groups.setter
    def total_groups(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'total_groups' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'total_groups' field must be an integer in [-2147483648, 2147483647]"
        self._total_groups = value

    @builtins.property
    def current_group_index(self):
        """Message field 'current_group_index'."""
        return self._current_group_index

    @current_group_index.setter
    def current_group_index(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'current_group_index' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'current_group_index' field must be an integer in [-2147483648, 2147483647]"
        self._current_group_index = value

    @builtins.property
    def current_group_waypoints(self):
        """Message field 'current_group_waypoints'."""
        return self._current_group_waypoints

    @current_group_waypoints.setter
    def current_group_waypoints(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'current_group_waypoints' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'current_group_waypoints' field must be an integer in [-2147483648, 2147483647]"
        self._current_group_waypoints = value

    @builtins.property
    def completed_groups(self):
        """Message field 'completed_groups'."""
        return self._completed_groups

    @completed_groups.setter
    def completed_groups(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'completed_groups' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'completed_groups' field must be an integer in [-2147483648, 2147483647]"
        self._completed_groups = value

    @builtins.property
    def distance_to_current_goal(self):
        """Message field 'distance_to_current_goal'."""
        return self._distance_to_current_goal

    @distance_to_current_goal.setter
    def distance_to_current_goal(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'distance_to_current_goal' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'distance_to_current_goal' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._distance_to_current_goal = value

    @builtins.property
    def elapsed_time(self):
        """Message field 'elapsed_time'."""
        return self._elapsed_time

    @elapsed_time.setter
    def elapsed_time(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'elapsed_time' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'elapsed_time' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._elapsed_time = value

    @builtins.property
    def error_message(self):
        """Message field 'error_message'."""
        return self._error_message

    @error_message.setter
    def error_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'error_message' field must be of type 'str'"
        self._error_message = value
