# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/MultiTaskDestination.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_MultiTaskDestination(type):
    """Metaclass of message 'MultiTaskDestination'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.MultiTaskDestination')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__multi_task_destination
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__multi_task_destination
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__multi_task_destination
            cls._TYPE_SUPPORT = module.type_support_msg__msg__multi_task_destination
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__multi_task_destination

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class MultiTaskDestination(metaclass=Metaclass_MultiTaskDestination):
    """Message class 'MultiTaskDestination'."""

    __slots__ = [
        '_building',
        '_unit',
        '_floor',
        '_door',
        '_cargo_type',
        '_delivery_code',
    ]

    _fields_and_field_types = {
        'building': 'string',
        'unit': 'string',
        'floor': 'string',
        'door': 'string',
        'cargo_type': 'int32',
        'delivery_code': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.building = kwargs.get('building', str())
        self.unit = kwargs.get('unit', str())
        self.floor = kwargs.get('floor', str())
        self.door = kwargs.get('door', str())
        self.cargo_type = kwargs.get('cargo_type', int())
        self.delivery_code = kwargs.get('delivery_code', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.building != other.building:
            return False
        if self.unit != other.unit:
            return False
        if self.floor != other.floor:
            return False
        if self.door != other.door:
            return False
        if self.cargo_type != other.cargo_type:
            return False
        if self.delivery_code != other.delivery_code:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def building(self):
        """Message field 'building'."""
        return self._building

    @building.setter
    def building(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'building' field must be of type 'str'"
        self._building = value

    @builtins.property
    def unit(self):
        """Message field 'unit'."""
        return self._unit

    @unit.setter
    def unit(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'unit' field must be of type 'str'"
        self._unit = value

    @builtins.property
    def floor(self):
        """Message field 'floor'."""
        return self._floor

    @floor.setter
    def floor(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'floor' field must be of type 'str'"
        self._floor = value

    @builtins.property
    def door(self):
        """Message field 'door'."""
        return self._door

    @door.setter
    def door(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'door' field must be of type 'str'"
        self._door = value

    @builtins.property
    def cargo_type(self):
        """Message field 'cargo_type'."""
        return self._cargo_type

    @cargo_type.setter
    def cargo_type(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cargo_type' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'cargo_type' field must be an integer in [-2147483648, 2147483647]"
        self._cargo_type = value

    @builtins.property
    def delivery_code(self):
        """Message field 'delivery_code'."""
        return self._delivery_code

    @delivery_code.setter
    def delivery_code(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'delivery_code' field must be of type 'str'"
        self._delivery_code = value
