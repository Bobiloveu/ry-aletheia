// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from master_interfaces:msg/NavigateTodoorStatus.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "master_interfaces/msg/detail/navigate_todoor_status__struct.h"
#include "master_interfaces/msg/detail/navigate_todoor_status__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool builtin_interfaces__msg__time__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * builtin_interfaces__msg__time__convert_to_py(void * raw_ros_message);
ROSIDL_GENERATOR_C_IMPORT
bool geometry_msgs__msg__pose__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * geometry_msgs__msg__pose__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__msg__navigate_todoor_status__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[67];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.msg._navigate_todoor_status.NavigateTodoorStatus", full_classname_dest, 66) == 0);
  }
  master_interfaces__msg__NavigateTodoorStatus * ros_message = _ros_message;
  {  // stamp
    PyObject * field = PyObject_GetAttrString(_pymsg, "stamp");
    if (!field) {
      return false;
    }
    if (!builtin_interfaces__msg__time__convert_from_py(field, &ros_message->stamp)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // status
    PyObject * field = PyObject_GetAttrString(_pymsg, "status");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->status, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // current_waypoint_id
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_waypoint_id");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->current_waypoint_id, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // current_waypoint_index
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_waypoint_index");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->current_waypoint_index = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // current_pose
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_pose");
    if (!field) {
      return false;
    }
    if (!geometry_msgs__msg__pose__convert_from_py(field, &ros_message->current_pose)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // current_speed_mode
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_speed_mode");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->current_speed_mode, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // current_task
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_task");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->current_task, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // total_waypoints
    PyObject * field = PyObject_GetAttrString(_pymsg, "total_waypoints");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->total_waypoints = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // completed_waypoints
    PyObject * field = PyObject_GetAttrString(_pymsg, "completed_waypoints");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->completed_waypoints = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // remaining_waypoints
    PyObject * field = PyObject_GetAttrString(_pymsg, "remaining_waypoints");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->remaining_waypoints = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // progress_percentage
    PyObject * field = PyObject_GetAttrString(_pymsg, "progress_percentage");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->progress_percentage = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // total_groups
    PyObject * field = PyObject_GetAttrString(_pymsg, "total_groups");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->total_groups = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // current_group_index
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_group_index");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->current_group_index = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // current_group_waypoints
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_group_waypoints");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->current_group_waypoints = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // completed_groups
    PyObject * field = PyObject_GetAttrString(_pymsg, "completed_groups");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->completed_groups = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // distance_to_current_goal
    PyObject * field = PyObject_GetAttrString(_pymsg, "distance_to_current_goal");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->distance_to_current_goal = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // elapsed_time
    PyObject * field = PyObject_GetAttrString(_pymsg, "elapsed_time");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->elapsed_time = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // error_message
    PyObject * field = PyObject_GetAttrString(_pymsg, "error_message");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->error_message, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__msg__navigate_todoor_status__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of NavigateTodoorStatus */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.msg._navigate_todoor_status");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "NavigateTodoorStatus");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__msg__NavigateTodoorStatus * ros_message = (master_interfaces__msg__NavigateTodoorStatus *)raw_ros_message;
  {  // stamp
    PyObject * field = NULL;
    field = builtin_interfaces__msg__time__convert_to_py(&ros_message->stamp);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "stamp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // status
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->status.data,
      strlen(ros_message->status.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_waypoint_id
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->current_waypoint_id.data,
      strlen(ros_message->current_waypoint_id.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_waypoint_id", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_waypoint_index
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->current_waypoint_index);
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_waypoint_index", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_pose
    PyObject * field = NULL;
    field = geometry_msgs__msg__pose__convert_to_py(&ros_message->current_pose);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_pose", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_speed_mode
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->current_speed_mode.data,
      strlen(ros_message->current_speed_mode.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_speed_mode", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_task
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->current_task.data,
      strlen(ros_message->current_task.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_task", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // total_waypoints
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->total_waypoints);
    {
      int rc = PyObject_SetAttrString(_pymessage, "total_waypoints", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // completed_waypoints
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->completed_waypoints);
    {
      int rc = PyObject_SetAttrString(_pymessage, "completed_waypoints", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // remaining_waypoints
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->remaining_waypoints);
    {
      int rc = PyObject_SetAttrString(_pymessage, "remaining_waypoints", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // progress_percentage
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->progress_percentage);
    {
      int rc = PyObject_SetAttrString(_pymessage, "progress_percentage", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // total_groups
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->total_groups);
    {
      int rc = PyObject_SetAttrString(_pymessage, "total_groups", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_group_index
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->current_group_index);
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_group_index", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_group_waypoints
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->current_group_waypoints);
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_group_waypoints", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // completed_groups
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->completed_groups);
    {
      int rc = PyObject_SetAttrString(_pymessage, "completed_groups", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // distance_to_current_goal
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->distance_to_current_goal);
    {
      int rc = PyObject_SetAttrString(_pymessage, "distance_to_current_goal", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // elapsed_time
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->elapsed_time);
    {
      int rc = PyObject_SetAttrString(_pymessage, "elapsed_time", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // error_message
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->error_message.data,
      strlen(ros_message->error_message.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "error_message", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
