# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/ReportException.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ReportException_Request(type):
    """Metaclass of message 'ReportException_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.ReportException_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__report_exception__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__report_exception__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__report_exception__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__report_exception__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__report_exception__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ReportException_Request(metaclass=Metaclass_ReportException_Request):
    """Message class 'ReportException_Request'."""

    __slots__ = [
        '_request_id',
        '_safe_level',
        '_safe_code',
        '_safe_msg',
        '_safe_action',
    ]

    _fields_and_field_types = {
        'request_id': 'string',
        'safe_level': 'string',
        'safe_code': 'string',
        'safe_msg': 'string',
        'safe_action': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.request_id = kwargs.get('request_id', str())
        self.safe_level = kwargs.get('safe_level', str())
        self.safe_code = kwargs.get('safe_code', str())
        self.safe_msg = kwargs.get('safe_msg', str())
        self.safe_action = kwargs.get('safe_action', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.request_id != other.request_id:
            return False
        if self.safe_level != other.safe_level:
            return False
        if self.safe_code != other.safe_code:
            return False
        if self.safe_msg != other.safe_msg:
            return False
        if self.safe_action != other.safe_action:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def request_id(self):
        """Message field 'request_id'."""
        return self._request_id

    @request_id.setter
    def request_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'request_id' field must be of type 'str'"
        self._request_id = value

    @builtins.property
    def safe_level(self):
        """Message field 'safe_level'."""
        return self._safe_level

    @safe_level.setter
    def safe_level(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'safe_level' field must be of type 'str'"
        self._safe_level = value

    @builtins.property
    def safe_code(self):
        """Message field 'safe_code'."""
        return self._safe_code

    @safe_code.setter
    def safe_code(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'safe_code' field must be of type 'str'"
        self._safe_code = value

    @builtins.property
    def safe_msg(self):
        """Message field 'safe_msg'."""
        return self._safe_msg

    @safe_msg.setter
    def safe_msg(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'safe_msg' field must be of type 'str'"
        self._safe_msg = value

    @builtins.property
    def safe_action(self):
        """Message field 'safe_action'."""
        return self._safe_action

    @safe_action.setter
    def safe_action(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'safe_action' field must be of type 'str'"
        self._safe_action = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_ReportException_Response(type):
    """Metaclass of message 'ReportException_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.ReportException_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__report_exception__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__report_exception__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__report_exception__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__report_exception__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__report_exception__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ReportException_Response(metaclass=Metaclass_ReportException_Response):
    """Message class 'ReportException_Response'."""

    __slots__ = [
        '_success',
        '_error_message',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'error_message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.error_message = kwargs.get('error_message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.error_message != other.error_message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def error_message(self):
        """Message field 'error_message'."""
        return self._error_message

    @error_message.setter
    def error_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'error_message' field must be of type 'str'"
        self._error_message = value


class Metaclass_ReportException(type):
    """Metaclass of service 'ReportException'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.ReportException')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__report_exception

            from master_interfaces.srv import _report_exception
            if _report_exception.Metaclass_ReportException_Request._TYPE_SUPPORT is None:
                _report_exception.Metaclass_ReportException_Request.__import_type_support__()
            if _report_exception.Metaclass_ReportException_Response._TYPE_SUPPORT is None:
                _report_exception.Metaclass_ReportException_Response.__import_type_support__()


class ReportException(metaclass=Metaclass_ReportException):
    from master_interfaces.srv._report_exception import ReportException_Request as Request
    from master_interfaces.srv._report_exception import ReportException_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
