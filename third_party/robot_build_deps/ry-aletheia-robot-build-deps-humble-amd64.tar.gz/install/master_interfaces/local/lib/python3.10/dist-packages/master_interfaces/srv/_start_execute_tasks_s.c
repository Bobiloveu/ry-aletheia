// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from master_interfaces:srv/StartExecuteTasks.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "master_interfaces/srv/detail/start_execute_tasks__struct.h"
#include "master_interfaces/srv/detail/start_execute_tasks__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__srv__start_execute_tasks__request__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[69];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.srv._start_execute_tasks.StartExecuteTasks_Request", full_classname_dest, 68) == 0);
  }
  master_interfaces__srv__StartExecuteTasks_Request * ros_message = _ros_message;
  {  // community
    PyObject * field = PyObject_GetAttrString(_pymsg, "community");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->community, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // building
    PyObject * field = PyObject_GetAttrString(_pymsg, "building");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->building = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // unit
    PyObject * field = PyObject_GetAttrString(_pymsg, "unit");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->unit = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // floor
    PyObject * field = PyObject_GetAttrString(_pymsg, "floor");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->floor = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // door
    PyObject * field = PyObject_GetAttrString(_pymsg, "door");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->door = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // task_uuid
    PyObject * field = PyObject_GetAttrString(_pymsg, "task_uuid");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->task_uuid, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__srv__start_execute_tasks__request__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of StartExecuteTasks_Request */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.srv._start_execute_tasks");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "StartExecuteTasks_Request");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__srv__StartExecuteTasks_Request * ros_message = (master_interfaces__srv__StartExecuteTasks_Request *)raw_ros_message;
  {  // community
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->community.data,
      strlen(ros_message->community.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "community", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // building
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->building);
    {
      int rc = PyObject_SetAttrString(_pymessage, "building", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // unit
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->unit);
    {
      int rc = PyObject_SetAttrString(_pymessage, "unit", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // floor
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->floor);
    {
      int rc = PyObject_SetAttrString(_pymessage, "floor", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // door
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->door);
    {
      int rc = PyObject_SetAttrString(_pymessage, "door", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // task_uuid
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->task_uuid.data,
      strlen(ros_message->task_uuid.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "task_uuid", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/srv/detail/start_execute_tasks__struct.h"
// already included above
// #include "master_interfaces/srv/detail/start_execute_tasks__functions.h"

// already included above
// #include "rosidl_runtime_c/string.h"
// already included above
// #include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__srv__start_execute_tasks__response__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[70];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.srv._start_execute_tasks.StartExecuteTasks_Response", full_classname_dest, 69) == 0);
  }
  master_interfaces__srv__StartExecuteTasks_Response * ros_message = _ros_message;
  {  // success
    PyObject * field = PyObject_GetAttrString(_pymsg, "success");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->success = (Py_True == field);
    Py_DECREF(field);
  }
  {  // message
    PyObject * field = PyObject_GetAttrString(_pymsg, "message");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->message, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__srv__start_execute_tasks__response__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of StartExecuteTasks_Response */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.srv._start_execute_tasks");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "StartExecuteTasks_Response");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__srv__StartExecuteTasks_Response * ros_message = (master_interfaces__srv__StartExecuteTasks_Response *)raw_ros_message;
  {  // success
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->success ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "success", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // message
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->message.data,
      strlen(ros_message->message.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "message", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
