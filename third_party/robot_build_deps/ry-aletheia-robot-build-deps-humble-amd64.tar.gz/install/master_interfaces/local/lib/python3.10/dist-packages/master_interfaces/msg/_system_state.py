# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/SystemState.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SystemState(type):
    """Metaclass of message 'SystemState'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'UNKNOWN': 0,
        'INITIALIZING': 1,
        'IDLE': 2,
        'ACTIVE': 3,
        'NAVIGATING': 4,
        'MAPPING': 5,
        'LOCALIZING': 6,
        'CHARGING': 7,
        'ERROR': 8,
        'EMERGENCY_STOP': 9,
        'MAINTENANCE': 10,
        'SHUTDOWN': 11,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.SystemState')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__system_state
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__system_state
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__system_state
            cls._TYPE_SUPPORT = module.type_support_msg__msg__system_state
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__system_state

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'UNKNOWN': cls.__constants['UNKNOWN'],
            'INITIALIZING': cls.__constants['INITIALIZING'],
            'IDLE': cls.__constants['IDLE'],
            'ACTIVE': cls.__constants['ACTIVE'],
            'NAVIGATING': cls.__constants['NAVIGATING'],
            'MAPPING': cls.__constants['MAPPING'],
            'LOCALIZING': cls.__constants['LOCALIZING'],
            'CHARGING': cls.__constants['CHARGING'],
            'ERROR': cls.__constants['ERROR'],
            'EMERGENCY_STOP': cls.__constants['EMERGENCY_STOP'],
            'MAINTENANCE': cls.__constants['MAINTENANCE'],
            'SHUTDOWN': cls.__constants['SHUTDOWN'],
        }

    @property
    def UNKNOWN(self):
        """Message constant 'UNKNOWN'."""
        return Metaclass_SystemState.__constants['UNKNOWN']

    @property
    def INITIALIZING(self):
        """Message constant 'INITIALIZING'."""
        return Metaclass_SystemState.__constants['INITIALIZING']

    @property
    def IDLE(self):
        """Message constant 'IDLE'."""
        return Metaclass_SystemState.__constants['IDLE']

    @property
    def ACTIVE(self):
        """Message constant 'ACTIVE'."""
        return Metaclass_SystemState.__constants['ACTIVE']

    @property
    def NAVIGATING(self):
        """Message constant 'NAVIGATING'."""
        return Metaclass_SystemState.__constants['NAVIGATING']

    @property
    def MAPPING(self):
        """Message constant 'MAPPING'."""
        return Metaclass_SystemState.__constants['MAPPING']

    @property
    def LOCALIZING(self):
        """Message constant 'LOCALIZING'."""
        return Metaclass_SystemState.__constants['LOCALIZING']

    @property
    def CHARGING(self):
        """Message constant 'CHARGING'."""
        return Metaclass_SystemState.__constants['CHARGING']

    @property
    def ERROR(self):
        """Message constant 'ERROR'."""
        return Metaclass_SystemState.__constants['ERROR']

    @property
    def EMERGENCY_STOP(self):
        """Message constant 'EMERGENCY_STOP'."""
        return Metaclass_SystemState.__constants['EMERGENCY_STOP']

    @property
    def MAINTENANCE(self):
        """Message constant 'MAINTENANCE'."""
        return Metaclass_SystemState.__constants['MAINTENANCE']

    @property
    def SHUTDOWN(self):
        """Message constant 'SHUTDOWN'."""
        return Metaclass_SystemState.__constants['SHUTDOWN']


class SystemState(metaclass=Metaclass_SystemState):
    """
    Message class 'SystemState'.

    Constants:
      UNKNOWN
      INITIALIZING
      IDLE
      ACTIVE
      NAVIGATING
      MAPPING
      LOCALIZING
      CHARGING
      ERROR
      EMERGENCY_STOP
      MAINTENANCE
      SHUTDOWN
    """

    __slots__ = [
        '_current_state',
        '_previous_state',
        '_state_description',
        '_state_entered_time',
        '_state_duration',
        '_state_data',
    ]

    _fields_and_field_types = {
        'current_state': 'uint8',
        'previous_state': 'uint8',
        'state_description': 'string',
        'state_entered_time': 'builtin_interfaces/Time',
        'state_duration': 'double',
        'state_data': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.current_state = kwargs.get('current_state', int())
        self.previous_state = kwargs.get('previous_state', int())
        self.state_description = kwargs.get('state_description', str())
        from builtin_interfaces.msg import Time
        self.state_entered_time = kwargs.get('state_entered_time', Time())
        self.state_duration = kwargs.get('state_duration', float())
        self.state_data = kwargs.get('state_data', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.current_state != other.current_state:
            return False
        if self.previous_state != other.previous_state:
            return False
        if self.state_description != other.state_description:
            return False
        if self.state_entered_time != other.state_entered_time:
            return False
        if self.state_duration != other.state_duration:
            return False
        if self.state_data != other.state_data:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def current_state(self):
        """Message field 'current_state'."""
        return self._current_state

    @current_state.setter
    def current_state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'current_state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'current_state' field must be an unsigned integer in [0, 255]"
        self._current_state = value

    @builtins.property
    def previous_state(self):
        """Message field 'previous_state'."""
        return self._previous_state

    @previous_state.setter
    def previous_state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'previous_state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'previous_state' field must be an unsigned integer in [0, 255]"
        self._previous_state = value

    @builtins.property
    def state_description(self):
        """Message field 'state_description'."""
        return self._state_description

    @state_description.setter
    def state_description(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'state_description' field must be of type 'str'"
        self._state_description = value

    @builtins.property
    def state_entered_time(self):
        """Message field 'state_entered_time'."""
        return self._state_entered_time

    @state_entered_time.setter
    def state_entered_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'state_entered_time' field must be a sub message of type 'Time'"
        self._state_entered_time = value

    @builtins.property
    def state_duration(self):
        """Message field 'state_duration'."""
        return self._state_duration

    @state_duration.setter
    def state_duration(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'state_duration' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'state_duration' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._state_duration = value

    @builtins.property
    def state_data(self):
        """Message field 'state_data'."""
        return self._state_data

    @state_data.setter
    def state_data(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'state_data' field must be of type 'str'"
        self._state_data = value
