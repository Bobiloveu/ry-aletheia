# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:action/WebVoicePlayer.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_WebVoicePlayer_Goal(type):
    """Metaclass of message 'WebVoicePlayer_Goal'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_Goal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__goal
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__goal
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__goal
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__goal
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__goal

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class WebVoicePlayer_Goal(metaclass=Metaclass_WebVoicePlayer_Goal):
    """Message class 'WebVoicePlayer_Goal'."""

    __slots__ = [
        '_text',
        '_model',
        '_voice',
        '_volume',
        '_rate',
        '_pitch',
        '_sample_rate',
        '_format',
        '_loop_count',
        '_loop_interval',
        '_priority',
    ]

    _fields_and_field_types = {
        'text': 'string',
        'model': 'string',
        'voice': 'string',
        'volume': 'uint8',
        'rate': 'float',
        'pitch': 'float',
        'sample_rate': 'uint32',
        'format': 'string',
        'loop_count': 'uint32',
        'loop_interval': 'float',
        'priority': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.text = kwargs.get('text', str())
        self.model = kwargs.get('model', str())
        self.voice = kwargs.get('voice', str())
        self.volume = kwargs.get('volume', int())
        self.rate = kwargs.get('rate', float())
        self.pitch = kwargs.get('pitch', float())
        self.sample_rate = kwargs.get('sample_rate', int())
        self.format = kwargs.get('format', str())
        self.loop_count = kwargs.get('loop_count', int())
        self.loop_interval = kwargs.get('loop_interval', float())
        self.priority = kwargs.get('priority', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.text != other.text:
            return False
        if self.model != other.model:
            return False
        if self.voice != other.voice:
            return False
        if self.volume != other.volume:
            return False
        if self.rate != other.rate:
            return False
        if self.pitch != other.pitch:
            return False
        if self.sample_rate != other.sample_rate:
            return False
        if self.format != other.format:
            return False
        if self.loop_count != other.loop_count:
            return False
        if self.loop_interval != other.loop_interval:
            return False
        if self.priority != other.priority:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def text(self):
        """Message field 'text'."""
        return self._text

    @text.setter
    def text(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'text' field must be of type 'str'"
        self._text = value

    @builtins.property
    def model(self):
        """Message field 'model'."""
        return self._model

    @model.setter
    def model(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'model' field must be of type 'str'"
        self._model = value

    @builtins.property
    def voice(self):
        """Message field 'voice'."""
        return self._voice

    @voice.setter
    def voice(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'voice' field must be of type 'str'"
        self._voice = value

    @builtins.property
    def volume(self):
        """Message field 'volume'."""
        return self._volume

    @volume.setter
    def volume(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'volume' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'volume' field must be an unsigned integer in [0, 255]"
        self._volume = value

    @builtins.property
    def rate(self):
        """Message field 'rate'."""
        return self._rate

    @rate.setter
    def rate(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'rate' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'rate' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._rate = value

    @builtins.property
    def pitch(self):
        """Message field 'pitch'."""
        return self._pitch

    @pitch.setter
    def pitch(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'pitch' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'pitch' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._pitch = value

    @builtins.property
    def sample_rate(self):
        """Message field 'sample_rate'."""
        return self._sample_rate

    @sample_rate.setter
    def sample_rate(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'sample_rate' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'sample_rate' field must be an unsigned integer in [0, 4294967295]"
        self._sample_rate = value

    @builtins.property  # noqa: A003
    def format(self):  # noqa: A003
        """Message field 'format'."""
        return self._format

    @format.setter  # noqa: A003
    def format(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'format' field must be of type 'str'"
        self._format = value

    @builtins.property
    def loop_count(self):
        """Message field 'loop_count'."""
        return self._loop_count

    @loop_count.setter
    def loop_count(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'loop_count' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'loop_count' field must be an unsigned integer in [0, 4294967295]"
        self._loop_count = value

    @builtins.property
    def loop_interval(self):
        """Message field 'loop_interval'."""
        return self._loop_interval

    @loop_interval.setter
    def loop_interval(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'loop_interval' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'loop_interval' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._loop_interval = value

    @builtins.property
    def priority(self):
        """Message field 'priority'."""
        return self._priority

    @priority.setter
    def priority(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'priority' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'priority' field must be an unsigned integer in [0, 255]"
        self._priority = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_Result(type):
    """Metaclass of message 'WebVoicePlayer_Result'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'ERROR_NONE': 0,
        'ERROR_NETWORK': 1,
        'ERROR_INVALID_PARAM': 2,
        'ERROR_AUTH_FAILED': 3,
        'ERROR_CANCELED': 4,
        'ERROR_PLAYBACK_FAILED': 5,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_Result')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__result
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__result
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__result
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__result
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__result

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'ERROR_NONE': cls.__constants['ERROR_NONE'],
            'ERROR_NETWORK': cls.__constants['ERROR_NETWORK'],
            'ERROR_INVALID_PARAM': cls.__constants['ERROR_INVALID_PARAM'],
            'ERROR_AUTH_FAILED': cls.__constants['ERROR_AUTH_FAILED'],
            'ERROR_CANCELED': cls.__constants['ERROR_CANCELED'],
            'ERROR_PLAYBACK_FAILED': cls.__constants['ERROR_PLAYBACK_FAILED'],
        }

    @property
    def ERROR_NONE(self):
        """Message constant 'ERROR_NONE'."""
        return Metaclass_WebVoicePlayer_Result.__constants['ERROR_NONE']

    @property
    def ERROR_NETWORK(self):
        """Message constant 'ERROR_NETWORK'."""
        return Metaclass_WebVoicePlayer_Result.__constants['ERROR_NETWORK']

    @property
    def ERROR_INVALID_PARAM(self):
        """Message constant 'ERROR_INVALID_PARAM'."""
        return Metaclass_WebVoicePlayer_Result.__constants['ERROR_INVALID_PARAM']

    @property
    def ERROR_AUTH_FAILED(self):
        """Message constant 'ERROR_AUTH_FAILED'."""
        return Metaclass_WebVoicePlayer_Result.__constants['ERROR_AUTH_FAILED']

    @property
    def ERROR_CANCELED(self):
        """Message constant 'ERROR_CANCELED'."""
        return Metaclass_WebVoicePlayer_Result.__constants['ERROR_CANCELED']

    @property
    def ERROR_PLAYBACK_FAILED(self):
        """Message constant 'ERROR_PLAYBACK_FAILED'."""
        return Metaclass_WebVoicePlayer_Result.__constants['ERROR_PLAYBACK_FAILED']


class WebVoicePlayer_Result(metaclass=Metaclass_WebVoicePlayer_Result):
    """
    Message class 'WebVoicePlayer_Result'.

    Constants:
      ERROR_NONE
      ERROR_NETWORK
      ERROR_INVALID_PARAM
      ERROR_AUTH_FAILED
      ERROR_CANCELED
      ERROR_PLAYBACK_FAILED
    """

    __slots__ = [
        '_success',
        '_message',
        '_error_code',
        '_characters_count',
        '_audio_file_path',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'error_code': 'uint8',
        'characters_count': 'uint32',
        'audio_file_path': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.error_code = kwargs.get('error_code', int())
        self.characters_count = kwargs.get('characters_count', int())
        self.audio_file_path = kwargs.get('audio_file_path', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.error_code != other.error_code:
            return False
        if self.characters_count != other.characters_count:
            return False
        if self.audio_file_path != other.audio_file_path:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def error_code(self):
        """Message field 'error_code'."""
        return self._error_code

    @error_code.setter
    def error_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'error_code' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'error_code' field must be an unsigned integer in [0, 255]"
        self._error_code = value

    @builtins.property
    def characters_count(self):
        """Message field 'characters_count'."""
        return self._characters_count

    @characters_count.setter
    def characters_count(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'characters_count' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'characters_count' field must be an unsigned integer in [0, 4294967295]"
        self._characters_count = value

    @builtins.property
    def audio_file_path(self):
        """Message field 'audio_file_path'."""
        return self._audio_file_path

    @audio_file_path.setter
    def audio_file_path(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'audio_file_path' field must be of type 'str'"
        self._audio_file_path = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_Feedback(type):
    """Metaclass of message 'WebVoicePlayer_Feedback'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'STATUS_INITIALIZING': 0,
        'STATUS_CONNECTING': 1,
        'STATUS_SYNTHESIZING': 2,
        'STATUS_PLAYING': 3,
        'STATUS_COMPLETED': 4,
        'STATUS_CANCELED': 5,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_Feedback')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__feedback
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__feedback
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__feedback
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__feedback
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__feedback

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'STATUS_INITIALIZING': cls.__constants['STATUS_INITIALIZING'],
            'STATUS_CONNECTING': cls.__constants['STATUS_CONNECTING'],
            'STATUS_SYNTHESIZING': cls.__constants['STATUS_SYNTHESIZING'],
            'STATUS_PLAYING': cls.__constants['STATUS_PLAYING'],
            'STATUS_COMPLETED': cls.__constants['STATUS_COMPLETED'],
            'STATUS_CANCELED': cls.__constants['STATUS_CANCELED'],
        }

    @property
    def STATUS_INITIALIZING(self):
        """Message constant 'STATUS_INITIALIZING'."""
        return Metaclass_WebVoicePlayer_Feedback.__constants['STATUS_INITIALIZING']

    @property
    def STATUS_CONNECTING(self):
        """Message constant 'STATUS_CONNECTING'."""
        return Metaclass_WebVoicePlayer_Feedback.__constants['STATUS_CONNECTING']

    @property
    def STATUS_SYNTHESIZING(self):
        """Message constant 'STATUS_SYNTHESIZING'."""
        return Metaclass_WebVoicePlayer_Feedback.__constants['STATUS_SYNTHESIZING']

    @property
    def STATUS_PLAYING(self):
        """Message constant 'STATUS_PLAYING'."""
        return Metaclass_WebVoicePlayer_Feedback.__constants['STATUS_PLAYING']

    @property
    def STATUS_COMPLETED(self):
        """Message constant 'STATUS_COMPLETED'."""
        return Metaclass_WebVoicePlayer_Feedback.__constants['STATUS_COMPLETED']

    @property
    def STATUS_CANCELED(self):
        """Message constant 'STATUS_CANCELED'."""
        return Metaclass_WebVoicePlayer_Feedback.__constants['STATUS_CANCELED']


class WebVoicePlayer_Feedback(metaclass=Metaclass_WebVoicePlayer_Feedback):
    """
    Message class 'WebVoicePlayer_Feedback'.

    Constants:
      STATUS_INITIALIZING
      STATUS_CONNECTING
      STATUS_SYNTHESIZING
      STATUS_PLAYING
      STATUS_COMPLETED
      STATUS_CANCELED
    """

    __slots__ = [
        '_status',
        '_status_message',
        '_synthesis_progress',
        '_playback_progress',
        '_audio_data_size',
    ]

    _fields_and_field_types = {
        'status': 'uint8',
        'status_message': 'string',
        'synthesis_progress': 'uint8',
        'playback_progress': 'uint8',
        'audio_data_size': 'uint32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        self.status_message = kwargs.get('status_message', str())
        self.synthesis_progress = kwargs.get('synthesis_progress', int())
        self.playback_progress = kwargs.get('playback_progress', int())
        self.audio_data_size = kwargs.get('audio_data_size', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.status_message != other.status_message:
            return False
        if self.synthesis_progress != other.synthesis_progress:
            return False
        if self.playback_progress != other.playback_progress:
            return False
        if self.audio_data_size != other.audio_data_size:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'status' field must be an unsigned integer in [0, 255]"
        self._status = value

    @builtins.property
    def status_message(self):
        """Message field 'status_message'."""
        return self._status_message

    @status_message.setter
    def status_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'status_message' field must be of type 'str'"
        self._status_message = value

    @builtins.property
    def synthesis_progress(self):
        """Message field 'synthesis_progress'."""
        return self._synthesis_progress

    @synthesis_progress.setter
    def synthesis_progress(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'synthesis_progress' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'synthesis_progress' field must be an unsigned integer in [0, 255]"
        self._synthesis_progress = value

    @builtins.property
    def playback_progress(self):
        """Message field 'playback_progress'."""
        return self._playback_progress

    @playback_progress.setter
    def playback_progress(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'playback_progress' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'playback_progress' field must be an unsigned integer in [0, 255]"
        self._playback_progress = value

    @builtins.property
    def audio_data_size(self):
        """Message field 'audio_data_size'."""
        return self._audio_data_size

    @audio_data_size.setter
    def audio_data_size(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'audio_data_size' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'audio_data_size' field must be an unsigned integer in [0, 4294967295]"
        self._audio_data_size = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_SendGoal_Request(type):
    """Metaclass of message 'WebVoicePlayer_SendGoal_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_SendGoal_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__send_goal__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__send_goal__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__send_goal__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__send_goal__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__send_goal__request

            from master_interfaces.action import WebVoicePlayer
            if WebVoicePlayer.Goal.__class__._TYPE_SUPPORT is None:
                WebVoicePlayer.Goal.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class WebVoicePlayer_SendGoal_Request(metaclass=Metaclass_WebVoicePlayer_SendGoal_Request):
    """Message class 'WebVoicePlayer_SendGoal_Request'."""

    __slots__ = [
        '_goal_id',
        '_goal',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'goal': 'master_interfaces/WebVoicePlayer_Goal',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'WebVoicePlayer_Goal'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from master_interfaces.action._web_voice_player import WebVoicePlayer_Goal
        self.goal = kwargs.get('goal', WebVoicePlayer_Goal())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.goal != other.goal:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def goal(self):
        """Message field 'goal'."""
        return self._goal

    @goal.setter
    def goal(self, value):
        if __debug__:
            from master_interfaces.action._web_voice_player import WebVoicePlayer_Goal
            assert \
                isinstance(value, WebVoicePlayer_Goal), \
                "The 'goal' field must be a sub message of type 'WebVoicePlayer_Goal'"
        self._goal = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_SendGoal_Response(type):
    """Metaclass of message 'WebVoicePlayer_SendGoal_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_SendGoal_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__send_goal__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__send_goal__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__send_goal__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__send_goal__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__send_goal__response

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class WebVoicePlayer_SendGoal_Response(metaclass=Metaclass_WebVoicePlayer_SendGoal_Response):
    """Message class 'WebVoicePlayer_SendGoal_Response'."""

    __slots__ = [
        '_accepted',
        '_stamp',
    ]

    _fields_and_field_types = {
        'accepted': 'boolean',
        'stamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.accepted = kwargs.get('accepted', bool())
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.accepted != other.accepted:
            return False
        if self.stamp != other.stamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def accepted(self):
        """Message field 'accepted'."""
        return self._accepted

    @accepted.setter
    def accepted(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'accepted' field must be of type 'bool'"
        self._accepted = value

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value


class Metaclass_WebVoicePlayer_SendGoal(type):
    """Metaclass of service 'WebVoicePlayer_SendGoal'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_SendGoal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__web_voice_player__send_goal

            from master_interfaces.action import _web_voice_player
            if _web_voice_player.Metaclass_WebVoicePlayer_SendGoal_Request._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_SendGoal_Request.__import_type_support__()
            if _web_voice_player.Metaclass_WebVoicePlayer_SendGoal_Response._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_SendGoal_Response.__import_type_support__()


class WebVoicePlayer_SendGoal(metaclass=Metaclass_WebVoicePlayer_SendGoal):
    from master_interfaces.action._web_voice_player import WebVoicePlayer_SendGoal_Request as Request
    from master_interfaces.action._web_voice_player import WebVoicePlayer_SendGoal_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_GetResult_Request(type):
    """Metaclass of message 'WebVoicePlayer_GetResult_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_GetResult_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__get_result__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__get_result__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__get_result__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__get_result__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__get_result__request

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class WebVoicePlayer_GetResult_Request(metaclass=Metaclass_WebVoicePlayer_GetResult_Request):
    """Message class 'WebVoicePlayer_GetResult_Request'."""

    __slots__ = [
        '_goal_id',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_GetResult_Response(type):
    """Metaclass of message 'WebVoicePlayer_GetResult_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_GetResult_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__get_result__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__get_result__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__get_result__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__get_result__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__get_result__response

            from master_interfaces.action import WebVoicePlayer
            if WebVoicePlayer.Result.__class__._TYPE_SUPPORT is None:
                WebVoicePlayer.Result.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class WebVoicePlayer_GetResult_Response(metaclass=Metaclass_WebVoicePlayer_GetResult_Response):
    """Message class 'WebVoicePlayer_GetResult_Response'."""

    __slots__ = [
        '_status',
        '_result',
    ]

    _fields_and_field_types = {
        'status': 'int8',
        'result': 'master_interfaces/WebVoicePlayer_Result',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'WebVoicePlayer_Result'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        from master_interfaces.action._web_voice_player import WebVoicePlayer_Result
        self.result = kwargs.get('result', WebVoicePlayer_Result())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.result != other.result:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'status' field must be an integer in [-128, 127]"
        self._status = value

    @builtins.property
    def result(self):
        """Message field 'result'."""
        return self._result

    @result.setter
    def result(self, value):
        if __debug__:
            from master_interfaces.action._web_voice_player import WebVoicePlayer_Result
            assert \
                isinstance(value, WebVoicePlayer_Result), \
                "The 'result' field must be a sub message of type 'WebVoicePlayer_Result'"
        self._result = value


class Metaclass_WebVoicePlayer_GetResult(type):
    """Metaclass of service 'WebVoicePlayer_GetResult'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_GetResult')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__web_voice_player__get_result

            from master_interfaces.action import _web_voice_player
            if _web_voice_player.Metaclass_WebVoicePlayer_GetResult_Request._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_GetResult_Request.__import_type_support__()
            if _web_voice_player.Metaclass_WebVoicePlayer_GetResult_Response._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_GetResult_Response.__import_type_support__()


class WebVoicePlayer_GetResult(metaclass=Metaclass_WebVoicePlayer_GetResult):
    from master_interfaces.action._web_voice_player import WebVoicePlayer_GetResult_Request as Request
    from master_interfaces.action._web_voice_player import WebVoicePlayer_GetResult_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_WebVoicePlayer_FeedbackMessage(type):
    """Metaclass of message 'WebVoicePlayer_FeedbackMessage'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer_FeedbackMessage')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__web_voice_player__feedback_message
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__web_voice_player__feedback_message
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__web_voice_player__feedback_message
            cls._TYPE_SUPPORT = module.type_support_msg__action__web_voice_player__feedback_message
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__web_voice_player__feedback_message

            from master_interfaces.action import WebVoicePlayer
            if WebVoicePlayer.Feedback.__class__._TYPE_SUPPORT is None:
                WebVoicePlayer.Feedback.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class WebVoicePlayer_FeedbackMessage(metaclass=Metaclass_WebVoicePlayer_FeedbackMessage):
    """Message class 'WebVoicePlayer_FeedbackMessage'."""

    __slots__ = [
        '_goal_id',
        '_feedback',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'feedback': 'master_interfaces/WebVoicePlayer_Feedback',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'WebVoicePlayer_Feedback'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from master_interfaces.action._web_voice_player import WebVoicePlayer_Feedback
        self.feedback = kwargs.get('feedback', WebVoicePlayer_Feedback())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.feedback != other.feedback:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def feedback(self):
        """Message field 'feedback'."""
        return self._feedback

    @feedback.setter
    def feedback(self, value):
        if __debug__:
            from master_interfaces.action._web_voice_player import WebVoicePlayer_Feedback
            assert \
                isinstance(value, WebVoicePlayer_Feedback), \
                "The 'feedback' field must be a sub message of type 'WebVoicePlayer_Feedback'"
        self._feedback = value


class Metaclass_WebVoicePlayer(type):
    """Metaclass of action 'WebVoicePlayer'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.WebVoicePlayer')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_action__action__web_voice_player

            from action_msgs.msg import _goal_status_array
            if _goal_status_array.Metaclass_GoalStatusArray._TYPE_SUPPORT is None:
                _goal_status_array.Metaclass_GoalStatusArray.__import_type_support__()
            from action_msgs.srv import _cancel_goal
            if _cancel_goal.Metaclass_CancelGoal._TYPE_SUPPORT is None:
                _cancel_goal.Metaclass_CancelGoal.__import_type_support__()

            from master_interfaces.action import _web_voice_player
            if _web_voice_player.Metaclass_WebVoicePlayer_SendGoal._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_SendGoal.__import_type_support__()
            if _web_voice_player.Metaclass_WebVoicePlayer_GetResult._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_GetResult.__import_type_support__()
            if _web_voice_player.Metaclass_WebVoicePlayer_FeedbackMessage._TYPE_SUPPORT is None:
                _web_voice_player.Metaclass_WebVoicePlayer_FeedbackMessage.__import_type_support__()


class WebVoicePlayer(metaclass=Metaclass_WebVoicePlayer):

    # The goal message defined in the action definition.
    from master_interfaces.action._web_voice_player import WebVoicePlayer_Goal as Goal
    # The result message defined in the action definition.
    from master_interfaces.action._web_voice_player import WebVoicePlayer_Result as Result
    # The feedback message defined in the action definition.
    from master_interfaces.action._web_voice_player import WebVoicePlayer_Feedback as Feedback

    class Impl:

        # The send_goal service using a wrapped version of the goal message as a request.
        from master_interfaces.action._web_voice_player import WebVoicePlayer_SendGoal as SendGoalService
        # The get_result service using a wrapped version of the result message as a response.
        from master_interfaces.action._web_voice_player import WebVoicePlayer_GetResult as GetResultService
        # The feedback message with generic fields which wraps the feedback message.
        from master_interfaces.action._web_voice_player import WebVoicePlayer_FeedbackMessage as FeedbackMessage

        # The generic service to cancel a goal.
        from action_msgs.srv._cancel_goal import CancelGoal as CancelGoalService
        # The generic message for get the status of a goal.
        from action_msgs.msg._goal_status_array import GoalStatusArray as GoalStatusMessage

    def __init__(self):
        raise NotImplementedError('Action classes can not be instantiated')
