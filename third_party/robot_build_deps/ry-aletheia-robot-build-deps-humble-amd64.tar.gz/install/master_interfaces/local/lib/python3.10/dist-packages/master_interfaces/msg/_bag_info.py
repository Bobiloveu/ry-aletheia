# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/BagInfo.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_BagInfo(type):
    """Metaclass of message 'BagInfo'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.BagInfo')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__bag_info
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__bag_info
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__bag_info
            cls._TYPE_SUPPORT = module.type_support_msg__msg__bag_info
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__bag_info

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class BagInfo(metaclass=Metaclass_BagInfo):
    """Message class 'BagInfo'."""

    __slots__ = [
        '_name',
        '_path',
        '_size_bytes',
        '_creation_time',
        '_duration_ns',
        '_message_count',
    ]

    _fields_and_field_types = {
        'name': 'string',
        'path': 'string',
        'size_bytes': 'int64',
        'creation_time': 'int64',
        'duration_ns': 'int64',
        'message_count': 'int32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.name = kwargs.get('name', str())
        self.path = kwargs.get('path', str())
        self.size_bytes = kwargs.get('size_bytes', int())
        self.creation_time = kwargs.get('creation_time', int())
        self.duration_ns = kwargs.get('duration_ns', int())
        self.message_count = kwargs.get('message_count', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.name != other.name:
            return False
        if self.path != other.path:
            return False
        if self.size_bytes != other.size_bytes:
            return False
        if self.creation_time != other.creation_time:
            return False
        if self.duration_ns != other.duration_ns:
            return False
        if self.message_count != other.message_count:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def name(self):
        """Message field 'name'."""
        return self._name

    @name.setter
    def name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'name' field must be of type 'str'"
        self._name = value

    @builtins.property
    def path(self):
        """Message field 'path'."""
        return self._path

    @path.setter
    def path(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'path' field must be of type 'str'"
        self._path = value

    @builtins.property
    def size_bytes(self):
        """Message field 'size_bytes'."""
        return self._size_bytes

    @size_bytes.setter
    def size_bytes(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'size_bytes' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'size_bytes' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._size_bytes = value

    @builtins.property
    def creation_time(self):
        """Message field 'creation_time'."""
        return self._creation_time

    @creation_time.setter
    def creation_time(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'creation_time' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'creation_time' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._creation_time = value

    @builtins.property
    def duration_ns(self):
        """Message field 'duration_ns'."""
        return self._duration_ns

    @duration_ns.setter
    def duration_ns(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'duration_ns' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'duration_ns' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._duration_ns = value

    @builtins.property
    def message_count(self):
        """Message field 'message_count'."""
        return self._message_count

    @message_count.setter
    def message_count(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'message_count' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'message_count' field must be an integer in [-2147483648, 2147483647]"
        self._message_count = value
