// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from master_interfaces:msg/BagInfo.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "master_interfaces/msg/detail/bag_info__struct.h"
#include "master_interfaces/msg/detail/bag_info__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__msg__bag_info__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[40];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.msg._bag_info.BagInfo", full_classname_dest, 39) == 0);
  }
  master_interfaces__msg__BagInfo * ros_message = _ros_message;
  {  // name
    PyObject * field = PyObject_GetAttrString(_pymsg, "name");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->name, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // path
    PyObject * field = PyObject_GetAttrString(_pymsg, "path");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->path, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // size_bytes
    PyObject * field = PyObject_GetAttrString(_pymsg, "size_bytes");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->size_bytes = PyLong_AsLongLong(field);
    Py_DECREF(field);
  }
  {  // creation_time
    PyObject * field = PyObject_GetAttrString(_pymsg, "creation_time");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->creation_time = PyLong_AsLongLong(field);
    Py_DECREF(field);
  }
  {  // duration_ns
    PyObject * field = PyObject_GetAttrString(_pymsg, "duration_ns");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->duration_ns = PyLong_AsLongLong(field);
    Py_DECREF(field);
  }
  {  // message_count
    PyObject * field = PyObject_GetAttrString(_pymsg, "message_count");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->message_count = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__msg__bag_info__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of BagInfo */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.msg._bag_info");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "BagInfo");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__msg__BagInfo * ros_message = (master_interfaces__msg__BagInfo *)raw_ros_message;
  {  // name
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->name.data,
      strlen(ros_message->name.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "name", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // path
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->path.data,
      strlen(ros_message->path.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "path", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // size_bytes
    PyObject * field = NULL;
    field = PyLong_FromLongLong(ros_message->size_bytes);
    {
      int rc = PyObject_SetAttrString(_pymessage, "size_bytes", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // creation_time
    PyObject * field = NULL;
    field = PyLong_FromLongLong(ros_message->creation_time);
    {
      int rc = PyObject_SetAttrString(_pymessage, "creation_time", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // duration_ns
    PyObject * field = NULL;
    field = PyLong_FromLongLong(ros_message->duration_ns);
    {
      int rc = PyObject_SetAttrString(_pymessage, "duration_ns", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // message_count
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->message_count);
    {
      int rc = PyObject_SetAttrString(_pymessage, "message_count", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
