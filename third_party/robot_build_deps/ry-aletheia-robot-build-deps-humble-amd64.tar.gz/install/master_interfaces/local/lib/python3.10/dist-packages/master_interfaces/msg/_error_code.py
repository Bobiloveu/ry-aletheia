# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/ErrorCode.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ErrorCode(type):
    """Metaclass of message 'ErrorCode'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'SUCCESS': 0,
        'UNKNOWN_ERROR': 1000,
        'NETWORK_ERROR': 1001,
        'INVALID_PARAMETER': 1002,
        'SERVICE_UNAVAILABLE': 1003,
        'TIMEOUT': 1004,
        'RESOURCE_NOT_FOUND': 1005,
        'PERMISSION_DENIED': 1006,
        'HARDWARE_ERROR': 2000,
        'NAVIGATION_ERROR': 3000,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.ErrorCode')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__error_code
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__error_code
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__error_code
            cls._TYPE_SUPPORT = module.type_support_msg__msg__error_code
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__error_code

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'SUCCESS': cls.__constants['SUCCESS'],
            'UNKNOWN_ERROR': cls.__constants['UNKNOWN_ERROR'],
            'NETWORK_ERROR': cls.__constants['NETWORK_ERROR'],
            'INVALID_PARAMETER': cls.__constants['INVALID_PARAMETER'],
            'SERVICE_UNAVAILABLE': cls.__constants['SERVICE_UNAVAILABLE'],
            'TIMEOUT': cls.__constants['TIMEOUT'],
            'RESOURCE_NOT_FOUND': cls.__constants['RESOURCE_NOT_FOUND'],
            'PERMISSION_DENIED': cls.__constants['PERMISSION_DENIED'],
            'HARDWARE_ERROR': cls.__constants['HARDWARE_ERROR'],
            'NAVIGATION_ERROR': cls.__constants['NAVIGATION_ERROR'],
        }

    @property
    def SUCCESS(self):
        """Message constant 'SUCCESS'."""
        return Metaclass_ErrorCode.__constants['SUCCESS']

    @property
    def UNKNOWN_ERROR(self):
        """Message constant 'UNKNOWN_ERROR'."""
        return Metaclass_ErrorCode.__constants['UNKNOWN_ERROR']

    @property
    def NETWORK_ERROR(self):
        """Message constant 'NETWORK_ERROR'."""
        return Metaclass_ErrorCode.__constants['NETWORK_ERROR']

    @property
    def INVALID_PARAMETER(self):
        """Message constant 'INVALID_PARAMETER'."""
        return Metaclass_ErrorCode.__constants['INVALID_PARAMETER']

    @property
    def SERVICE_UNAVAILABLE(self):
        """Message constant 'SERVICE_UNAVAILABLE'."""
        return Metaclass_ErrorCode.__constants['SERVICE_UNAVAILABLE']

    @property
    def TIMEOUT(self):
        """Message constant 'TIMEOUT'."""
        return Metaclass_ErrorCode.__constants['TIMEOUT']

    @property
    def RESOURCE_NOT_FOUND(self):
        """Message constant 'RESOURCE_NOT_FOUND'."""
        return Metaclass_ErrorCode.__constants['RESOURCE_NOT_FOUND']

    @property
    def PERMISSION_DENIED(self):
        """Message constant 'PERMISSION_DENIED'."""
        return Metaclass_ErrorCode.__constants['PERMISSION_DENIED']

    @property
    def HARDWARE_ERROR(self):
        """Message constant 'HARDWARE_ERROR'."""
        return Metaclass_ErrorCode.__constants['HARDWARE_ERROR']

    @property
    def NAVIGATION_ERROR(self):
        """Message constant 'NAVIGATION_ERROR'."""
        return Metaclass_ErrorCode.__constants['NAVIGATION_ERROR']


class ErrorCode(metaclass=Metaclass_ErrorCode):
    """
    Message class 'ErrorCode'.

    Constants:
      SUCCESS
      UNKNOWN_ERROR
      NETWORK_ERROR
      INVALID_PARAMETER
      SERVICE_UNAVAILABLE
      TIMEOUT
      RESOURCE_NOT_FOUND
      PERMISSION_DENIED
      HARDWARE_ERROR
      NAVIGATION_ERROR
    """

    __slots__ = [
        '_code',
        '_description',
    ]

    _fields_and_field_types = {
        'code': 'int32',
        'description': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.code = kwargs.get('code', int())
        self.description = kwargs.get('description', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.code != other.code:
            return False
        if self.description != other.description:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def code(self):
        """Message field 'code'."""
        return self._code

    @code.setter
    def code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'code' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'code' field must be an integer in [-2147483648, 2147483647]"
        self._code = value

    @builtins.property
    def description(self):
        """Message field 'description'."""
        return self._description

    @description.setter
    def description(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'description' field must be of type 'str'"
        self._description = value
