# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/GetCargoStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_GetCargoStatus_Request(type):
    """Metaclass of message 'GetCargoStatus_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'CARGO_UPPER': 1,
        'CARGO_LOWER': 2,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetCargoStatus_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__get_cargo_status__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__get_cargo_status__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__get_cargo_status__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__get_cargo_status__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__get_cargo_status__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'CARGO_UPPER': cls.__constants['CARGO_UPPER'],
            'CARGO_LOWER': cls.__constants['CARGO_LOWER'],
        }

    @property
    def CARGO_UPPER(self):
        """Message constant 'CARGO_UPPER'."""
        return Metaclass_GetCargoStatus_Request.__constants['CARGO_UPPER']

    @property
    def CARGO_LOWER(self):
        """Message constant 'CARGO_LOWER'."""
        return Metaclass_GetCargoStatus_Request.__constants['CARGO_LOWER']


class GetCargoStatus_Request(metaclass=Metaclass_GetCargoStatus_Request):
    """
    Message class 'GetCargoStatus_Request'.

    Constants:
      CARGO_UPPER
      CARGO_LOWER
    """

    __slots__ = [
        '_cargo_id',
    ]

    _fields_and_field_types = {
        'cargo_id': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.cargo_id = kwargs.get('cargo_id', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.cargo_id != other.cargo_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def cargo_id(self):
        """Message field 'cargo_id'."""
        return self._cargo_id

    @cargo_id.setter
    def cargo_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cargo_id' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'cargo_id' field must be an unsigned integer in [0, 255]"
        self._cargo_id = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_GetCargoStatus_Response(type):
    """Metaclass of message 'GetCargoStatus_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'STATE_UNKNOWN': 0,
        'STATE_RESET': 1,
        'STATE_UPPER_MANUAL_OPEN': 2,
        'STATE_UPPER_MANUAL_CLOSE': 3,
        'STATE_UPPER_AUTO_UNLOAD': 4,
        'STATE_LOWER_UNLOCK': 5,
        'STATE_LOWER_LOCK': 6,
        'STATE_LOWER_OPEN': 7,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetCargoStatus_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__get_cargo_status__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__get_cargo_status__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__get_cargo_status__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__get_cargo_status__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__get_cargo_status__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'STATE_UNKNOWN': cls.__constants['STATE_UNKNOWN'],
            'STATE_RESET': cls.__constants['STATE_RESET'],
            'STATE_UPPER_MANUAL_OPEN': cls.__constants['STATE_UPPER_MANUAL_OPEN'],
            'STATE_UPPER_MANUAL_CLOSE': cls.__constants['STATE_UPPER_MANUAL_CLOSE'],
            'STATE_UPPER_AUTO_UNLOAD': cls.__constants['STATE_UPPER_AUTO_UNLOAD'],
            'STATE_LOWER_UNLOCK': cls.__constants['STATE_LOWER_UNLOCK'],
            'STATE_LOWER_LOCK': cls.__constants['STATE_LOWER_LOCK'],
            'STATE_LOWER_OPEN': cls.__constants['STATE_LOWER_OPEN'],
        }

    @property
    def STATE_UNKNOWN(self):
        """Message constant 'STATE_UNKNOWN'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_UNKNOWN']

    @property
    def STATE_RESET(self):
        """Message constant 'STATE_RESET'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_RESET']

    @property
    def STATE_UPPER_MANUAL_OPEN(self):
        """Message constant 'STATE_UPPER_MANUAL_OPEN'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_UPPER_MANUAL_OPEN']

    @property
    def STATE_UPPER_MANUAL_CLOSE(self):
        """Message constant 'STATE_UPPER_MANUAL_CLOSE'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_UPPER_MANUAL_CLOSE']

    @property
    def STATE_UPPER_AUTO_UNLOAD(self):
        """Message constant 'STATE_UPPER_AUTO_UNLOAD'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_UPPER_AUTO_UNLOAD']

    @property
    def STATE_LOWER_UNLOCK(self):
        """Message constant 'STATE_LOWER_UNLOCK'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_LOWER_UNLOCK']

    @property
    def STATE_LOWER_LOCK(self):
        """Message constant 'STATE_LOWER_LOCK'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_LOWER_LOCK']

    @property
    def STATE_LOWER_OPEN(self):
        """Message constant 'STATE_LOWER_OPEN'."""
        return Metaclass_GetCargoStatus_Response.__constants['STATE_LOWER_OPEN']


class GetCargoStatus_Response(metaclass=Metaclass_GetCargoStatus_Response):
    """
    Message class 'GetCargoStatus_Response'.

    Constants:
      STATE_UNKNOWN
      STATE_RESET
      STATE_UPPER_MANUAL_OPEN
      STATE_UPPER_MANUAL_CLOSE
      STATE_UPPER_AUTO_UNLOAD
      STATE_LOWER_UNLOCK
      STATE_LOWER_LOCK
      STATE_LOWER_OPEN
    """

    __slots__ = [
        '_success',
        '_message',
        '_cargo_id',
        '_state',
        '_last_operation_code',
        '_is_busy',
        '_state_text',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'cargo_id': 'uint8',
        'state': 'uint8',
        'last_operation_code': 'uint8',
        'is_busy': 'boolean',
        'state_text': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.cargo_id = kwargs.get('cargo_id', int())
        self.state = kwargs.get('state', int())
        self.last_operation_code = kwargs.get('last_operation_code', int())
        self.is_busy = kwargs.get('is_busy', bool())
        self.state_text = kwargs.get('state_text', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.cargo_id != other.cargo_id:
            return False
        if self.state != other.state:
            return False
        if self.last_operation_code != other.last_operation_code:
            return False
        if self.is_busy != other.is_busy:
            return False
        if self.state_text != other.state_text:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def cargo_id(self):
        """Message field 'cargo_id'."""
        return self._cargo_id

    @cargo_id.setter
    def cargo_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cargo_id' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'cargo_id' field must be an unsigned integer in [0, 255]"
        self._cargo_id = value

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'state' field must be an unsigned integer in [0, 255]"
        self._state = value

    @builtins.property
    def last_operation_code(self):
        """Message field 'last_operation_code'."""
        return self._last_operation_code

    @last_operation_code.setter
    def last_operation_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'last_operation_code' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'last_operation_code' field must be an unsigned integer in [0, 255]"
        self._last_operation_code = value

    @builtins.property
    def is_busy(self):
        """Message field 'is_busy'."""
        return self._is_busy

    @is_busy.setter
    def is_busy(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_busy' field must be of type 'bool'"
        self._is_busy = value

    @builtins.property
    def state_text(self):
        """Message field 'state_text'."""
        return self._state_text

    @state_text.setter
    def state_text(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'state_text' field must be of type 'str'"
        self._state_text = value


class Metaclass_GetCargoStatus(type):
    """Metaclass of service 'GetCargoStatus'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetCargoStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__get_cargo_status

            from master_interfaces.srv import _get_cargo_status
            if _get_cargo_status.Metaclass_GetCargoStatus_Request._TYPE_SUPPORT is None:
                _get_cargo_status.Metaclass_GetCargoStatus_Request.__import_type_support__()
            if _get_cargo_status.Metaclass_GetCargoStatus_Response._TYPE_SUPPORT is None:
                _get_cargo_status.Metaclass_GetCargoStatus_Response.__import_type_support__()


class GetCargoStatus(metaclass=Metaclass_GetCargoStatus):
    from master_interfaces.srv._get_cargo_status import GetCargoStatus_Request as Request
    from master_interfaces.srv._get_cargo_status import GetCargoStatus_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
