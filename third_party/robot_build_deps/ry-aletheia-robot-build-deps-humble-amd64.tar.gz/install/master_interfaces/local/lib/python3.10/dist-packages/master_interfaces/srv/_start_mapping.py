# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/StartMapping.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_StartMapping_Request(type):
    """Metaclass of message 'StartMapping_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartMapping_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__start_mapping__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__start_mapping__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__start_mapping__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__start_mapping__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__start_mapping__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class StartMapping_Request(metaclass=Metaclass_StartMapping_Request):
    """Message class 'StartMapping_Request'."""

    __slots__ = [
        '_rosbag',
        '_map_type',
        '_community',
        '_building',
        '_unit',
        '_floor',
    ]

    _fields_and_field_types = {
        'rosbag': 'string',
        'map_type': 'string',
        'community': 'string',
        'building': 'string',
        'unit': 'string',
        'floor': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.rosbag = kwargs.get('rosbag', str())
        self.map_type = kwargs.get('map_type', str())
        self.community = kwargs.get('community', str())
        self.building = kwargs.get('building', str())
        self.unit = kwargs.get('unit', str())
        self.floor = kwargs.get('floor', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.rosbag != other.rosbag:
            return False
        if self.map_type != other.map_type:
            return False
        if self.community != other.community:
            return False
        if self.building != other.building:
            return False
        if self.unit != other.unit:
            return False
        if self.floor != other.floor:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def rosbag(self):
        """Message field 'rosbag'."""
        return self._rosbag

    @rosbag.setter
    def rosbag(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'rosbag' field must be of type 'str'"
        self._rosbag = value

    @builtins.property
    def map_type(self):
        """Message field 'map_type'."""
        return self._map_type

    @map_type.setter
    def map_type(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'map_type' field must be of type 'str'"
        self._map_type = value

    @builtins.property
    def community(self):
        """Message field 'community'."""
        return self._community

    @community.setter
    def community(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'community' field must be of type 'str'"
        self._community = value

    @builtins.property
    def building(self):
        """Message field 'building'."""
        return self._building

    @building.setter
    def building(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'building' field must be of type 'str'"
        self._building = value

    @builtins.property
    def unit(self):
        """Message field 'unit'."""
        return self._unit

    @unit.setter
    def unit(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'unit' field must be of type 'str'"
        self._unit = value

    @builtins.property
    def floor(self):
        """Message field 'floor'."""
        return self._floor

    @floor.setter
    def floor(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'floor' field must be of type 'str'"
        self._floor = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_StartMapping_Response(type):
    """Metaclass of message 'StartMapping_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartMapping_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__start_mapping__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__start_mapping__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__start_mapping__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__start_mapping__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__start_mapping__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class StartMapping_Response(metaclass=Metaclass_StartMapping_Response):
    """Message class 'StartMapping_Response'."""

    __slots__ = [
        '_success',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value


class Metaclass_StartMapping(type):
    """Metaclass of service 'StartMapping'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartMapping')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__start_mapping

            from master_interfaces.srv import _start_mapping
            if _start_mapping.Metaclass_StartMapping_Request._TYPE_SUPPORT is None:
                _start_mapping.Metaclass_StartMapping_Request.__import_type_support__()
            if _start_mapping.Metaclass_StartMapping_Response._TYPE_SUPPORT is None:
                _start_mapping.Metaclass_StartMapping_Response.__import_type_support__()


class StartMapping(metaclass=Metaclass_StartMapping):
    from master_interfaces.srv._start_mapping import StartMapping_Request as Request
    from master_interfaces.srv._start_mapping import StartMapping_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
