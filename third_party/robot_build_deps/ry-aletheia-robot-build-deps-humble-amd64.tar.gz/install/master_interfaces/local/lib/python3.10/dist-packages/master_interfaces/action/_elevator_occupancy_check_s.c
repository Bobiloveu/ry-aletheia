// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from master_interfaces:action/ElevatorOccupancyCheck.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
#include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__goal__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[79];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_Goal", full_classname_dest, 78) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_Goal * ros_message = _ros_message;
  {  // enable
    PyObject * field = PyObject_GetAttrString(_pymsg, "enable");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->enable = (Py_True == field);
    Py_DECREF(field);
  }
  {  // car_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "car_status");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->car_status, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__goal__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_Goal */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_Goal");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_Goal * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_Goal *)raw_ros_message;
  {  // enable
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->enable ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "enable", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // car_status
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->car_status.data,
      strlen(ros_message->car_status.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "car_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

// already included above
// #include "rosidl_runtime_c/string.h"
// already included above
// #include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__result__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[81];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_Result", full_classname_dest, 80) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_Result * ros_message = _ros_message;
  {  // success
    PyObject * field = PyObject_GetAttrString(_pymsg, "success");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->success = (Py_True == field);
    Py_DECREF(field);
  }
  {  // average_occupied_ratio
    PyObject * field = PyObject_GetAttrString(_pymsg, "average_occupied_ratio");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->average_occupied_ratio = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // window_size
    PyObject * field = PyObject_GetAttrString(_pymsg, "window_size");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->window_size = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // sample_count
    PyObject * field = PyObject_GetAttrString(_pymsg, "sample_count");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->sample_count = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // last_occupied_ratio
    PyObject * field = PyObject_GetAttrString(_pymsg, "last_occupied_ratio");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->last_occupied_ratio = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // last_occupied_cells
    PyObject * field = PyObject_GetAttrString(_pymsg, "last_occupied_cells");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->last_occupied_cells = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // last_total_cells
    PyObject * field = PyObject_GetAttrString(_pymsg, "last_total_cells");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->last_total_cells = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // last_largest_cluster_cells
    PyObject * field = PyObject_GetAttrString(_pymsg, "last_largest_cluster_cells");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->last_largest_cluster_cells = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // source_frame
    PyObject * field = PyObject_GetAttrString(_pymsg, "source_frame");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->source_frame, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // roi_center_x
    PyObject * field = PyObject_GetAttrString(_pymsg, "roi_center_x");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->roi_center_x = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // roi_center_y
    PyObject * field = PyObject_GetAttrString(_pymsg, "roi_center_y");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->roi_center_y = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // roi_center_z
    PyObject * field = PyObject_GetAttrString(_pymsg, "roi_center_z");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->roi_center_z = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // roi_half_size_x
    PyObject * field = PyObject_GetAttrString(_pymsg, "roi_half_size_x");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->roi_half_size_x = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // roi_half_size_y
    PyObject * field = PyObject_GetAttrString(_pymsg, "roi_half_size_y");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->roi_half_size_y = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // roi_half_size_z
    PyObject * field = PyObject_GetAttrString(_pymsg, "roi_half_size_z");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->roi_half_size_z = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // message
    PyObject * field = PyObject_GetAttrString(_pymsg, "message");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->message, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__result__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_Result */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_Result");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_Result * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_Result *)raw_ros_message;
  {  // success
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->success ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "success", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // average_occupied_ratio
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->average_occupied_ratio);
    {
      int rc = PyObject_SetAttrString(_pymessage, "average_occupied_ratio", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // window_size
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->window_size);
    {
      int rc = PyObject_SetAttrString(_pymessage, "window_size", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // sample_count
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->sample_count);
    {
      int rc = PyObject_SetAttrString(_pymessage, "sample_count", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // last_occupied_ratio
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->last_occupied_ratio);
    {
      int rc = PyObject_SetAttrString(_pymessage, "last_occupied_ratio", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // last_occupied_cells
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->last_occupied_cells);
    {
      int rc = PyObject_SetAttrString(_pymessage, "last_occupied_cells", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // last_total_cells
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->last_total_cells);
    {
      int rc = PyObject_SetAttrString(_pymessage, "last_total_cells", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // last_largest_cluster_cells
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->last_largest_cluster_cells);
    {
      int rc = PyObject_SetAttrString(_pymessage, "last_largest_cluster_cells", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // source_frame
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->source_frame.data,
      strlen(ros_message->source_frame.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "source_frame", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // roi_center_x
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->roi_center_x);
    {
      int rc = PyObject_SetAttrString(_pymessage, "roi_center_x", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // roi_center_y
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->roi_center_y);
    {
      int rc = PyObject_SetAttrString(_pymessage, "roi_center_y", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // roi_center_z
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->roi_center_z);
    {
      int rc = PyObject_SetAttrString(_pymessage, "roi_center_z", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // roi_half_size_x
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->roi_half_size_x);
    {
      int rc = PyObject_SetAttrString(_pymessage, "roi_half_size_x", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // roi_half_size_y
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->roi_half_size_y);
    {
      int rc = PyObject_SetAttrString(_pymessage, "roi_half_size_y", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // roi_half_size_z
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->roi_half_size_z);
    {
      int rc = PyObject_SetAttrString(_pymessage, "roi_half_size_z", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // message
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->message.data,
      strlen(ros_message->message.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "message", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

// already included above
// #include "rosidl_runtime_c/string.h"
// already included above
// #include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__feedback__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[83];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_Feedback", full_classname_dest, 82) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_Feedback * ros_message = _ros_message;
  {  // collected_frames
    PyObject * field = PyObject_GetAttrString(_pymsg, "collected_frames");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->collected_frames = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // target_frames
    PyObject * field = PyObject_GetAttrString(_pymsg, "target_frames");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->target_frames = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // current_occupied_ratio
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_occupied_ratio");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->current_occupied_ratio = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // current_average_occupied_ratio
    PyObject * field = PyObject_GetAttrString(_pymsg, "current_average_occupied_ratio");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->current_average_occupied_ratio = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // progress_percentage
    PyObject * field = PyObject_GetAttrString(_pymsg, "progress_percentage");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->progress_percentage = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // status_message
    PyObject * field = PyObject_GetAttrString(_pymsg, "status_message");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->status_message, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__feedback__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_Feedback */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_Feedback");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_Feedback * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_Feedback *)raw_ros_message;
  {  // collected_frames
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->collected_frames);
    {
      int rc = PyObject_SetAttrString(_pymessage, "collected_frames", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // target_frames
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->target_frames);
    {
      int rc = PyObject_SetAttrString(_pymessage, "target_frames", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_occupied_ratio
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->current_occupied_ratio);
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_occupied_ratio", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // current_average_occupied_ratio
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->current_average_occupied_ratio);
    {
      int rc = PyObject_SetAttrString(_pymessage, "current_average_occupied_ratio", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // progress_percentage
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->progress_percentage);
    {
      int rc = PyObject_SetAttrString(_pymessage, "progress_percentage", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // status_message
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->status_message.data,
      strlen(ros_message->status_message.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "status_message", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool unique_identifier_msgs__msg__uuid__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * unique_identifier_msgs__msg__uuid__convert_to_py(void * raw_ros_message);
bool master_interfaces__action__elevator_occupancy_check__goal__convert_from_py(PyObject * _pymsg, void * _ros_message);
PyObject * master_interfaces__action__elevator_occupancy_check__goal__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__send_goal__request__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[91];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_SendGoal_Request", full_classname_dest, 90) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request * ros_message = _ros_message;
  {  // goal_id
    PyObject * field = PyObject_GetAttrString(_pymsg, "goal_id");
    if (!field) {
      return false;
    }
    if (!unique_identifier_msgs__msg__uuid__convert_from_py(field, &ros_message->goal_id)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // goal
    PyObject * field = PyObject_GetAttrString(_pymsg, "goal");
    if (!field) {
      return false;
    }
    if (!master_interfaces__action__elevator_occupancy_check__goal__convert_from_py(field, &ros_message->goal)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__send_goal__request__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_SendGoal_Request */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_SendGoal_Request");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Request *)raw_ros_message;
  {  // goal_id
    PyObject * field = NULL;
    field = unique_identifier_msgs__msg__uuid__convert_to_py(&ros_message->goal_id);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "goal_id", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // goal
    PyObject * field = NULL;
    field = master_interfaces__action__elevator_occupancy_check__goal__convert_to_py(&ros_message->goal);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "goal", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool builtin_interfaces__msg__time__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * builtin_interfaces__msg__time__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__send_goal__response__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[92];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_SendGoal_Response", full_classname_dest, 91) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response * ros_message = _ros_message;
  {  // accepted
    PyObject * field = PyObject_GetAttrString(_pymsg, "accepted");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->accepted = (Py_True == field);
    Py_DECREF(field);
  }
  {  // stamp
    PyObject * field = PyObject_GetAttrString(_pymsg, "stamp");
    if (!field) {
      return false;
    }
    if (!builtin_interfaces__msg__time__convert_from_py(field, &ros_message->stamp)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__send_goal__response__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_SendGoal_Response */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_SendGoal_Response");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_SendGoal_Response *)raw_ros_message;
  {  // accepted
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->accepted ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "accepted", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // stamp
    PyObject * field = NULL;
    field = builtin_interfaces__msg__time__convert_to_py(&ros_message->stamp);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "stamp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool unique_identifier_msgs__msg__uuid__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * unique_identifier_msgs__msg__uuid__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__get_result__request__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[92];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_GetResult_Request", full_classname_dest, 91) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request * ros_message = _ros_message;
  {  // goal_id
    PyObject * field = PyObject_GetAttrString(_pymsg, "goal_id");
    if (!field) {
      return false;
    }
    if (!unique_identifier_msgs__msg__uuid__convert_from_py(field, &ros_message->goal_id)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__get_result__request__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_GetResult_Request */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_GetResult_Request");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_GetResult_Request *)raw_ros_message;
  {  // goal_id
    PyObject * field = NULL;
    field = unique_identifier_msgs__msg__uuid__convert_to_py(&ros_message->goal_id);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "goal_id", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

bool master_interfaces__action__elevator_occupancy_check__result__convert_from_py(PyObject * _pymsg, void * _ros_message);
PyObject * master_interfaces__action__elevator_occupancy_check__result__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__get_result__response__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[93];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_GetResult_Response", full_classname_dest, 92) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response * ros_message = _ros_message;
  {  // status
    PyObject * field = PyObject_GetAttrString(_pymsg, "status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->status = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // result
    PyObject * field = PyObject_GetAttrString(_pymsg, "result");
    if (!field) {
      return false;
    }
    if (!master_interfaces__action__elevator_occupancy_check__result__convert_from_py(field, &ros_message->result)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__get_result__response__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_GetResult_Response */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_GetResult_Response");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_GetResult_Response *)raw_ros_message;
  {  // status
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // result
    PyObject * field = NULL;
    field = master_interfaces__action__elevator_occupancy_check__result__convert_to_py(&ros_message->result);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "result", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__struct.h"
// already included above
// #include "master_interfaces/action/detail/elevator_occupancy_check__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool unique_identifier_msgs__msg__uuid__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * unique_identifier_msgs__msg__uuid__convert_to_py(void * raw_ros_message);
bool master_interfaces__action__elevator_occupancy_check__feedback__convert_from_py(PyObject * _pymsg, void * _ros_message);
PyObject * master_interfaces__action__elevator_occupancy_check__feedback__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool master_interfaces__action__elevator_occupancy_check__feedback_message__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[90];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("master_interfaces.action._elevator_occupancy_check.ElevatorOccupancyCheck_FeedbackMessage", full_classname_dest, 89) == 0);
  }
  master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage * ros_message = _ros_message;
  {  // goal_id
    PyObject * field = PyObject_GetAttrString(_pymsg, "goal_id");
    if (!field) {
      return false;
    }
    if (!unique_identifier_msgs__msg__uuid__convert_from_py(field, &ros_message->goal_id)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // feedback
    PyObject * field = PyObject_GetAttrString(_pymsg, "feedback");
    if (!field) {
      return false;
    }
    if (!master_interfaces__action__elevator_occupancy_check__feedback__convert_from_py(field, &ros_message->feedback)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * master_interfaces__action__elevator_occupancy_check__feedback_message__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ElevatorOccupancyCheck_FeedbackMessage */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("master_interfaces.action._elevator_occupancy_check");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ElevatorOccupancyCheck_FeedbackMessage");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage * ros_message = (master_interfaces__action__ElevatorOccupancyCheck_FeedbackMessage *)raw_ros_message;
  {  // goal_id
    PyObject * field = NULL;
    field = unique_identifier_msgs__msg__uuid__convert_to_py(&ros_message->goal_id);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "goal_id", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // feedback
    PyObject * field = NULL;
    field = master_interfaces__action__elevator_occupancy_check__feedback__convert_to_py(&ros_message->feedback);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "feedback", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
