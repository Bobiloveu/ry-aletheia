# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/DoorControl.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_DoorControl_Request(type):
    """Metaclass of message 'DoorControl_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.DoorControl_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__door_control__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__door_control__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__door_control__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__door_control__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__door_control__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class DoorControl_Request(metaclass=Metaclass_DoorControl_Request):
    """Message class 'DoorControl_Request'."""

    __slots__ = [
        '_executeid',
        '_doorid',
    ]

    _fields_and_field_types = {
        'executeid': 'int32',
        'doorid': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.executeid = kwargs.get('executeid', int())
        self.doorid = kwargs.get('doorid', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.executeid != other.executeid:
            return False
        if self.doorid != other.doorid:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def executeid(self):
        """Message field 'executeid'."""
        return self._executeid

    @executeid.setter
    def executeid(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'executeid' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'executeid' field must be an integer in [-2147483648, 2147483647]"
        self._executeid = value

    @builtins.property
    def doorid(self):
        """Message field 'doorid'."""
        return self._doorid

    @doorid.setter
    def doorid(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'doorid' field must be of type 'str'"
        self._doorid = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_DoorControl_Response(type):
    """Metaclass of message 'DoorControl_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.DoorControl_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__door_control__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__door_control__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__door_control__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__door_control__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__door_control__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class DoorControl_Response(metaclass=Metaclass_DoorControl_Response):
    """Message class 'DoorControl_Response'."""

    __slots__ = [
        '_success',
        '_stateid',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'stateid': 'int32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.stateid = kwargs.get('stateid', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.stateid != other.stateid:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def stateid(self):
        """Message field 'stateid'."""
        return self._stateid

    @stateid.setter
    def stateid(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'stateid' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'stateid' field must be an integer in [-2147483648, 2147483647]"
        self._stateid = value


class Metaclass_DoorControl(type):
    """Metaclass of service 'DoorControl'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.DoorControl')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__door_control

            from master_interfaces.srv import _door_control
            if _door_control.Metaclass_DoorControl_Request._TYPE_SUPPORT is None:
                _door_control.Metaclass_DoorControl_Request.__import_type_support__()
            if _door_control.Metaclass_DoorControl_Response._TYPE_SUPPORT is None:
                _door_control.Metaclass_DoorControl_Response.__import_type_support__()


class DoorControl(metaclass=Metaclass_DoorControl):
    from master_interfaces.srv._door_control import DoorControl_Request as Request
    from master_interfaces.srv._door_control import DoorControl_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
