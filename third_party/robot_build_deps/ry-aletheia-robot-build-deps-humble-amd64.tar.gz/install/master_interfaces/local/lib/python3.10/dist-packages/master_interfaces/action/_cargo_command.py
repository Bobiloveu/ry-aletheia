# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:action/CargoCommand.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_CargoCommand_Goal(type):
    """Metaclass of message 'CargoCommand_Goal'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'CARGO_UPPER': 1,
        'CARGO_LOWER': 2,
        'OP_MANUAL_OPEN': 0,
        'OP_MANUAL_CLOSE': 1,
        'OP_AUTO_UNLOAD': 2,
        'OP_RESET': 3,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_Goal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__goal
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__goal
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__goal
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__goal
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__goal

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'CARGO_UPPER': cls.__constants['CARGO_UPPER'],
            'CARGO_LOWER': cls.__constants['CARGO_LOWER'],
            'OP_MANUAL_OPEN': cls.__constants['OP_MANUAL_OPEN'],
            'OP_MANUAL_CLOSE': cls.__constants['OP_MANUAL_CLOSE'],
            'OP_AUTO_UNLOAD': cls.__constants['OP_AUTO_UNLOAD'],
            'OP_RESET': cls.__constants['OP_RESET'],
        }

    @property
    def CARGO_UPPER(self):
        """Message constant 'CARGO_UPPER'."""
        return Metaclass_CargoCommand_Goal.__constants['CARGO_UPPER']

    @property
    def CARGO_LOWER(self):
        """Message constant 'CARGO_LOWER'."""
        return Metaclass_CargoCommand_Goal.__constants['CARGO_LOWER']

    @property
    def OP_MANUAL_OPEN(self):
        """Message constant 'OP_MANUAL_OPEN'."""
        return Metaclass_CargoCommand_Goal.__constants['OP_MANUAL_OPEN']

    @property
    def OP_MANUAL_CLOSE(self):
        """Message constant 'OP_MANUAL_CLOSE'."""
        return Metaclass_CargoCommand_Goal.__constants['OP_MANUAL_CLOSE']

    @property
    def OP_AUTO_UNLOAD(self):
        """Message constant 'OP_AUTO_UNLOAD'."""
        return Metaclass_CargoCommand_Goal.__constants['OP_AUTO_UNLOAD']

    @property
    def OP_RESET(self):
        """Message constant 'OP_RESET'."""
        return Metaclass_CargoCommand_Goal.__constants['OP_RESET']


class CargoCommand_Goal(metaclass=Metaclass_CargoCommand_Goal):
    """
    Message class 'CargoCommand_Goal'.

    Constants:
      CARGO_UPPER
      CARGO_LOWER
      OP_MANUAL_OPEN
      OP_MANUAL_CLOSE
      OP_AUTO_UNLOAD
      OP_RESET
    """

    __slots__ = [
        '_cargo_id',
        '_operation_code',
    ]

    _fields_and_field_types = {
        'cargo_id': 'uint8',
        'operation_code': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.cargo_id = kwargs.get('cargo_id', int())
        self.operation_code = kwargs.get('operation_code', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.cargo_id != other.cargo_id:
            return False
        if self.operation_code != other.operation_code:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def cargo_id(self):
        """Message field 'cargo_id'."""
        return self._cargo_id

    @cargo_id.setter
    def cargo_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cargo_id' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'cargo_id' field must be an unsigned integer in [0, 255]"
        self._cargo_id = value

    @builtins.property
    def operation_code(self):
        """Message field 'operation_code'."""
        return self._operation_code

    @operation_code.setter
    def operation_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'operation_code' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'operation_code' field must be an unsigned integer in [0, 255]"
        self._operation_code = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_Result(type):
    """Metaclass of message 'CargoCommand_Result'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'ERROR_NONE': 0,
        'ERROR_INVALID_GOAL': 1,
        'ERROR_BUSY': 2,
        'ERROR_MQTT_UNAVAILABLE': 3,
        'ERROR_PUBLISH_FAILED': 4,
        'ERROR_TIMEOUT': 5,
        'ERROR_RESPONSE_MISMATCH': 6,
        'ERROR_RESPONSE_INVALID': 7,
        'ERROR_CANCELED': 8,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_Result')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__result
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__result
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__result
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__result
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__result

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'ERROR_NONE': cls.__constants['ERROR_NONE'],
            'ERROR_INVALID_GOAL': cls.__constants['ERROR_INVALID_GOAL'],
            'ERROR_BUSY': cls.__constants['ERROR_BUSY'],
            'ERROR_MQTT_UNAVAILABLE': cls.__constants['ERROR_MQTT_UNAVAILABLE'],
            'ERROR_PUBLISH_FAILED': cls.__constants['ERROR_PUBLISH_FAILED'],
            'ERROR_TIMEOUT': cls.__constants['ERROR_TIMEOUT'],
            'ERROR_RESPONSE_MISMATCH': cls.__constants['ERROR_RESPONSE_MISMATCH'],
            'ERROR_RESPONSE_INVALID': cls.__constants['ERROR_RESPONSE_INVALID'],
            'ERROR_CANCELED': cls.__constants['ERROR_CANCELED'],
        }

    @property
    def ERROR_NONE(self):
        """Message constant 'ERROR_NONE'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_NONE']

    @property
    def ERROR_INVALID_GOAL(self):
        """Message constant 'ERROR_INVALID_GOAL'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_INVALID_GOAL']

    @property
    def ERROR_BUSY(self):
        """Message constant 'ERROR_BUSY'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_BUSY']

    @property
    def ERROR_MQTT_UNAVAILABLE(self):
        """Message constant 'ERROR_MQTT_UNAVAILABLE'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_MQTT_UNAVAILABLE']

    @property
    def ERROR_PUBLISH_FAILED(self):
        """Message constant 'ERROR_PUBLISH_FAILED'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_PUBLISH_FAILED']

    @property
    def ERROR_TIMEOUT(self):
        """Message constant 'ERROR_TIMEOUT'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_TIMEOUT']

    @property
    def ERROR_RESPONSE_MISMATCH(self):
        """Message constant 'ERROR_RESPONSE_MISMATCH'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_RESPONSE_MISMATCH']

    @property
    def ERROR_RESPONSE_INVALID(self):
        """Message constant 'ERROR_RESPONSE_INVALID'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_RESPONSE_INVALID']

    @property
    def ERROR_CANCELED(self):
        """Message constant 'ERROR_CANCELED'."""
        return Metaclass_CargoCommand_Result.__constants['ERROR_CANCELED']


class CargoCommand_Result(metaclass=Metaclass_CargoCommand_Result):
    """
    Message class 'CargoCommand_Result'.

    Constants:
      ERROR_NONE
      ERROR_INVALID_GOAL
      ERROR_BUSY
      ERROR_MQTT_UNAVAILABLE
      ERROR_PUBLISH_FAILED
      ERROR_TIMEOUT
      ERROR_RESPONSE_MISMATCH
      ERROR_RESPONSE_INVALID
      ERROR_CANCELED
    """

    __slots__ = [
        '_success',
        '_message',
        '_cargo_id',
        '_operation_code',
        '_error_code',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'cargo_id': 'uint8',
        'operation_code': 'uint8',
        'error_code': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.cargo_id = kwargs.get('cargo_id', int())
        self.operation_code = kwargs.get('operation_code', int())
        self.error_code = kwargs.get('error_code', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.cargo_id != other.cargo_id:
            return False
        if self.operation_code != other.operation_code:
            return False
        if self.error_code != other.error_code:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def cargo_id(self):
        """Message field 'cargo_id'."""
        return self._cargo_id

    @cargo_id.setter
    def cargo_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cargo_id' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'cargo_id' field must be an unsigned integer in [0, 255]"
        self._cargo_id = value

    @builtins.property
    def operation_code(self):
        """Message field 'operation_code'."""
        return self._operation_code

    @operation_code.setter
    def operation_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'operation_code' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'operation_code' field must be an unsigned integer in [0, 255]"
        self._operation_code = value

    @builtins.property
    def error_code(self):
        """Message field 'error_code'."""
        return self._error_code

    @error_code.setter
    def error_code(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'error_code' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'error_code' field must be an unsigned integer in [0, 255]"
        self._error_code = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_Feedback(type):
    """Metaclass of message 'CargoCommand_Feedback'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'STATUS_ACCEPTED': 0,
        'STATUS_PUBLISHING': 1,
        'STATUS_WAITING_RESPONSE': 2,
        'STATUS_COMPLETED': 3,
        'STATUS_CANCELED': 4,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_Feedback')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__feedback
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__feedback
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__feedback
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__feedback
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__feedback

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'STATUS_ACCEPTED': cls.__constants['STATUS_ACCEPTED'],
            'STATUS_PUBLISHING': cls.__constants['STATUS_PUBLISHING'],
            'STATUS_WAITING_RESPONSE': cls.__constants['STATUS_WAITING_RESPONSE'],
            'STATUS_COMPLETED': cls.__constants['STATUS_COMPLETED'],
            'STATUS_CANCELED': cls.__constants['STATUS_CANCELED'],
        }

    @property
    def STATUS_ACCEPTED(self):
        """Message constant 'STATUS_ACCEPTED'."""
        return Metaclass_CargoCommand_Feedback.__constants['STATUS_ACCEPTED']

    @property
    def STATUS_PUBLISHING(self):
        """Message constant 'STATUS_PUBLISHING'."""
        return Metaclass_CargoCommand_Feedback.__constants['STATUS_PUBLISHING']

    @property
    def STATUS_WAITING_RESPONSE(self):
        """Message constant 'STATUS_WAITING_RESPONSE'."""
        return Metaclass_CargoCommand_Feedback.__constants['STATUS_WAITING_RESPONSE']

    @property
    def STATUS_COMPLETED(self):
        """Message constant 'STATUS_COMPLETED'."""
        return Metaclass_CargoCommand_Feedback.__constants['STATUS_COMPLETED']

    @property
    def STATUS_CANCELED(self):
        """Message constant 'STATUS_CANCELED'."""
        return Metaclass_CargoCommand_Feedback.__constants['STATUS_CANCELED']


class CargoCommand_Feedback(metaclass=Metaclass_CargoCommand_Feedback):
    """
    Message class 'CargoCommand_Feedback'.

    Constants:
      STATUS_ACCEPTED
      STATUS_PUBLISHING
      STATUS_WAITING_RESPONSE
      STATUS_COMPLETED
      STATUS_CANCELED
    """

    __slots__ = [
        '_status',
        '_status_message',
    ]

    _fields_and_field_types = {
        'status': 'uint8',
        'status_message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        self.status_message = kwargs.get('status_message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.status_message != other.status_message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'status' field must be an unsigned integer in [0, 255]"
        self._status = value

    @builtins.property
    def status_message(self):
        """Message field 'status_message'."""
        return self._status_message

    @status_message.setter
    def status_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'status_message' field must be of type 'str'"
        self._status_message = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_SendGoal_Request(type):
    """Metaclass of message 'CargoCommand_SendGoal_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_SendGoal_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__send_goal__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__send_goal__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__send_goal__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__send_goal__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__send_goal__request

            from master_interfaces.action import CargoCommand
            if CargoCommand.Goal.__class__._TYPE_SUPPORT is None:
                CargoCommand.Goal.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CargoCommand_SendGoal_Request(metaclass=Metaclass_CargoCommand_SendGoal_Request):
    """Message class 'CargoCommand_SendGoal_Request'."""

    __slots__ = [
        '_goal_id',
        '_goal',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'goal': 'master_interfaces/CargoCommand_Goal',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'CargoCommand_Goal'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from master_interfaces.action._cargo_command import CargoCommand_Goal
        self.goal = kwargs.get('goal', CargoCommand_Goal())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.goal != other.goal:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def goal(self):
        """Message field 'goal'."""
        return self._goal

    @goal.setter
    def goal(self, value):
        if __debug__:
            from master_interfaces.action._cargo_command import CargoCommand_Goal
            assert \
                isinstance(value, CargoCommand_Goal), \
                "The 'goal' field must be a sub message of type 'CargoCommand_Goal'"
        self._goal = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_SendGoal_Response(type):
    """Metaclass of message 'CargoCommand_SendGoal_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_SendGoal_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__send_goal__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__send_goal__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__send_goal__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__send_goal__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__send_goal__response

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CargoCommand_SendGoal_Response(metaclass=Metaclass_CargoCommand_SendGoal_Response):
    """Message class 'CargoCommand_SendGoal_Response'."""

    __slots__ = [
        '_accepted',
        '_stamp',
    ]

    _fields_and_field_types = {
        'accepted': 'boolean',
        'stamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.accepted = kwargs.get('accepted', bool())
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.accepted != other.accepted:
            return False
        if self.stamp != other.stamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def accepted(self):
        """Message field 'accepted'."""
        return self._accepted

    @accepted.setter
    def accepted(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'accepted' field must be of type 'bool'"
        self._accepted = value

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value


class Metaclass_CargoCommand_SendGoal(type):
    """Metaclass of service 'CargoCommand_SendGoal'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_SendGoal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__cargo_command__send_goal

            from master_interfaces.action import _cargo_command
            if _cargo_command.Metaclass_CargoCommand_SendGoal_Request._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_SendGoal_Request.__import_type_support__()
            if _cargo_command.Metaclass_CargoCommand_SendGoal_Response._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_SendGoal_Response.__import_type_support__()


class CargoCommand_SendGoal(metaclass=Metaclass_CargoCommand_SendGoal):
    from master_interfaces.action._cargo_command import CargoCommand_SendGoal_Request as Request
    from master_interfaces.action._cargo_command import CargoCommand_SendGoal_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_GetResult_Request(type):
    """Metaclass of message 'CargoCommand_GetResult_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_GetResult_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__get_result__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__get_result__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__get_result__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__get_result__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__get_result__request

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CargoCommand_GetResult_Request(metaclass=Metaclass_CargoCommand_GetResult_Request):
    """Message class 'CargoCommand_GetResult_Request'."""

    __slots__ = [
        '_goal_id',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_GetResult_Response(type):
    """Metaclass of message 'CargoCommand_GetResult_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_GetResult_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__get_result__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__get_result__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__get_result__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__get_result__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__get_result__response

            from master_interfaces.action import CargoCommand
            if CargoCommand.Result.__class__._TYPE_SUPPORT is None:
                CargoCommand.Result.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CargoCommand_GetResult_Response(metaclass=Metaclass_CargoCommand_GetResult_Response):
    """Message class 'CargoCommand_GetResult_Response'."""

    __slots__ = [
        '_status',
        '_result',
    ]

    _fields_and_field_types = {
        'status': 'int8',
        'result': 'master_interfaces/CargoCommand_Result',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'CargoCommand_Result'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        from master_interfaces.action._cargo_command import CargoCommand_Result
        self.result = kwargs.get('result', CargoCommand_Result())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.result != other.result:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'status' field must be an integer in [-128, 127]"
        self._status = value

    @builtins.property
    def result(self):
        """Message field 'result'."""
        return self._result

    @result.setter
    def result(self, value):
        if __debug__:
            from master_interfaces.action._cargo_command import CargoCommand_Result
            assert \
                isinstance(value, CargoCommand_Result), \
                "The 'result' field must be a sub message of type 'CargoCommand_Result'"
        self._result = value


class Metaclass_CargoCommand_GetResult(type):
    """Metaclass of service 'CargoCommand_GetResult'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_GetResult')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__cargo_command__get_result

            from master_interfaces.action import _cargo_command
            if _cargo_command.Metaclass_CargoCommand_GetResult_Request._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_GetResult_Request.__import_type_support__()
            if _cargo_command.Metaclass_CargoCommand_GetResult_Response._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_GetResult_Response.__import_type_support__()


class CargoCommand_GetResult(metaclass=Metaclass_CargoCommand_GetResult):
    from master_interfaces.action._cargo_command import CargoCommand_GetResult_Request as Request
    from master_interfaces.action._cargo_command import CargoCommand_GetResult_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CargoCommand_FeedbackMessage(type):
    """Metaclass of message 'CargoCommand_FeedbackMessage'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand_FeedbackMessage')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__cargo_command__feedback_message
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__cargo_command__feedback_message
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__cargo_command__feedback_message
            cls._TYPE_SUPPORT = module.type_support_msg__action__cargo_command__feedback_message
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__cargo_command__feedback_message

            from master_interfaces.action import CargoCommand
            if CargoCommand.Feedback.__class__._TYPE_SUPPORT is None:
                CargoCommand.Feedback.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CargoCommand_FeedbackMessage(metaclass=Metaclass_CargoCommand_FeedbackMessage):
    """Message class 'CargoCommand_FeedbackMessage'."""

    __slots__ = [
        '_goal_id',
        '_feedback',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'feedback': 'master_interfaces/CargoCommand_Feedback',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'action'], 'CargoCommand_Feedback'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from master_interfaces.action._cargo_command import CargoCommand_Feedback
        self.feedback = kwargs.get('feedback', CargoCommand_Feedback())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.feedback != other.feedback:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def feedback(self):
        """Message field 'feedback'."""
        return self._feedback

    @feedback.setter
    def feedback(self, value):
        if __debug__:
            from master_interfaces.action._cargo_command import CargoCommand_Feedback
            assert \
                isinstance(value, CargoCommand_Feedback), \
                "The 'feedback' field must be a sub message of type 'CargoCommand_Feedback'"
        self._feedback = value


class Metaclass_CargoCommand(type):
    """Metaclass of action 'CargoCommand'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.action.CargoCommand')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_action__action__cargo_command

            from action_msgs.msg import _goal_status_array
            if _goal_status_array.Metaclass_GoalStatusArray._TYPE_SUPPORT is None:
                _goal_status_array.Metaclass_GoalStatusArray.__import_type_support__()
            from action_msgs.srv import _cancel_goal
            if _cancel_goal.Metaclass_CancelGoal._TYPE_SUPPORT is None:
                _cancel_goal.Metaclass_CancelGoal.__import_type_support__()

            from master_interfaces.action import _cargo_command
            if _cargo_command.Metaclass_CargoCommand_SendGoal._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_SendGoal.__import_type_support__()
            if _cargo_command.Metaclass_CargoCommand_GetResult._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_GetResult.__import_type_support__()
            if _cargo_command.Metaclass_CargoCommand_FeedbackMessage._TYPE_SUPPORT is None:
                _cargo_command.Metaclass_CargoCommand_FeedbackMessage.__import_type_support__()


class CargoCommand(metaclass=Metaclass_CargoCommand):

    # The goal message defined in the action definition.
    from master_interfaces.action._cargo_command import CargoCommand_Goal as Goal
    # The result message defined in the action definition.
    from master_interfaces.action._cargo_command import CargoCommand_Result as Result
    # The feedback message defined in the action definition.
    from master_interfaces.action._cargo_command import CargoCommand_Feedback as Feedback

    class Impl:

        # The send_goal service using a wrapped version of the goal message as a request.
        from master_interfaces.action._cargo_command import CargoCommand_SendGoal as SendGoalService
        # The get_result service using a wrapped version of the result message as a response.
        from master_interfaces.action._cargo_command import CargoCommand_GetResult as GetResultService
        # The feedback message with generic fields which wraps the feedback message.
        from master_interfaces.action._cargo_command import CargoCommand_FeedbackMessage as FeedbackMessage

        # The generic service to cancel a goal.
        from action_msgs.srv._cancel_goal import CancelGoal as CancelGoalService
        # The generic message for get the status of a goal.
        from action_msgs.msg._goal_status_array import GoalStatusArray as GoalStatusMessage

    def __init__(self):
        raise NotImplementedError('Action classes can not be instantiated')
