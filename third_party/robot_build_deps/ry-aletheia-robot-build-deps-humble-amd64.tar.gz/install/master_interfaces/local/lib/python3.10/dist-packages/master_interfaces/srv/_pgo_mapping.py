# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/PGOMapping.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_PGOMapping_Request(type):
    """Metaclass of message 'PGOMapping_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.PGOMapping_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__pgo_mapping__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__pgo_mapping__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__pgo_mapping__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__pgo_mapping__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__pgo_mapping__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PGOMapping_Request(metaclass=Metaclass_PGOMapping_Request):
    """Message class 'PGOMapping_Request'."""

    __slots__ = [
        '_command',
        '_file_path',
        '_save_patches',
    ]

    _fields_and_field_types = {
        'command': 'string',
        'file_path': 'string',
        'save_patches': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.command = kwargs.get('command', str())
        self.file_path = kwargs.get('file_path', str())
        self.save_patches = kwargs.get('save_patches', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.command != other.command:
            return False
        if self.file_path != other.file_path:
            return False
        if self.save_patches != other.save_patches:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def command(self):
        """Message field 'command'."""
        return self._command

    @command.setter
    def command(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'command' field must be of type 'str'"
        self._command = value

    @builtins.property
    def file_path(self):
        """Message field 'file_path'."""
        return self._file_path

    @file_path.setter
    def file_path(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'file_path' field must be of type 'str'"
        self._file_path = value

    @builtins.property
    def save_patches(self):
        """Message field 'save_patches'."""
        return self._save_patches

    @save_patches.setter
    def save_patches(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'save_patches' field must be of type 'bool'"
        self._save_patches = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_PGOMapping_Response(type):
    """Metaclass of message 'PGOMapping_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.PGOMapping_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__pgo_mapping__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__pgo_mapping__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__pgo_mapping__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__pgo_mapping__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__pgo_mapping__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PGOMapping_Response(metaclass=Metaclass_PGOMapping_Response):
    """Message class 'PGOMapping_Response'."""

    __slots__ = [
        '_success',
        '_message',
        '_num_key_poses',
        '_num_loops',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'num_key_poses': 'int32',
        'num_loops': 'int32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.num_key_poses = kwargs.get('num_key_poses', int())
        self.num_loops = kwargs.get('num_loops', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.num_key_poses != other.num_key_poses:
            return False
        if self.num_loops != other.num_loops:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def num_key_poses(self):
        """Message field 'num_key_poses'."""
        return self._num_key_poses

    @num_key_poses.setter
    def num_key_poses(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'num_key_poses' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'num_key_poses' field must be an integer in [-2147483648, 2147483647]"
        self._num_key_poses = value

    @builtins.property
    def num_loops(self):
        """Message field 'num_loops'."""
        return self._num_loops

    @num_loops.setter
    def num_loops(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'num_loops' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'num_loops' field must be an integer in [-2147483648, 2147483647]"
        self._num_loops = value


class Metaclass_PGOMapping(type):
    """Metaclass of service 'PGOMapping'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.PGOMapping')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__pgo_mapping

            from master_interfaces.srv import _pgo_mapping
            if _pgo_mapping.Metaclass_PGOMapping_Request._TYPE_SUPPORT is None:
                _pgo_mapping.Metaclass_PGOMapping_Request.__import_type_support__()
            if _pgo_mapping.Metaclass_PGOMapping_Response._TYPE_SUPPORT is None:
                _pgo_mapping.Metaclass_PGOMapping_Response.__import_type_support__()


class PGOMapping(metaclass=Metaclass_PGOMapping):
    from master_interfaces.srv._pgo_mapping import PGOMapping_Request as Request
    from master_interfaces.srv._pgo_mapping import PGOMapping_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
