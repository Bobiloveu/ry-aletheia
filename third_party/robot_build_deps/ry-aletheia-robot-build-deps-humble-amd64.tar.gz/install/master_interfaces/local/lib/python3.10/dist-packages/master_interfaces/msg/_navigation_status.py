# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/NavigationStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_NavigationStatus(type):
    """Metaclass of message 'NavigationStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'PENDING': 0,
        'PLANNING': 1,
        'RUNNING': 2,
        'SUCCEEDED': 3,
        'FAILED': 4,
        'CANCELLED': 5,
        'PAUSED': 6,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.NavigationStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__navigation_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__navigation_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__navigation_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__navigation_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__navigation_status

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

            from geometry_msgs.msg import PoseStamped
            if PoseStamped.__class__._TYPE_SUPPORT is None:
                PoseStamped.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'PENDING': cls.__constants['PENDING'],
            'PLANNING': cls.__constants['PLANNING'],
            'RUNNING': cls.__constants['RUNNING'],
            'SUCCEEDED': cls.__constants['SUCCEEDED'],
            'FAILED': cls.__constants['FAILED'],
            'CANCELLED': cls.__constants['CANCELLED'],
            'PAUSED': cls.__constants['PAUSED'],
        }

    @property
    def PENDING(self):
        """Message constant 'PENDING'."""
        return Metaclass_NavigationStatus.__constants['PENDING']

    @property
    def PLANNING(self):
        """Message constant 'PLANNING'."""
        return Metaclass_NavigationStatus.__constants['PLANNING']

    @property
    def RUNNING(self):
        """Message constant 'RUNNING'."""
        return Metaclass_NavigationStatus.__constants['RUNNING']

    @property
    def SUCCEEDED(self):
        """Message constant 'SUCCEEDED'."""
        return Metaclass_NavigationStatus.__constants['SUCCEEDED']

    @property
    def FAILED(self):
        """Message constant 'FAILED'."""
        return Metaclass_NavigationStatus.__constants['FAILED']

    @property
    def CANCELLED(self):
        """Message constant 'CANCELLED'."""
        return Metaclass_NavigationStatus.__constants['CANCELLED']

    @property
    def PAUSED(self):
        """Message constant 'PAUSED'."""
        return Metaclass_NavigationStatus.__constants['PAUSED']


class NavigationStatus(metaclass=Metaclass_NavigationStatus):
    """
    Message class 'NavigationStatus'.

    Constants:
      PENDING
      PLANNING
      RUNNING
      SUCCEEDED
      FAILED
      CANCELLED
      PAUSED
    """

    __slots__ = [
        '_task_id',
        '_status',
        '_target_pose',
        '_current_pose',
        '_remaining_distance',
        '_estimated_time_remaining',
        '_progress',
        '_current_planner_id',
        '_current_controller_id',
        '_created_time',
        '_started_time',
        '_completed_time',
        '_error_message',
        '_waypoint_type',
        '_navigation_data',
    ]

    _fields_and_field_types = {
        'task_id': 'string',
        'status': 'uint8',
        'target_pose': 'geometry_msgs/PoseStamped',
        'current_pose': 'geometry_msgs/PoseStamped',
        'remaining_distance': 'double',
        'estimated_time_remaining': 'double',
        'progress': 'double',
        'current_planner_id': 'string',
        'current_controller_id': 'string',
        'created_time': 'builtin_interfaces/Time',
        'started_time': 'builtin_interfaces/Time',
        'completed_time': 'builtin_interfaces/Time',
        'error_message': 'string',
        'waypoint_type': 'string',
        'navigation_data': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'PoseStamped'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'PoseStamped'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.task_id = kwargs.get('task_id', str())
        self.status = kwargs.get('status', int())
        from geometry_msgs.msg import PoseStamped
        self.target_pose = kwargs.get('target_pose', PoseStamped())
        from geometry_msgs.msg import PoseStamped
        self.current_pose = kwargs.get('current_pose', PoseStamped())
        self.remaining_distance = kwargs.get('remaining_distance', float())
        self.estimated_time_remaining = kwargs.get('estimated_time_remaining', float())
        self.progress = kwargs.get('progress', float())
        self.current_planner_id = kwargs.get('current_planner_id', str())
        self.current_controller_id = kwargs.get('current_controller_id', str())
        from builtin_interfaces.msg import Time
        self.created_time = kwargs.get('created_time', Time())
        from builtin_interfaces.msg import Time
        self.started_time = kwargs.get('started_time', Time())
        from builtin_interfaces.msg import Time
        self.completed_time = kwargs.get('completed_time', Time())
        self.error_message = kwargs.get('error_message', str())
        self.waypoint_type = kwargs.get('waypoint_type', str())
        self.navigation_data = kwargs.get('navigation_data', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.task_id != other.task_id:
            return False
        if self.status != other.status:
            return False
        if self.target_pose != other.target_pose:
            return False
        if self.current_pose != other.current_pose:
            return False
        if self.remaining_distance != other.remaining_distance:
            return False
        if self.estimated_time_remaining != other.estimated_time_remaining:
            return False
        if self.progress != other.progress:
            return False
        if self.current_planner_id != other.current_planner_id:
            return False
        if self.current_controller_id != other.current_controller_id:
            return False
        if self.created_time != other.created_time:
            return False
        if self.started_time != other.started_time:
            return False
        if self.completed_time != other.completed_time:
            return False
        if self.error_message != other.error_message:
            return False
        if self.waypoint_type != other.waypoint_type:
            return False
        if self.navigation_data != other.navigation_data:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def task_id(self):
        """Message field 'task_id'."""
        return self._task_id

    @task_id.setter
    def task_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'task_id' field must be of type 'str'"
        self._task_id = value

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'status' field must be an unsigned integer in [0, 255]"
        self._status = value

    @builtins.property
    def target_pose(self):
        """Message field 'target_pose'."""
        return self._target_pose

    @target_pose.setter
    def target_pose(self, value):
        if __debug__:
            from geometry_msgs.msg import PoseStamped
            assert \
                isinstance(value, PoseStamped), \
                "The 'target_pose' field must be a sub message of type 'PoseStamped'"
        self._target_pose = value

    @builtins.property
    def current_pose(self):
        """Message field 'current_pose'."""
        return self._current_pose

    @current_pose.setter
    def current_pose(self, value):
        if __debug__:
            from geometry_msgs.msg import PoseStamped
            assert \
                isinstance(value, PoseStamped), \
                "The 'current_pose' field must be a sub message of type 'PoseStamped'"
        self._current_pose = value

    @builtins.property
    def remaining_distance(self):
        """Message field 'remaining_distance'."""
        return self._remaining_distance

    @remaining_distance.setter
    def remaining_distance(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'remaining_distance' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'remaining_distance' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._remaining_distance = value

    @builtins.property
    def estimated_time_remaining(self):
        """Message field 'estimated_time_remaining'."""
        return self._estimated_time_remaining

    @estimated_time_remaining.setter
    def estimated_time_remaining(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'estimated_time_remaining' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'estimated_time_remaining' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._estimated_time_remaining = value

    @builtins.property
    def progress(self):
        """Message field 'progress'."""
        return self._progress

    @progress.setter
    def progress(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'progress' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'progress' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._progress = value

    @builtins.property
    def current_planner_id(self):
        """Message field 'current_planner_id'."""
        return self._current_planner_id

    @current_planner_id.setter
    def current_planner_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_planner_id' field must be of type 'str'"
        self._current_planner_id = value

    @builtins.property
    def current_controller_id(self):
        """Message field 'current_controller_id'."""
        return self._current_controller_id

    @current_controller_id.setter
    def current_controller_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_controller_id' field must be of type 'str'"
        self._current_controller_id = value

    @builtins.property
    def created_time(self):
        """Message field 'created_time'."""
        return self._created_time

    @created_time.setter
    def created_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'created_time' field must be a sub message of type 'Time'"
        self._created_time = value

    @builtins.property
    def started_time(self):
        """Message field 'started_time'."""
        return self._started_time

    @started_time.setter
    def started_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'started_time' field must be a sub message of type 'Time'"
        self._started_time = value

    @builtins.property
    def completed_time(self):
        """Message field 'completed_time'."""
        return self._completed_time

    @completed_time.setter
    def completed_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'completed_time' field must be a sub message of type 'Time'"
        self._completed_time = value

    @builtins.property
    def error_message(self):
        """Message field 'error_message'."""
        return self._error_message

    @error_message.setter
    def error_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'error_message' field must be of type 'str'"
        self._error_message = value

    @builtins.property
    def waypoint_type(self):
        """Message field 'waypoint_type'."""
        return self._waypoint_type

    @waypoint_type.setter
    def waypoint_type(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'waypoint_type' field must be of type 'str'"
        self._waypoint_type = value

    @builtins.property
    def navigation_data(self):
        """Message field 'navigation_data'."""
        return self._navigation_data

    @navigation_data.setter
    def navigation_data(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'navigation_data' field must be of type 'str'"
        self._navigation_data = value
