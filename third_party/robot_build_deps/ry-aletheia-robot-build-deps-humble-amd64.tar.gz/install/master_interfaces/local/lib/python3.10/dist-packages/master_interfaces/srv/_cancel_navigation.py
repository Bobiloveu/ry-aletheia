# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/CancelNavigation.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_CancelNavigation_Request(type):
    """Metaclass of message 'CancelNavigation_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.CancelNavigation_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__cancel_navigation__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__cancel_navigation__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__cancel_navigation__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__cancel_navigation__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__cancel_navigation__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CancelNavigation_Request(metaclass=Metaclass_CancelNavigation_Request):
    """Message class 'CancelNavigation_Request'."""

    __slots__ = [
        '_task_id',
        '_reason',
    ]

    _fields_and_field_types = {
        'task_id': 'string',
        'reason': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.task_id = kwargs.get('task_id', str())
        self.reason = kwargs.get('reason', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.task_id != other.task_id:
            return False
        if self.reason != other.reason:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def task_id(self):
        """Message field 'task_id'."""
        return self._task_id

    @task_id.setter
    def task_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'task_id' field must be of type 'str'"
        self._task_id = value

    @builtins.property
    def reason(self):
        """Message field 'reason'."""
        return self._reason

    @reason.setter
    def reason(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'reason' field must be of type 'str'"
        self._reason = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_CancelNavigation_Response(type):
    """Metaclass of message 'CancelNavigation_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.CancelNavigation_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__cancel_navigation__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__cancel_navigation__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__cancel_navigation__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__cancel_navigation__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__cancel_navigation__response

            from master_interfaces.msg import StandardResponse
            if StandardResponse.__class__._TYPE_SUPPORT is None:
                StandardResponse.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class CancelNavigation_Response(metaclass=Metaclass_CancelNavigation_Response):
    """Message class 'CancelNavigation_Response'."""

    __slots__ = [
        '_response',
        '_cancelled_tasks_count',
        '_cancelled_task_ids',
    ]

    _fields_and_field_types = {
        'response': 'master_interfaces/StandardResponse',
        'cancelled_tasks_count': 'int32',
        'cancelled_task_ids': 'sequence<string>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'msg'], 'StandardResponse'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from master_interfaces.msg import StandardResponse
        self.response = kwargs.get('response', StandardResponse())
        self.cancelled_tasks_count = kwargs.get('cancelled_tasks_count', int())
        self.cancelled_task_ids = kwargs.get('cancelled_task_ids', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.response != other.response:
            return False
        if self.cancelled_tasks_count != other.cancelled_tasks_count:
            return False
        if self.cancelled_task_ids != other.cancelled_task_ids:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def response(self):
        """Message field 'response'."""
        return self._response

    @response.setter
    def response(self, value):
        if __debug__:
            from master_interfaces.msg import StandardResponse
            assert \
                isinstance(value, StandardResponse), \
                "The 'response' field must be a sub message of type 'StandardResponse'"
        self._response = value

    @builtins.property
    def cancelled_tasks_count(self):
        """Message field 'cancelled_tasks_count'."""
        return self._cancelled_tasks_count

    @cancelled_tasks_count.setter
    def cancelled_tasks_count(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'cancelled_tasks_count' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'cancelled_tasks_count' field must be an integer in [-2147483648, 2147483647]"
        self._cancelled_tasks_count = value

    @builtins.property
    def cancelled_task_ids(self):
        """Message field 'cancelled_task_ids'."""
        return self._cancelled_task_ids

    @cancelled_task_ids.setter
    def cancelled_task_ids(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'cancelled_task_ids' field must be a set or sequence and each value of type 'str'"
        self._cancelled_task_ids = value


class Metaclass_CancelNavigation(type):
    """Metaclass of service 'CancelNavigation'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.CancelNavigation')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__cancel_navigation

            from master_interfaces.srv import _cancel_navigation
            if _cancel_navigation.Metaclass_CancelNavigation_Request._TYPE_SUPPORT is None:
                _cancel_navigation.Metaclass_CancelNavigation_Request.__import_type_support__()
            if _cancel_navigation.Metaclass_CancelNavigation_Response._TYPE_SUPPORT is None:
                _cancel_navigation.Metaclass_CancelNavigation_Response.__import_type_support__()


class CancelNavigation(metaclass=Metaclass_CancelNavigation):
    from master_interfaces.srv._cancel_navigation import CancelNavigation_Request as Request
    from master_interfaces.srv._cancel_navigation import CancelNavigation_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
