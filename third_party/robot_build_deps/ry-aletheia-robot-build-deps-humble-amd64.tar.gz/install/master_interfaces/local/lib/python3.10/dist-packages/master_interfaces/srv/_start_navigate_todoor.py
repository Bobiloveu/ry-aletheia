# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/StartNavigateTodoor.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_StartNavigateTodoor_Request(type):
    """Metaclass of message 'StartNavigateTodoor_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartNavigateTodoor_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__start_navigate_todoor__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__start_navigate_todoor__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__start_navigate_todoor__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__start_navigate_todoor__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__start_navigate_todoor__request

            from master_interfaces.msg import NavigateWaypoint
            if NavigateWaypoint.__class__._TYPE_SUPPORT is None:
                NavigateWaypoint.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class StartNavigateTodoor_Request(metaclass=Metaclass_StartNavigateTodoor_Request):
    """Message class 'StartNavigateTodoor_Request'."""

    __slots__ = [
        '_waypoints',
    ]

    _fields_and_field_types = {
        'waypoints': 'sequence<master_interfaces/NavigateWaypoint>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['master_interfaces', 'msg'], 'NavigateWaypoint')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.waypoints = kwargs.get('waypoints', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.waypoints != other.waypoints:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def waypoints(self):
        """Message field 'waypoints'."""
        return self._waypoints

    @waypoints.setter
    def waypoints(self, value):
        if __debug__:
            from master_interfaces.msg import NavigateWaypoint
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, NavigateWaypoint) for v in value) and
                 True), \
                "The 'waypoints' field must be a set or sequence and each value of type 'NavigateWaypoint'"
        self._waypoints = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_StartNavigateTodoor_Response(type):
    """Metaclass of message 'StartNavigateTodoor_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartNavigateTodoor_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__start_navigate_todoor__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__start_navigate_todoor__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__start_navigate_todoor__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__start_navigate_todoor__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__start_navigate_todoor__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class StartNavigateTodoor_Response(metaclass=Metaclass_StartNavigateTodoor_Response):
    """Message class 'StartNavigateTodoor_Response'."""

    __slots__ = [
        '_success',
        '_message',
        '_total_waypoints',
        '_task_waypoints',
        '_waypoint_groups',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'total_waypoints': 'int32',
        'task_waypoints': 'int32',
        'waypoint_groups': 'int32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.total_waypoints = kwargs.get('total_waypoints', int())
        self.task_waypoints = kwargs.get('task_waypoints', int())
        self.waypoint_groups = kwargs.get('waypoint_groups', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.total_waypoints != other.total_waypoints:
            return False
        if self.task_waypoints != other.task_waypoints:
            return False
        if self.waypoint_groups != other.waypoint_groups:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def total_waypoints(self):
        """Message field 'total_waypoints'."""
        return self._total_waypoints

    @total_waypoints.setter
    def total_waypoints(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'total_waypoints' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'total_waypoints' field must be an integer in [-2147483648, 2147483647]"
        self._total_waypoints = value

    @builtins.property
    def task_waypoints(self):
        """Message field 'task_waypoints'."""
        return self._task_waypoints

    @task_waypoints.setter
    def task_waypoints(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'task_waypoints' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'task_waypoints' field must be an integer in [-2147483648, 2147483647]"
        self._task_waypoints = value

    @builtins.property
    def waypoint_groups(self):
        """Message field 'waypoint_groups'."""
        return self._waypoint_groups

    @waypoint_groups.setter
    def waypoint_groups(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'waypoint_groups' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'waypoint_groups' field must be an integer in [-2147483648, 2147483647]"
        self._waypoint_groups = value


class Metaclass_StartNavigateTodoor(type):
    """Metaclass of service 'StartNavigateTodoor'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartNavigateTodoor')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__start_navigate_todoor

            from master_interfaces.srv import _start_navigate_todoor
            if _start_navigate_todoor.Metaclass_StartNavigateTodoor_Request._TYPE_SUPPORT is None:
                _start_navigate_todoor.Metaclass_StartNavigateTodoor_Request.__import_type_support__()
            if _start_navigate_todoor.Metaclass_StartNavigateTodoor_Response._TYPE_SUPPORT is None:
                _start_navigate_todoor.Metaclass_StartNavigateTodoor_Response.__import_type_support__()


class StartNavigateTodoor(metaclass=Metaclass_StartNavigateTodoor):
    from master_interfaces.srv._start_navigate_todoor import StartNavigateTodoor_Request as Request
    from master_interfaces.srv._start_navigate_todoor import StartNavigateTodoor_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
