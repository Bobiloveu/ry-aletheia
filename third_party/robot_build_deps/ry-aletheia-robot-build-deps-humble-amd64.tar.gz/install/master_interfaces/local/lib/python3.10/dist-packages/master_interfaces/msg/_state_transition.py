# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:msg/StateTransition.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_StateTransition(type):
    """Metaclass of message 'StateTransition'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'AUTOMATIC': 0,
        'MANUAL': 1,
        'EVENT_TRIGGERED': 2,
        'ERROR_TRIGGERED': 3,
        'TIMEOUT_TRIGGERED': 4,
        'SUCCESS': 0,
        'FAILED': 1,
        'REJECTED': 2,
        'PENDING': 3,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.msg.StateTransition')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__state_transition
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__state_transition
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__state_transition
            cls._TYPE_SUPPORT = module.type_support_msg__msg__state_transition
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__state_transition

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'AUTOMATIC': cls.__constants['AUTOMATIC'],
            'MANUAL': cls.__constants['MANUAL'],
            'EVENT_TRIGGERED': cls.__constants['EVENT_TRIGGERED'],
            'ERROR_TRIGGERED': cls.__constants['ERROR_TRIGGERED'],
            'TIMEOUT_TRIGGERED': cls.__constants['TIMEOUT_TRIGGERED'],
            'SUCCESS': cls.__constants['SUCCESS'],
            'FAILED': cls.__constants['FAILED'],
            'REJECTED': cls.__constants['REJECTED'],
            'PENDING': cls.__constants['PENDING'],
        }

    @property
    def AUTOMATIC(self):
        """Message constant 'AUTOMATIC'."""
        return Metaclass_StateTransition.__constants['AUTOMATIC']

    @property
    def MANUAL(self):
        """Message constant 'MANUAL'."""
        return Metaclass_StateTransition.__constants['MANUAL']

    @property
    def EVENT_TRIGGERED(self):
        """Message constant 'EVENT_TRIGGERED'."""
        return Metaclass_StateTransition.__constants['EVENT_TRIGGERED']

    @property
    def ERROR_TRIGGERED(self):
        """Message constant 'ERROR_TRIGGERED'."""
        return Metaclass_StateTransition.__constants['ERROR_TRIGGERED']

    @property
    def TIMEOUT_TRIGGERED(self):
        """Message constant 'TIMEOUT_TRIGGERED'."""
        return Metaclass_StateTransition.__constants['TIMEOUT_TRIGGERED']

    @property
    def SUCCESS(self):
        """Message constant 'SUCCESS'."""
        return Metaclass_StateTransition.__constants['SUCCESS']

    @property
    def FAILED(self):
        """Message constant 'FAILED'."""
        return Metaclass_StateTransition.__constants['FAILED']

    @property
    def REJECTED(self):
        """Message constant 'REJECTED'."""
        return Metaclass_StateTransition.__constants['REJECTED']

    @property
    def PENDING(self):
        """Message constant 'PENDING'."""
        return Metaclass_StateTransition.__constants['PENDING']


class StateTransition(metaclass=Metaclass_StateTransition):
    """
    Message class 'StateTransition'.

    Constants:
      AUTOMATIC
      MANUAL
      EVENT_TRIGGERED
      ERROR_TRIGGERED
      TIMEOUT_TRIGGERED
      SUCCESS
      FAILED
      REJECTED
      PENDING
    """

    __slots__ = [
        '_transition_id',
        '_from_state',
        '_to_state',
        '_transition_type',
        '_transition_result',
        '_trigger_event',
        '_transition_start_time',
        '_transition_end_time',
        '_transition_duration_ms',
        '_reason',
        '_error_message',
        '_transition_data',
    ]

    _fields_and_field_types = {
        'transition_id': 'string',
        'from_state': 'uint8',
        'to_state': 'uint8',
        'transition_type': 'uint8',
        'transition_result': 'uint8',
        'trigger_event': 'string',
        'transition_start_time': 'builtin_interfaces/Time',
        'transition_end_time': 'builtin_interfaces/Time',
        'transition_duration_ms': 'int64',
        'reason': 'string',
        'error_message': 'string',
        'transition_data': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.transition_id = kwargs.get('transition_id', str())
        self.from_state = kwargs.get('from_state', int())
        self.to_state = kwargs.get('to_state', int())
        self.transition_type = kwargs.get('transition_type', int())
        self.transition_result = kwargs.get('transition_result', int())
        self.trigger_event = kwargs.get('trigger_event', str())
        from builtin_interfaces.msg import Time
        self.transition_start_time = kwargs.get('transition_start_time', Time())
        from builtin_interfaces.msg import Time
        self.transition_end_time = kwargs.get('transition_end_time', Time())
        self.transition_duration_ms = kwargs.get('transition_duration_ms', int())
        self.reason = kwargs.get('reason', str())
        self.error_message = kwargs.get('error_message', str())
        self.transition_data = kwargs.get('transition_data', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.transition_id != other.transition_id:
            return False
        if self.from_state != other.from_state:
            return False
        if self.to_state != other.to_state:
            return False
        if self.transition_type != other.transition_type:
            return False
        if self.transition_result != other.transition_result:
            return False
        if self.trigger_event != other.trigger_event:
            return False
        if self.transition_start_time != other.transition_start_time:
            return False
        if self.transition_end_time != other.transition_end_time:
            return False
        if self.transition_duration_ms != other.transition_duration_ms:
            return False
        if self.reason != other.reason:
            return False
        if self.error_message != other.error_message:
            return False
        if self.transition_data != other.transition_data:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def transition_id(self):
        """Message field 'transition_id'."""
        return self._transition_id

    @transition_id.setter
    def transition_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'transition_id' field must be of type 'str'"
        self._transition_id = value

    @builtins.property
    def from_state(self):
        """Message field 'from_state'."""
        return self._from_state

    @from_state.setter
    def from_state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'from_state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'from_state' field must be an unsigned integer in [0, 255]"
        self._from_state = value

    @builtins.property
    def to_state(self):
        """Message field 'to_state'."""
        return self._to_state

    @to_state.setter
    def to_state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'to_state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'to_state' field must be an unsigned integer in [0, 255]"
        self._to_state = value

    @builtins.property
    def transition_type(self):
        """Message field 'transition_type'."""
        return self._transition_type

    @transition_type.setter
    def transition_type(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'transition_type' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'transition_type' field must be an unsigned integer in [0, 255]"
        self._transition_type = value

    @builtins.property
    def transition_result(self):
        """Message field 'transition_result'."""
        return self._transition_result

    @transition_result.setter
    def transition_result(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'transition_result' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'transition_result' field must be an unsigned integer in [0, 255]"
        self._transition_result = value

    @builtins.property
    def trigger_event(self):
        """Message field 'trigger_event'."""
        return self._trigger_event

    @trigger_event.setter
    def trigger_event(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'trigger_event' field must be of type 'str'"
        self._trigger_event = value

    @builtins.property
    def transition_start_time(self):
        """Message field 'transition_start_time'."""
        return self._transition_start_time

    @transition_start_time.setter
    def transition_start_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'transition_start_time' field must be a sub message of type 'Time'"
        self._transition_start_time = value

    @builtins.property
    def transition_end_time(self):
        """Message field 'transition_end_time'."""
        return self._transition_end_time

    @transition_end_time.setter
    def transition_end_time(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'transition_end_time' field must be a sub message of type 'Time'"
        self._transition_end_time = value

    @builtins.property
    def transition_duration_ms(self):
        """Message field 'transition_duration_ms'."""
        return self._transition_duration_ms

    @transition_duration_ms.setter
    def transition_duration_ms(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'transition_duration_ms' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'transition_duration_ms' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._transition_duration_ms = value

    @builtins.property
    def reason(self):
        """Message field 'reason'."""
        return self._reason

    @reason.setter
    def reason(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'reason' field must be of type 'str'"
        self._reason = value

    @builtins.property
    def error_message(self):
        """Message field 'error_message'."""
        return self._error_message

    @error_message.setter
    def error_message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'error_message' field must be of type 'str'"
        self._error_message = value

    @builtins.property
    def transition_data(self):
        """Message field 'transition_data'."""
        return self._transition_data

    @transition_data.setter
    def transition_data(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'transition_data' field must be of type 'str'"
        self._transition_data = value
