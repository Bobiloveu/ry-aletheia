# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/GetNavigationStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_GetNavigationStatus_Request(type):
    """Metaclass of message 'GetNavigationStatus_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetNavigationStatus_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__get_navigation_status__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__get_navigation_status__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__get_navigation_status__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__get_navigation_status__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__get_navigation_status__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class GetNavigationStatus_Request(metaclass=Metaclass_GetNavigationStatus_Request):
    """Message class 'GetNavigationStatus_Request'."""

    __slots__ = [
        '_task_id',
    ]

    _fields_and_field_types = {
        'task_id': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.task_id = kwargs.get('task_id', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.task_id != other.task_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def task_id(self):
        """Message field 'task_id'."""
        return self._task_id

    @task_id.setter
    def task_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'task_id' field must be of type 'str'"
        self._task_id = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_GetNavigationStatus_Response(type):
    """Metaclass of message 'GetNavigationStatus_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetNavigationStatus_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__get_navigation_status__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__get_navigation_status__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__get_navigation_status__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__get_navigation_status__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__get_navigation_status__response

            from master_interfaces.msg import NavigationStatus
            if NavigationStatus.__class__._TYPE_SUPPORT is None:
                NavigationStatus.__class__.__import_type_support__()

            from master_interfaces.msg import StandardResponse
            if StandardResponse.__class__._TYPE_SUPPORT is None:
                StandardResponse.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class GetNavigationStatus_Response(metaclass=Metaclass_GetNavigationStatus_Response):
    """Message class 'GetNavigationStatus_Response'."""

    __slots__ = [
        '_response',
        '_navigation_status',
    ]

    _fields_and_field_types = {
        'response': 'master_interfaces/StandardResponse',
        'navigation_status': 'sequence<master_interfaces/NavigationStatus>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['master_interfaces', 'msg'], 'StandardResponse'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['master_interfaces', 'msg'], 'NavigationStatus')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from master_interfaces.msg import StandardResponse
        self.response = kwargs.get('response', StandardResponse())
        self.navigation_status = kwargs.get('navigation_status', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.response != other.response:
            return False
        if self.navigation_status != other.navigation_status:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def response(self):
        """Message field 'response'."""
        return self._response

    @response.setter
    def response(self, value):
        if __debug__:
            from master_interfaces.msg import StandardResponse
            assert \
                isinstance(value, StandardResponse), \
                "The 'response' field must be a sub message of type 'StandardResponse'"
        self._response = value

    @builtins.property
    def navigation_status(self):
        """Message field 'navigation_status'."""
        return self._navigation_status

    @navigation_status.setter
    def navigation_status(self, value):
        if __debug__:
            from master_interfaces.msg import NavigationStatus
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, NavigationStatus) for v in value) and
                 True), \
                "The 'navigation_status' field must be a set or sequence and each value of type 'NavigationStatus'"
        self._navigation_status = value


class Metaclass_GetNavigationStatus(type):
    """Metaclass of service 'GetNavigationStatus'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetNavigationStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__get_navigation_status

            from master_interfaces.srv import _get_navigation_status
            if _get_navigation_status.Metaclass_GetNavigationStatus_Request._TYPE_SUPPORT is None:
                _get_navigation_status.Metaclass_GetNavigationStatus_Request.__import_type_support__()
            if _get_navigation_status.Metaclass_GetNavigationStatus_Response._TYPE_SUPPORT is None:
                _get_navigation_status.Metaclass_GetNavigationStatus_Response.__import_type_support__()


class GetNavigationStatus(metaclass=Metaclass_GetNavigationStatus):
    from master_interfaces.srv._get_navigation_status import GetNavigationStatus_Request as Request
    from master_interfaces.srv._get_navigation_status import GetNavigationStatus_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
