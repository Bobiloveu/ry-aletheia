# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/GetElevatorId.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_GetElevatorId_Request(type):
    """Metaclass of message 'GetElevatorId_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetElevatorId_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__get_elevator_id__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__get_elevator_id__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__get_elevator_id__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__get_elevator_id__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__get_elevator_id__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class GetElevatorId_Request(metaclass=Metaclass_GetElevatorId_Request):
    """Message class 'GetElevatorId_Request'."""

    __slots__ = [
        '_community',
        '_building',
        '_unit',
        '_floor',
        '_door',
    ]

    _fields_and_field_types = {
        'community': 'string',
        'building': 'int32',
        'unit': 'int32',
        'floor': 'int32',
        'door': 'int32',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.community = kwargs.get('community', str())
        self.building = kwargs.get('building', int())
        self.unit = kwargs.get('unit', int())
        self.floor = kwargs.get('floor', int())
        self.door = kwargs.get('door', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.community != other.community:
            return False
        if self.building != other.building:
            return False
        if self.unit != other.unit:
            return False
        if self.floor != other.floor:
            return False
        if self.door != other.door:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def community(self):
        """Message field 'community'."""
        return self._community

    @community.setter
    def community(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'community' field must be of type 'str'"
        self._community = value

    @builtins.property
    def building(self):
        """Message field 'building'."""
        return self._building

    @building.setter
    def building(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'building' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'building' field must be an integer in [-2147483648, 2147483647]"
        self._building = value

    @builtins.property
    def unit(self):
        """Message field 'unit'."""
        return self._unit

    @unit.setter
    def unit(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'unit' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'unit' field must be an integer in [-2147483648, 2147483647]"
        self._unit = value

    @builtins.property
    def floor(self):
        """Message field 'floor'."""
        return self._floor

    @floor.setter
    def floor(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'floor' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'floor' field must be an integer in [-2147483648, 2147483647]"
        self._floor = value

    @builtins.property
    def door(self):
        """Message field 'door'."""
        return self._door

    @door.setter
    def door(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'door' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'door' field must be an integer in [-2147483648, 2147483647]"
        self._door = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_GetElevatorId_Response(type):
    """Metaclass of message 'GetElevatorId_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetElevatorId_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__get_elevator_id__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__get_elevator_id__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__get_elevator_id__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__get_elevator_id__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__get_elevator_id__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class GetElevatorId_Response(metaclass=Metaclass_GetElevatorId_Response):
    """Message class 'GetElevatorId_Response'."""

    __slots__ = [
        '_success',
        '_elevatorid',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'elevatorid': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.elevatorid = kwargs.get('elevatorid', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.elevatorid != other.elevatorid:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def elevatorid(self):
        """Message field 'elevatorid'."""
        return self._elevatorid

    @elevatorid.setter
    def elevatorid(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'elevatorid' field must be of type 'str'"
        self._elevatorid = value


class Metaclass_GetElevatorId(type):
    """Metaclass of service 'GetElevatorId'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.GetElevatorId')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__get_elevator_id

            from master_interfaces.srv import _get_elevator_id
            if _get_elevator_id.Metaclass_GetElevatorId_Request._TYPE_SUPPORT is None:
                _get_elevator_id.Metaclass_GetElevatorId_Request.__import_type_support__()
            if _get_elevator_id.Metaclass_GetElevatorId_Response._TYPE_SUPPORT is None:
                _get_elevator_id.Metaclass_GetElevatorId_Response.__import_type_support__()


class GetElevatorId(metaclass=Metaclass_GetElevatorId):
    from master_interfaces.srv._get_elevator_id import GetElevatorId_Request as Request
    from master_interfaces.srv._get_elevator_id import GetElevatorId_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
