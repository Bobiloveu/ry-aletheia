# generated from rosidl_generator_py/resource/_idl.py.em
# with input from master_interfaces:srv/StartRecordPath.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_StartRecordPath_Request(type):
    """Metaclass of message 'StartRecordPath_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartRecordPath_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__start_record_path__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__start_record_path__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__start_record_path__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__start_record_path__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__start_record_path__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class StartRecordPath_Request(metaclass=Metaclass_StartRecordPath_Request):
    """Message class 'StartRecordPath_Request'."""

    __slots__ = [
        '_mode',
        '_type',
        '_community',
        '_building',
        '_unit',
        '_floor',
        '_door',
        '_path_name',
        '_bag_path',
        '_point_interval',
    ]

    _fields_and_field_types = {
        'mode': 'string',
        'type': 'string',
        'community': 'string',
        'building': 'int32',
        'unit': 'int32',
        'floor': 'int32',
        'door': 'int32',
        'path_name': 'string',
        'bag_path': 'string',
        'point_interval': 'double',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.mode = kwargs.get('mode', str())
        self.type = kwargs.get('type', str())
        self.community = kwargs.get('community', str())
        self.building = kwargs.get('building', int())
        self.unit = kwargs.get('unit', int())
        self.floor = kwargs.get('floor', int())
        self.door = kwargs.get('door', int())
        self.path_name = kwargs.get('path_name', str())
        self.bag_path = kwargs.get('bag_path', str())
        self.point_interval = kwargs.get('point_interval', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.mode != other.mode:
            return False
        if self.type != other.type:
            return False
        if self.community != other.community:
            return False
        if self.building != other.building:
            return False
        if self.unit != other.unit:
            return False
        if self.floor != other.floor:
            return False
        if self.door != other.door:
            return False
        if self.path_name != other.path_name:
            return False
        if self.bag_path != other.bag_path:
            return False
        if self.point_interval != other.point_interval:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def mode(self):
        """Message field 'mode'."""
        return self._mode

    @mode.setter
    def mode(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'mode' field must be of type 'str'"
        self._mode = value

    @builtins.property  # noqa: A003
    def type(self):  # noqa: A003
        """Message field 'type'."""
        return self._type

    @type.setter  # noqa: A003
    def type(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'type' field must be of type 'str'"
        self._type = value

    @builtins.property
    def community(self):
        """Message field 'community'."""
        return self._community

    @community.setter
    def community(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'community' field must be of type 'str'"
        self._community = value

    @builtins.property
    def building(self):
        """Message field 'building'."""
        return self._building

    @building.setter
    def building(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'building' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'building' field must be an integer in [-2147483648, 2147483647]"
        self._building = value

    @builtins.property
    def unit(self):
        """Message field 'unit'."""
        return self._unit

    @unit.setter
    def unit(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'unit' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'unit' field must be an integer in [-2147483648, 2147483647]"
        self._unit = value

    @builtins.property
    def floor(self):
        """Message field 'floor'."""
        return self._floor

    @floor.setter
    def floor(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'floor' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'floor' field must be an integer in [-2147483648, 2147483647]"
        self._floor = value

    @builtins.property
    def door(self):
        """Message field 'door'."""
        return self._door

    @door.setter
    def door(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'door' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'door' field must be an integer in [-2147483648, 2147483647]"
        self._door = value

    @builtins.property
    def path_name(self):
        """Message field 'path_name'."""
        return self._path_name

    @path_name.setter
    def path_name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'path_name' field must be of type 'str'"
        self._path_name = value

    @builtins.property
    def bag_path(self):
        """Message field 'bag_path'."""
        return self._bag_path

    @bag_path.setter
    def bag_path(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'bag_path' field must be of type 'str'"
        self._bag_path = value

    @builtins.property
    def point_interval(self):
        """Message field 'point_interval'."""
        return self._point_interval

    @point_interval.setter
    def point_interval(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'point_interval' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'point_interval' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._point_interval = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_StartRecordPath_Response(type):
    """Metaclass of message 'StartRecordPath_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartRecordPath_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__start_record_path__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__start_record_path__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__start_record_path__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__start_record_path__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__start_record_path__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class StartRecordPath_Response(metaclass=Metaclass_StartRecordPath_Response):
    """Message class 'StartRecordPath_Response'."""

    __slots__ = [
        '_success',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value


class Metaclass_StartRecordPath(type):
    """Metaclass of service 'StartRecordPath'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('master_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'master_interfaces.srv.StartRecordPath')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__start_record_path

            from master_interfaces.srv import _start_record_path
            if _start_record_path.Metaclass_StartRecordPath_Request._TYPE_SUPPORT is None:
                _start_record_path.Metaclass_StartRecordPath_Request.__import_type_support__()
            if _start_record_path.Metaclass_StartRecordPath_Response._TYPE_SUPPORT is None:
                _start_record_path.Metaclass_StartRecordPath_Response.__import_type_support__()


class StartRecordPath(metaclass=Metaclass_StartRecordPath):
    from master_interfaces.srv._start_record_path import StartRecordPath_Request as Request
    from master_interfaces.srv._start_record_path import StartRecordPath_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
